# CityDeals — Standalone Android APK Guide

This guide explains how CityDeals is packaged for Android, why the current installed app looks and behaves the way it does, and how to build a standalone `.apk` file that can be installed on any Android phone.

---

## 1. How the Currently Installed App Was Packaged

The version currently installed on your phone is an **Android WebAPK** generated automatically by Google Chrome when you tapped **"Install app"** or **"Add to Home Screen"** from `manifest.json`.

- **WebAPK Mechanism**: Chrome on Android contacts Google's WebAPK Minting Service, which creates a lightweight wrapper application linking directly to the CityDeals web server.
- **Why White Side Gutters Appeared**: In standalone mode on modern Android screens (with front-camera cutouts or navigation gesture bars), Android letterboxes apps unless the web page explicitly specifies `viewport-fit=cover`. Without it, Android renders artificial white pillarbox margins on both sides of the screen to protect what it considers unsafe display cutouts.
- **The Fix**: We added `viewport-fit=cover` and maximum screen width handling to `index.html` and `src/index.css`, ensuring the app fills 100% of the display edge-to-edge.

---

## 2. Producing a Standalone APK for Other Android Devices

Because this server container runs Node.js without the Java Development Kit (JDK) or Android SDK command-line tools installed, native APK compilation cannot be executed directly inside this container terminal.

We have configured **two turnkey ways** to generate the standalone `.apk` for other devices:

### Option A: 1-Click Cloud Build (Recommended — No Technical Setup)

We have added a complete automated build workflow at `.github/workflows/build-apk.yml`.

1. Push this project to GitHub (or commit to your repository).
2. Go to the **Actions** tab on your GitHub repository.
3. Select **"Build CityDeals Standalone Android APK"** and click **Run workflow**.
4. GitHub's cloud runners (with Java 17 and Android SDK pre-installed) will build and sign the app in ~2 minutes.
5. Download the ready-to-install `citydeals-standalone-release-apk` zip containing `app-release-signed.apk`.

---

### Option B: Local 2-Minute Build on Any Computer

If you have a laptop or computer with Node.js and Java installed:

1. Clone or download this project.
2. Install Bubblewrap CLI:
   ```bash
   npm install -g @bubblewrap/cli
   ```
3. Generate the keystore (if you don't already have one):
   ```bash
   keytool -genkey -v -keystore android.keystore -alias citydeals -keyalg RSA -keysize 2048 -validity 10000
   ```
4. Build the APK:
   ```bash
   bubblewrap build
   ```
5. The generated file `app-release-signed.apk` will be output in your project folder.

---

## 3. Package & Connection Configuration

- **Application ID**: `in.citydeals.app`
- **Application Name**: CityDeals
- **Target Backend Server**: `https://ais-dev-d2brfyn5mt4gkwn2bkdrjd-726927888221.asia-northeast1.run.app`
- **Permissions**: `INTERNET`, `ACCESS_NETWORK_STATE` (standard network access, no invasive permissions required).
- **Backend Verification**: `/.well-known/assetlinks.json` is already active on the server to remove the browser address bar in the APK.

---

## 4. How to Install on Any Android Phone

1. Transfer `app-release-signed.apk` to any Android phone via WhatsApp, Google Drive, email, or USB cable.
2. Tap on the `.apk` file to open it.
3. If prompted with *"For your security, your phone is not allowed to install unknown apps from this source"*, tap **Settings** and toggle **"Allow from this source"**.
4. Tap **Install**, then **Open**.
5. The app launches immediately in full screen, connecting to the live CityDeals production backend.
