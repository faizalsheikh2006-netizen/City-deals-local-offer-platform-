# CityDeals – RBAC & Admin Preview System Implementation Report

## Overview
This report details the implementation of strict Role-Based Access Control (RBAC) and the Admin Preview ("View As") System for the CityDeals application, ensuring data integrity, privilege separation, and zero regression of existing merchant listings and offers.

---

## 1. Summary of Modified Files

| File Path | Description of Changes |
|---|---|
| `firestore.rules` | Security rules hardened: `/users/{userId}` now explicitly forbids users from modifying their own `role` field on update (`!request.resource.data.diff(resource.data).affectedKeys().hasAny(['role'])`). `/admins/{adminId}` write rules restricted to verified administrators (`allow write: if isValidId(adminId) && isAdmin();`). Deployed to Firebase project. |
| `server.ts` | 1. Hardened `getRequester(req)` to verify admin privilege against `TRUSTED_ADMIN_UIDS` and founder email (`citydeals.discoverlocal@gmail.com`).<br>2. Prohibited self-registration as admin in `POST /api/auth/register` (rejects `role: 'admin'` with HTTP 403; defaults strictly to `'public'`).<br>3. Introduced `requireMerchantOrAdmin` middleware and protected 19 merchant API routes (business profile, offers CRUD, promotions, verifications, products catalog, and orders). |
| `src/context/AppContext.tsx` | 1. Added `adminPreviewMode`: `'admin' \| 'merchant' \| 'public'` (persisted in `sessionStorage`).<br>2. Added `effectiveRole`: computed UI role (`user.role === 'admin' ? adminPreviewMode : user.role`) while preserving true user role and backend tokens.<br>3. Added `setAdminPreviewMode` method.<br>4. Updated `switchRole(targetRole)`: purely toggles `adminPreviewMode` if administrator; toggles between public browsing and merchant dashboard if merchant; prevents public customers from entering merchant dashboard.<br>5. Unified authentication redirects: automatically routes to `admin`, `merchant`, or `browse` upon login based on server-stored role. |
| `src/App.tsx` | Added persistent sticky **Admin Preview Mode Banner** rendered whenever `user.role === 'admin' && adminPreviewMode !== 'admin'`. Displays active preview mode (`Merchant View` or `Public Customer View`), quick-switch buttons, and a prominent **"Return to Admin Dashboard"** button that restores admin view. Updated header visibility during preview. |
| `src/components/Header.tsx` | Integrated `effectiveRole`: Merchant Portal link and badge adapt to preview mode. Admin controls ("Admin Control Centre") are cleanly omitted from header dropdown and mobile navigation when previewing as Merchant or Public. User badge displays `Merchant (Preview)` or `Public (Preview)`. |
| `src/components/AdminPortal.tsx` | Added **"Preview Application As"** section with dedicated options: **Admin View**, **Merchant View**, and **Public View**, allowing seamless switching without logging out. |
| `src/components/ShopkeeperPortal.tsx` | Added access guard: renders an informative "Access Restricted: Public Customer Account" screen with navigation to public deals or merchant registration if a customer accesses the merchant portal directly. |
| `src/components/AuthModal.tsx` | Added Unified Sign-In guidance banner: clarifies that Customers, Merchants, and Administrators all sign in using the single unified form without needing to select a role. |

---

## 2. Security Changes Implemented

1. **Strict Three-Role Model (`ADMIN`, `MERCHANT`, `PUBLIC`)**:
   - Every user in the database has exactly one real role stored on their server user profile (`data/citydeals_db.json` and Firestore `/users/{uid}`).
   - New registrations are restricted to `'public'` (Customer) or `'merchant'` (Merchant). Submitting `role: 'admin'` to `POST /api/auth/register` is rejected with `403 Forbidden`.
   - Admin privileges require provisioning in `TRUSTED_ADMIN_UIDS` and the Firestore `/admins` collection.

2. **Backend API Route Protection**:
   - Every `/api/merchant/*` endpoint is guarded by `requireMerchantOrAdmin`. Public users attempting direct HTTP requests receive `403 Forbidden`.
   - Every `/api/admin/*` endpoint is guarded by `requireAdmin`. Non-admin accounts receive `403 Forbidden`.
   - Public endpoints (`/api/offers`, `/api/businesses`, `/api/products`) are accessible to all roles (public users, merchants, and admins).

3. **Database Security Rules**:
   - Firestore security rules verify document ownership and role immutability.
   - Deployed to the project `ai-studio-citydealslocalof-dc47f173-bace-4152-bd24-6bdde99d4c87`.

4. **Safe Admin Preview System**:
   - The preview system operates purely as a client-side visual context (`adminPreviewMode` & `effectiveRole`).
   - The admin's backend authorization token and Firestore credentials remain intact with administrative rights.
   - Zero state mutation or role reassignment in the database occurs when switching views.

---

## 3. Verification Test Suite Results

The automated and API verification suite was executed against the live dev server on port 3000:

| # | Test Scenario | Expected Result | Actual Result | Status |
|---|---|---|---|---|
| 1 | **Public User Registration** | Create user with `role: 'public'` | HTTP 201, `user.role === 'public'` | **PASS** |
| 2 | **Merchant Registration** | Create user with `role: 'merchant'` | HTTP 201, `user.role === 'merchant'` | **PASS** |
| 3 | **Admin Self-Registration Attempt** | User attempts `POST /api/auth/register` with `role: 'admin'` | HTTP 403 Forbidden with security error | **PASS** |
| 4 | **Unified Sign-In (Public User)** | Login with public credentials | HTTP 200, role returned as `'public'`, routed to Browse | **PASS** |
| 5 | **Unified Sign-In (Merchant User)** | Login with merchant credentials | HTTP 200, role returned as `'merchant'`, routed to Merchant Portal | **PASS** |
| 6 | **Unified Sign-In (Administrator)** | Login with admin credentials | HTTP 200, role returned as `'admin'`, routed to Admin Portal | **PASS** |
| 7 | **Public User accessing Merchant API** | Public token calls `GET /api/merchant/offers` | HTTP 403 Forbidden (Merchant privilege required) | **PASS** |
| 8 | **Public User accessing Admin API** | Public token calls `GET /api/admin/stats` | HTTP 403 Forbidden (Admin privilege required) | **PASS** |
| 9 | **Merchant User accessing Admin API** | Merchant token calls `GET /api/admin/stats` | HTTP 403 Forbidden (Admin privilege required) | **PASS** |
| 10 | **Merchant Public + Merchant Dual Access** | Merchant browses public deals and accesses merchant dashboard | HTTP 200 for `/api/offers` and HTTP 200 for `/api/merchant/offers` | **PASS** |
| 11 | **Admin Access to Merchant API** | Admin token accessing merchant endpoints for inspection | HTTP 200 OK | **PASS** |
| 12 | **Admin Preview Mode Toggle** | Admin switches between Admin, Merchant, and Public views | Instant client switch with banner; "Return to Admin Dashboard" restores view | **PASS** |
| 13 | **Session Persistence** | Refreshing the browser preserves credentials & preview context | Session restored via `sessionStorage` and token refresh | **PASS** |

---

## 4. Compilation & Linting Results
- `compile_applet`: **Build succeeded - the applet is compiled**
- `lint_applet`: **Linting completed successfully ($ tsc --noEmit: 0 errors)**
