# CityDeals Critical Firebase Architecture Remediation Plan

A detailed, non-destructive architectural remediation plan to address the three critical gaps identified in the technical audit:
1. Migrating the Express server (`server.ts`) from the local JSON store (`data/citydeals_db.json`) to Google Cloud Firestore using the Firebase Admin SDK.
2. Implementing genuine Firebase Authentication accounts (Email/Password & Google OAuth) with an automated account claim & password-reset flow for existing users with scrypt password hashes.
3. Replacing the local reset-token system with native Firebase Authentication password-recovery workflows.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Zero code or database changes have been made.** Review the decisions below and click **Proceed** (or provide feedback) to authorize the execution of this plan.

*   **Firebase Admin SDK vs. Client SDK on Backend**:
    *   *Decision*: Install `firebase-admin` for `server.ts`. The backend will authenticate using Google Cloud Application Default Credentials (ADC) scoped to project `arboreal-maker-n3kqt` and named database `ai-studio-citydealslocalof-dc47f173-bace-4152-bd24-6bdde99d4c87`. No service account secret keys will be stored or exposed in client bundles.
*   **Existing User Credential Recovery (Zero Password Inventions)**:
    *   *Decision*: Existing users (10 accounts) have salted scrypt password hashes that cannot be converted to plaintext. When existing users log in or request a password reset, the system will provision their corresponding Firebase Auth record (matching their existing `userId`) and issue an official Firebase password reset email. Once they set their password, they sign in via Firebase Auth with their original `userId`, preserving their shop profiles, offers, and order histories.
*   **Safe Data Isolation (Demo vs. Genuine)**:
    *   *Decision*: Genuine merchants (`usr-admin-mvtwy8x5`, `usr-1792955234246-dc20d19a`, `usr-1793006838902-6b0332ee`) will remain active in the primary Firestore collections. Pre-existing demo records (`isDemo: true`) will be flagged with `isArchived: true` or moved to an `/archived_demo` collection rather than deleted.
*   **API Contract Preservation**:
    *   *Decision*: The Express REST routes (`/api/offers`, `/api/businesses`, `/api/products`, `/api/orders`, `/api/admin/*`, `/api/merchants/*`) will be preserved so the React frontend, PWA service worker, recent searches, and shopping cart require zero breaking changes.

---

## 1. Updated System Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CityDeals Frontend (React PWA)                  │
│                                                                        │
│   ┌─────────────────────┐   ┌─────────────────┐   ┌────────────────┐   │
│   │ Discovery & Search  │   │ Merchant Portal │   │ Admin Console  │   │
│   │ (Offers, Shop, Cart)│   │ (Manage Deals,  │   │ (Moderation,   │   │
│   │                     │   │  Stock, Orders) │   │  Audit, Ads)   │   │
│   └──────────┬──────────┘   └────────┬────────┘   └────────┬───────┘   │
│              │                       │                     │           │
│              ▼                       ▼                     ▼           │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │ Firebase Auth Client SDK (`signInWithEmailAndPassword`,        │   │
│   │ `signInWithPopup(Google)`, `sendPasswordResetEmail`)           │   │
│   └───────────────────────────────┬────────────────────────────────┘   │
│                                   │ Bearer ID Token                    │
└───────────────────────────────────┼────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                      Express Backend (`server.ts`)                     │
│                                                                        │
│   ┌──────────────────────┐  ┌───────────────────┐  ┌───────────────┐   │
│   │ Rate Limiting        │  │ Firebase Admin    │  │ Business      │   │
│   │ (express-rate-limit) │  │ Token Verifier    │  │ Validation    │   │
│   │                      │  │ `verifyIdToken()` │  │ & Ownership   │   │
│   └──────────┬───────────┘  └────────┬──────────┘  └───────┬───────┘   │
└──────────────┼───────────────────────┼─────────────────────┼───────────┘
               │                       │                     │
               ▼                       ▼                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                 Google Cloud Firestore & Firebase Auth                 │
│                                                                        │
│   Database: `ai-studio-citydealslocalof-dc47f173-bace-4152-bd24...`    │
│                                                                        │
│   ┌──────────────────────┐  ┌───────────────────┐  ┌───────────────┐   │
│   │ /users & /admins     │  │ /businesses &     │  │ Firebase Auth │   │
│   │ (RBAC Registry)      │  │ /offers & /orders │  │ Identity Pool │   │
│   └──────────────────────┘  └───────────────────┘  └───────────────┘   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Files Requiring Modification

| File Path | Type | Planned Changes |
|---|---|---|
| `package.json` | Dependency | Add `firebase-admin` (runtime dependency) via `install_applet_package`. |
| `server.ts` | Backend Core | Replace in-memory `Store` queries and `fs.writeFileSync` with Firebase Admin Firestore collections (`db.collection('offers')`, `db.collection('products')`, etc.). Replace custom token check with `admin.auth().verifyIdToken()`. |
| `src/context/AuthContext.tsx` | Auth State | Integrate Firebase Auth listener (`onAuthStateChanged`). Issue Firebase ID tokens to Express via `Authorization: Bearer <token>`. Support Email/Password, Google Sign-in, and Firebase password recovery. |
| `src/components/AuthModal.tsx` | UI Forms | Update login and registration forms to call Firebase Auth SDK directly. Route "Forgot Password" to native Firebase Auth `sendPasswordResetEmail()`. |
| `src/api/client.ts` | API Client | Ensure every authenticated request retrieves the latest Firebase ID token (`user.getIdToken()`) and passes it in the `Authorization` header. |
| `scripts/seed-firestore-admin.ts` | Automation | Ensure administrative roles and initial master records are verified in `/admins` collection. |
| `scripts/archive-demo-data.ts` | Cleanup Utility | Separate and safely isolate demo items (`isDemo: true`) without deleting genuine shopkeeper listings. |

---

## 3. Firebase Configuration Required

1.  **Firebase Authentication Providers**:
    *   **Google OAuth**: Already enabled via provisioned client config (`oAuthClientId: 866966298069-hjv4d1qadekr1hjf3biec4v3b41kaoe0.apps.googleusercontent.com`).
    *   **Email & Password**: Enable Email/Password provider for merchants and public customers.
2.  **Firebase Admin SDK Initialization**:
    *   Initialize using the project configuration from `firebase-applet-config.json`:
        ```typescript
        import * as admin from 'firebase-admin';
        import firebaseConfig from './firebase-applet-config.json';

        if (!admin.apps.length) {
          admin.initializeApp({
            projectId: firebaseConfig.projectId,
          });
        }
        export const firestoreAdmin = admin.firestore();
        export const authAdmin = admin.auth();
        ```
    *   Configure database ID targeting named database: `firestoreAdmin.databaseId = firebaseConfig.firestoreDatabaseId;`

---

## 4. Data Migration Strategy (Zero Loss & Dual Safety)

1.  **Immutable Snapshot**:
    *   Before executing any write, copy `data/citydeals_db.json` to `data/backups/pre_admin_migration_snapshot.json`.
    *   Keep `data/citydeals_db.json` intact as a read-only local archive.
2.  **Entity-by-Entity Firestore Mapping**:
    *   `businesses`: Read from Firestore collection. Merchant updates validate `business.merchantId === requester.uid`.
    *   `offers`: Query live offers where `status == 'active'` and `validUntil > now()`. Offer creation writes `status: 'pending'`.
    *   `products`: Real-time stock decrements executed using Firestore atomic transactions (`runTransaction`).
    *   `orders`: Orders written directly to `/orders/{orderId}` with sequential numbering `CD-ORD-...`.
3.  **Audit Logs & Reports**:
    *   Administrative logs written to `/auditLogs` on every approval, rejection, or role change.

---

## 5. Authentication Recovery Strategy (For Existing Scrypt Users)

Existing accounts cannot have their passwords converted or read. To allow existing merchants (`heritage.silks@gmail.com`, `manash.retail@gmail.com`, `assam.handicrafts...`) to access their stores securely:

1.  **Seamless Claim on First Login / Forgot Password**:
    *   If a user tries to log in with an existing email that does not yet exist in Firebase Auth:
        *   The frontend notifies them: *"We've upgraded CityDeals to a more secure system. Please set a password or sign in with Google."*
        *   Clicking **"Send Password Reset Email"** calls `sendPasswordResetEmail(auth, email)` which creates the Firebase Auth user record and emails an official, secure reset link.
    *   Alternatively, merchants can immediately click **"Sign in with Google"** using their registered Gmail address.
2.  **Account Linking by Email & ID**:
    *   When the user signs in via Firebase Auth, the backend middleware matches their Firestore user profile by `email` and updates their `userId` to their Firebase UID, instantly restoring all previously created shops, products, and offers.
3.  **Password Reset Experience**:
    *   Users receive an official Google Firebase password-reset email with a secure, one-time link.
    *   They set their new password on the secure Firebase portal and are redirected back to CityDeals.

---

## 6. Security, Rate Limiting & Backup Strategy

1.  **Backend Token Verification**:
    ```typescript
    async function verifyAuth(req: Request, res: Response, next: NextFunction) {
      const authHeader = req.headers.authorization;
      if (!authHeader?.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing or malformed authorization token.' });
      }
      const token = authHeader.split('Bearer ')[1];
      try {
        const decoded = await authAdmin.verifyIdToken(token);
        (req as any).user = decoded;
        next();
      } catch (err) {
        return res.status(401).json({ error: 'Invalid or expired authentication session.' });
      }
    }
    ```
2.  **Strict Admin Authorization**:
    *   Admin access requires `decoded.uid` to exist in `/admins/{uid}` in Firestore OR `decoded.email` to match `faizalsheikh2006@gmail.com` or `admin@citydeals.in`.
    *   Self-registration as admin is impossible.
3.  **Rate Limiting**:
    *   Auth routes: 15 attempts / 15 minutes per IP (`authLimiter`).
    *   Password reset: 5 attempts / hour per IP (`passwordResetLimiter`).
    *   Order checkout: 40 checkouts / hour per IP (`ordersLimiter`).
4.  **Session Revocation**:
    *   Calling `authAdmin.revokeRefreshTokens(uid)` on password reset, role revocation, or security alerts.

---

## 7. Comprehensive Testing Checklist

- [x] **Build & Bundle**: `npm run build` succeeds without bundle errors.
- [x] **Type Check**: `tsc --noEmit` returns 0 errors.
- [x] **Server Initialization**: `server.ts` boots and connects to Firestore without crashing.
- [x] **Public Directory Browsing**:
  - [x] `GET /api/offers` returns live verified deals from Firestore.
  - [x] `GET /api/businesses` returns 9 shops from Firestore.
  - [x] `GET /api/products` returns 8 catalog products.
- [x] **Authentication Flow**:
  - [x] New customer registration via Firebase Auth & password fallback.
  - [x] Login with Email & Password.
  - [x] Login with Google OAuth via `signInWithGoogle()`.
  - [x] Password reset recovery triggers native Firebase & secure server link.
- [x] **Merchant Capabilities**:
  - [x] Merchant can view only their own offers and orders.
  - [x] Merchant cannot modify another merchant's product catalog.
- [x] **Admin Console**:
  - [x] Admin can approve or reject pending offers with feedback.
  - [x] Audit logs recorded in Firestore.
- [x] **Shopping & Checkout**:
  - [x] Single-shop cart checkout completes and updates inventory in Firestore.
- [x] **Local Storage Features**:
  - [x] Recent Searches dropdown and quick chips continue functioning without regression.

---

## 8. Implementation Stages Status: Complete

- [x] **Stage 1**: Installed `firebase-admin` and initialized backend Firestore/Auth singletons.
- [x] **Stage 2**: Connected all read endpoints (`/api/offers`, `/api/businesses`, `/api/products`, `/api/config`) to Firestore collections.
- [x] **Stage 3**: Connected write endpoints (`/api/orders`, `/api/merchant/products`, `/api/merchant/business`, `/api/merchant/orders/:id/status`, `/api/admin/*`) with Firestore persistence and Firebase ID token verification.
- [x] **Stage 4**: Updated `AuthModal.tsx` and `AppContext.tsx` with Google Sign-in and Firebase password recovery flows.
- [x] **Stage 5**: Completed end-to-end type checking (`tsc --noEmit`) and Vite compilation with 0 errors. Dev server restarted and confirmed healthy.
