// server.ts
import express from "express";
import fs2 from "fs";
import path2 from "path";
import crypto from "crypto";
import zlib from "zlib";
import { fileURLToPath as fileURLToPath2 } from "url";
import rateLimit from "express-rate-limit";

// server/firestore.ts
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { initializeApp, getApps, getApp } from "firebase/app";
import {
  initializeFirestore,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  runTransaction
} from "firebase/firestore";
import { initializeApp as initAdminApp, getApps as getAdminApps } from "firebase-admin/app";
import { getAuth as getAdminAuth } from "firebase-admin/auth";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var possibleConfigPaths = [
  path.join(process.cwd(), "firebase-applet-config.json"),
  path.join(__dirname, "firebase-applet-config.json"),
  path.join(__dirname, "..", "firebase-applet-config.json")
];
var configPath = possibleConfigPaths.find((p) => fs.existsSync(p));
if (!configPath) {
  throw new Error("firebase-applet-config.json not found in root directory");
}
var firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
var clientApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
var firestore = initializeFirestore(
  clientApp,
  {
    ignoreUndefinedProperties: true
  },
  firebaseConfig.firestoreDatabaseId
);
var adminApp = getAdminApps().length > 0 ? getAdminApps()[0] : initAdminApp({ projectId: firebaseConfig.projectId });
var adminAuth = getAdminAuth(adminApp);
console.log(`\u{1F525} Connected server to Firestore database: [${firebaseConfig.firestoreDatabaseId}] in project [${firebaseConfig.projectId}]`);

// server/firestoreStore.ts
function sanitizeForFirestore(obj) {
  const result = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== void 0) {
      if (value !== null && typeof value === "object" && !Array.isArray(value) && !(value instanceof Date)) {
        result[key] = sanitizeForFirestore(value);
      } else {
        result[key] = value;
      }
    }
  }
  return result;
}
async function persistToFirestore(collectionName, docId, data) {
  try {
    const cleanData = sanitizeForFirestore(data);
    await setDoc(doc(firestore, collectionName, docId), cleanData, { merge: true });
  } catch (err) {
    console.error(`[Firestore Error] Failed to persist to ${collectionName}/${docId}:`, err.message);
    throw err;
  }
}
async function removeFromFirestore(collectionName, docId) {
  try {
    await deleteDoc(doc(firestore, collectionName, docId));
  } catch (err) {
    console.error(`[Firestore Error] Failed to delete from ${collectionName}/${docId}:`, err.message);
    throw err;
  }
}
async function loadCollectionsFromFirestore() {
  const result = {};
  const targetCollections = [
    "businesses",
    "offers",
    "products",
    "orders",
    "categories",
    "cities",
    "districts",
    "promotionPackages",
    "promotionRequests",
    "verificationRequests",
    "reports",
    "dealSuggestions",
    "auditLogs",
    "users"
  ];
  const fetchWithTimeout = async (col, ms = 8e3) => {
    return Promise.race([
      getDocs(collection(firestore, col)),
      new Promise(
        (_, reject) => setTimeout(() => reject(new Error(`Timeout fetching ${col}`)), ms)
      )
    ]);
  };
  for (const col of targetCollections) {
    try {
      const snap = await fetchWithTimeout(col);
      result[col] = snap?.docs ? snap.docs.map((d) => ({ ...d.data(), id: d.id })) : [];
    } catch {
      result[col] = void 0;
    }
  }
  return result;
}

// server.ts
import { createServer as createViteServer } from "vite";
var __filename2 = fileURLToPath2(import.meta.url);
var __dirname2 = path2.dirname(__filename2);
var PORT = 3e3;
var DATA_DIR = path2.join(__dirname2, "data");
var DB_FILE = path2.join(DATA_DIR, "citydeals_db.json");
var DEFAULT_CATEGORIES = [
  {
    id: "cafes-restaurants",
    name: "Cafes & Restaurants",
    slug: "cafes-restaurants",
    iconName: "Utensils",
    description: "Local bistros, Assamese thali houses, bakeries, coffee rooms & dining spots",
    color: "from-amber-500 to-orange-600"
  },
  {
    id: "fashion",
    name: "Fashion & Boutiques",
    slug: "fashion",
    iconName: "Shirt",
    description: "Mekhela Sador showrooms, ethnic boutiques, apparel, footwear & menswear",
    color: "from-rose-500 to-pink-600"
  },
  {
    id: "grocery",
    name: "Grocery Stores",
    slug: "grocery",
    iconName: "ShoppingBag",
    description: "Neighborhood supermarkets, organic spice merchants, tea depots & local farm outlets",
    color: "from-emerald-500 to-teal-600"
  },
  {
    id: "electronics",
    name: "Electronics Shops",
    slug: "electronics",
    iconName: "Smartphone",
    description: "Mobile phone stores, accessory dealers, home electronics & repair workshops",
    color: "from-blue-500 to-indigo-600"
  },
  {
    id: "beauty-salons",
    name: "Beauty & Salons",
    slug: "beauty-salons",
    iconName: "Sparkles",
    description: "Hair salons, spas, bridal makeover studios & grooming parlours",
    color: "from-purple-500 to-fuchsia-600"
  },
  {
    id: "home-lifestyle",
    name: "Home & Lifestyle",
    slug: "home-lifestyle",
    iconName: "Home",
    description: "Assam cane & bamboo craft showrooms, home decor, cookware & lifestyle shops",
    color: "from-amber-600 to-yellow-600"
  },
  {
    id: "services",
    name: "Services & Repairs",
    slug: "services",
    iconName: "Wrench",
    description: "Automobile care, two-wheeler servicing, tailoring, printing & appliance repairs",
    color: "from-cyan-500 to-blue-600"
  },
  {
    id: "other-shops",
    name: "Other Local Shops",
    slug: "other-shops",
    iconName: "Store",
    description: "Bookstores, stationery, fitness centers, sports gear & specialty retailers",
    color: "from-slate-600 to-slate-800"
  }
];
var DEFAULT_CITIES = [
  {
    id: "dibrugarh",
    name: "Dibrugarh",
    state: "Assam",
    districtId: "dibrugarh",
    districtName: "Dibrugarh",
    isLaunchMarket: true,
    localities: [
      "Dibrugarh Town",
      "Chowkidinghee",
      "Chabua",
      "Naharkatia",
      "Duliajan",
      "Moran",
      "Tengakhat",
      "Lahowal",
      "Khowang",
      "Joypur",
      "Thana Chariali",
      "Graham Bazar",
      "HS Road",
      "Boiragimoth",
      "Mancotta Road",
      "Phoolbagan",
      "Amolapatty",
      "Naliapool",
      "Gabharupathar",
      "Khalihamari",
      "Jalan Nagar"
    ]
  },
  {
    id: "tinsukia",
    name: "Tinsukia",
    state: "Assam",
    districtId: "tinsukia",
    districtName: "Tinsukia",
    isLaunchMarket: true,
    localities: [
      "Tinsukia Town",
      "Doomdooma",
      "Dhola",
      "Makum",
      "Digboi",
      "Margherita",
      "Daily Bazar",
      "GNB Road",
      "Chirwapatty",
      "Parbotia"
    ]
  },
  {
    id: "guwahati",
    name: "Guwahati",
    state: "Assam",
    districtId: "kamrup_metro",
    districtName: "Kamrup Metro",
    isLaunchMarket: false,
    localities: ["GS Road", "Paltan Bazar", "Pan Bazar", "Fancy Bazar", "Ulubari"]
  },
  {
    id: "jorhat",
    name: "Jorhat",
    state: "Assam",
    districtId: "jorhat",
    districtName: "Jorhat",
    isLaunchMarket: false,
    localities: ["AT Road", "Gar-Ali", "KB Road", "Barbheta"]
  }
];
var DEFAULT_DISTRICTS = [
  {
    id: "dibrugarh",
    name: "Dibrugarh",
    state: "Assam",
    isActive: true,
    isLaunchMarket: true,
    localities: [
      { id: "dibrugarh-town", name: "Dibrugarh Town", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4835, longitude: 94.9112 },
      { id: "chowkidinghee", name: "Chowkidinghee", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4695, longitude: 94.9178 },
      { id: "chabua", name: "Chabua", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4789, longitude: 95.1764 },
      { id: "naharkatia", name: "Naharkatia", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.2817, longitude: 95.2575 },
      { id: "duliajan", name: "Duliajan", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.3592, longitude: 95.3211 },
      { id: "moran", name: "Moran", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.1856, longitude: 94.9317 },
      { id: "tengakhat", name: "Tengakhat", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4128, longitude: 95.1483 },
      { id: "lahowal", name: "Lahowal", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4583, longitude: 95.0089 },
      { id: "khowang", name: "Khowang", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.2833, longitude: 94.9167 },
      { id: "joypur", name: "Joypur", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.2667, longitude: 95.3833 },
      { id: "thana-chariali", name: "Thana Chariali", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4835, longitude: 94.9112 },
      { id: "graham-bazar", name: "Graham Bazar", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4782, longitude: 94.9048 },
      { id: "hs-road", name: "HS Road", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4851, longitude: 94.9135 },
      { id: "boiragimoth", name: "Boiragimoth", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.465, longitude: 94.921 },
      { id: "mancotta-road", name: "Mancotta Road", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4612, longitude: 94.913 },
      { id: "phoolbagan", name: "Phoolbagan", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.488, longitude: 94.916 },
      { id: "amolapatty", name: "Amolapatty", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.476, longitude: 94.918 },
      { id: "naliapool", name: "Naliapool", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.4895, longitude: 94.908 },
      { id: "gabharupathar", name: "Gabharupathar", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.458, longitude: 94.931 },
      { id: "khalihamari", name: "Khalihamari", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.48, longitude: 94.9195 },
      { id: "jalan-nagar", name: "Jalan Nagar", districtId: "dibrugarh", districtName: "Dibrugarh", state: "Assam", isActive: true, latitude: 27.452, longitude: 94.901 }
    ]
  },
  {
    id: "tinsukia",
    name: "Tinsukia",
    state: "Assam",
    isActive: true,
    isLaunchMarket: true,
    localities: [
      { id: "tinsukia-town", name: "Tinsukia Town", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.4922, longitude: 95.3468 },
      { id: "doomdooma", name: "Doomdooma", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.5683, longitude: 95.5686 },
      { id: "dhola", name: "Dhola", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.7681, longitude: 95.6022 },
      { id: "makum", name: "Makum", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.5028, longitude: 95.4528 },
      { id: "digboi", name: "Digboi", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.3822, longitude: 95.6289 },
      { id: "margherita", name: "Margherita", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.2847, longitude: 95.6833 },
      { id: "daily-bazar", name: "Daily Bazar", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.4935, longitude: 95.3482 },
      { id: "gnb-road", name: "GNB Road", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.491, longitude: 95.345 },
      { id: "chirwapatty", name: "Chirwapatty", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.496, longitude: 95.352 },
      { id: "parbotia", name: "Parbotia", districtId: "tinsukia", districtName: "Tinsukia", state: "Assam", isActive: true, latitude: 27.489, longitude: 95.339 }
    ]
  }
];
var DEFAULT_PROMOTION_PACKAGES = [
  {
    id: "pkg-starter",
    name: "Starter",
    tier: "starter",
    priceInr: 99,
    price: 99,
    durationDays: 3,
    description: "Introductory 3-day promotion to boost visibility and weekend footfall in your locality.",
    badge: "Starter Boost",
    features: [
      "Priority ranking in category results",
      'Highlighted "Promoted Offer" badge',
      "Direct WhatsApp and Call contact buttons",
      "3 days active duration"
    ]
  },
  {
    id: "pkg-popular",
    name: "Popular",
    tier: "popular",
    priceInr: 199,
    price: 199,
    durationDays: 7,
    recommended: true,
    description: "Our most popular weekly campaign for steady store footfall and high customer conversion.",
    badge: "Most Popular",
    features: [
      "Top priority ranking in category search",
      'Prominent "Promoted Deal" badge on offer card',
      "Pinned visibility across local area feed",
      "7 days active duration"
    ]
  },
  {
    id: "pkg-monthly",
    name: "Monthly",
    tier: "monthly",
    priceInr: 499,
    price: 499,
    durationDays: 30,
    description: "Full 30-day continuous presence across locality feed with ongoing merchant promotion.",
    badge: "Best Monthly Value",
    features: [
      "Top placement across locality and category",
      "Promoted badge with continuous search boost",
      "Verified local shop trust recognition",
      "30 days active duration"
    ]
  },
  {
    id: "pkg-homepage-featured",
    name: "Homepage Featured",
    tier: "homepage_featured",
    priceInr: 999,
    price: 999,
    durationDays: 30,
    description: "Prime homepage showcase banner visible to all citizens and shoppers visiting CityDeals.",
    badge: "Maximum City-Wide Reach",
    features: [
      "Prime homepage featured hero placement",
      'Dedicated "Featured Sponsor" badge',
      "District-wide exposure across all categories",
      "30 days active duration"
    ]
  }
];
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}
function verifyPassword(password, hash, salt) {
  try {
    const calculated = crypto.scryptSync(password, salt, 64);
    const stored = Buffer.from(hash, "hex");
    if (calculated.length !== stored.length) return false;
    return crypto.timingSafeEqual(calculated, stored);
  } catch {
    return false;
  }
}
function generateSecureToken() {
  return crypto.randomBytes(32).toString("hex");
}
function sanitizeUser(user) {
  const { passwordHash: _hash, salt: _salt, ...safeUser } = user;
  return safeUser;
}
function generateReferralCode(name, id) {
  const cleanPrefix = (name.replace(/[^a-zA-Z]/g, "").slice(0, 4) || "CITY").toUpperCase();
  const uniqueHex = crypto.createHash("md5").update(id + name).digest("hex").slice(0, 4).toUpperCase();
  return `${cleanPrefix}${uniqueHex}`;
}
var DEFAULT_REFERRAL_CONFIG = {
  enabled: true,
  programName: "CityDeals Community Ambassador Program",
  rewardType: "community_badge",
  rewardDescription: "Early Pioneer Community Badge and Priority Local Partner status. No cash rewards or financial payouts are promised or distributed during the early access phase.",
  maxReferralsPerUser: 100,
  termsAndConditions: "Strictly one account per individual or local business. Duplicate signups or self-referrals are automatically rejected.",
  qualifyingAction: "registration",
  isActive: true,
  campaignName: "CityDeals Community Ambassador Program",
  rulesDescription: "Invite friends, shoppers, and local retailers to CityDeals. Every genuine account registration verified on our platform counts toward your ambassador tier."
};
var ASSAM_COORDS = {
  // Tinsukia District
  "Tinsukia Town": { lat: 27.4922, lng: 95.3468 },
  "Doomdooma": { lat: 27.5683, lng: 95.5686 },
  "Dhola": { lat: 27.7681, lng: 95.6022 },
  "Makum": { lat: 27.5028, lng: 95.4528 },
  "Digboi": { lat: 27.3822, lng: 95.6289 },
  "Margherita": { lat: 27.2847, lng: 95.6833 },
  "Daily Bazar": { lat: 27.4935, lng: 95.3482 },
  "GNB Road": { lat: 27.491, lng: 95.345 },
  "Chirwapatty": { lat: 27.496, lng: 95.352 },
  "Parbotia": { lat: 27.489, lng: 95.339 },
  // Dibrugarh District
  "Dibrugarh Town": { lat: 27.4835, lng: 94.9112 },
  "Chowkidinghee": { lat: 27.4695, lng: 94.9178 },
  "Chabua": { lat: 27.4789, lng: 95.1764 },
  "Naharkatia": { lat: 27.2817, lng: 95.2575 },
  "Duliajan": { lat: 27.3592, lng: 95.3211 },
  "Moran": { lat: 27.1856, lng: 94.9317 },
  "Tengakhat": { lat: 27.4128, lng: 95.1483 },
  "Lahowal": { lat: 27.4583, lng: 95.0089 },
  "Khowang": { lat: 27.2833, lng: 94.9167 },
  "Joypur": { lat: 27.2667, lng: 95.3833 },
  "Thana Chariali": { lat: 27.4835, lng: 94.9112 },
  "Graham Bazar": { lat: 27.4782, lng: 94.9048 },
  "HS Road": { lat: 27.4851, lng: 94.9135 },
  "New Market": { lat: 27.4851, lng: 94.9135 },
  "Boiragimoth": { lat: 27.465, lng: 94.921 },
  "Mancotta Road": { lat: 27.4612, lng: 94.913 },
  "Phoolbagan": { lat: 27.488, lng: 94.916 },
  "Amolapatty": { lat: 27.476, lng: 94.918 },
  "Naliapool": { lat: 27.4895, lng: 94.908 },
  "Gabharupathar": { lat: 27.458, lng: 94.931 },
  "Khalihamari": { lat: 27.48, lng: 94.9195 },
  "Jalan Nagar": { lat: 27.452, lng: 94.901 }
};
function getLocalityCoordinates(locality, district) {
  if (locality) {
    const match = Object.entries(ASSAM_COORDS).find(
      ([k]) => k.toLowerCase() === locality.trim().toLowerCase()
    );
    if (match) return match[1];
  }
  if (district && district.toLowerCase().includes("tinsukia")) {
    return { lat: 27.4922, lng: 95.3468 };
  }
  return { lat: 27.4835, lng: 94.9112 };
}
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}
function getCleanProductionData() {
  const saltAdmin = crypto.randomBytes(16).toString("hex");
  const adminPassword = process.env.ADMIN_INITIAL_PASSWORD || "Admin@12345";
  const ownerEmail = "citydeals.discoverlocal@gmail.com";
  const ownerName = "CityDeals Administrator";
  const ownerId = "usr-admin-founder";
  const adminReferralCode = generateReferralCode(ownerName, ownerId);
  const users = [
    {
      id: ownerId,
      name: ownerName,
      email: ownerEmail,
      role: "admin",
      phone: "+91 98540 00000",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      passwordHash: hashPassword(adminPassword, saltAdmin),
      salt: saltAdmin,
      isDemo: false,
      referralCode: adminReferralCode,
      referralCount: 0
    }
  ];
  return {
    users,
    sessions: [],
    businesses: [],
    offers: [],
    categories: DEFAULT_CATEGORIES,
    cities: DEFAULT_CITIES,
    districts: DEFAULT_DISTRICTS,
    promotionPackages: DEFAULT_PROMOTION_PACKAGES,
    promotionRequests: [],
    verificationRequests: [],
    reports: [],
    auditLogs: [],
    referrals: [],
    referralConfig: DEFAULT_REFERRAL_CONFIG,
    dealSuggestions: [],
    products: [],
    orders: []
  };
}
function getSampleData() {
  const saltAdmin = crypto.randomBytes(16).toString("hex");
  const saltMerchant1 = crypto.randomBytes(16).toString("hex");
  const saltMerchant2 = crypto.randomBytes(16).toString("hex");
  const saltPublic1 = crypto.randomBytes(16).toString("hex");
  const users = [
    {
      id: "usr-admin-1",
      name: "CityDeals Moderation Team",
      email: "admin@citydeals.in",
      role: "admin",
      phone: "+91 98540 12345",
      createdAt: "2026-09-01T10:00:00Z",
      passwordHash: hashPassword("Admin@12345", saltAdmin),
      salt: saltAdmin
    },
    {
      id: "usr-merchant-1",
      name: "Bhaskar Jyoti Baruah",
      email: "heritage.silks@gmail.com",
      role: "merchant",
      phone: "+91 94350 88210",
      businessId: "biz-1",
      createdAt: "2026-09-10T11:00:00Z",
      passwordHash: hashPassword("Merchant@12345", saltMerchant1),
      salt: saltMerchant1
    },
    {
      id: "usr-merchant-2",
      name: "Anupama Chetia",
      email: "chai.chomp@gmail.com",
      role: "merchant",
      phone: "+91 88760 33419",
      businessId: "biz-2",
      createdAt: "2026-09-15T09:30:00Z",
      passwordHash: hashPassword("Merchant@12345", saltMerchant2),
      salt: saltMerchant2
    },
    {
      id: "usr-public-1",
      name: "Rohan Sharma",
      email: "shopper@citydeals.in",
      role: "public",
      createdAt: "2026-10-01T14:20:00Z",
      passwordHash: hashPassword("Shopper@12345", saltPublic1),
      salt: saltPublic1
    }
  ];
  const businesses = [
    {
      id: "biz-1",
      merchantId: "usr-merchant-1",
      name: "Heritage Silks of Assam",
      category: "fashion",
      city: "Dibrugarh",
      locality: "HS Road",
      address: "Shop 14-16, New Market Complex, HS Road, Dibrugarh",
      landmark: "Near Bata Showroom, HS Road",
      phone: "+91 94350 88210",
      whatsapp: "+919435088210",
      email: "heritage.silks@gmail.com",
      description: "Physical handloom emporium specializing in authentic pure Muga, Paat, and Eri silk Mekhela Sador handwoven by master weavers.",
      logoUrl: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80",
      openingHours: "10:00 AM \u2013 8:30 PM (Mon\u2013Sat)",
      status: "approved",
      verified: true,
      isFeatured: true,
      createdAt: "2026-09-10T11:05:00Z"
    },
    {
      id: "biz-2",
      merchantId: "usr-merchant-2",
      name: "Chai & Chomp Artisan Bistro",
      category: "cafes-restaurants",
      city: "Dibrugarh",
      locality: "Graham Bazar",
      address: "Plot 42, Riverview Lane, Graham Bazar, Dibrugarh",
      landmark: "Opposite State Bank of India, Graham Bazar Branch",
      phone: "+91 88760 33419",
      whatsapp: "+918876033419",
      email: "chai.chomp@gmail.com",
      description: "Cozy dine-in cafe and eatery overlooking the river. Known for single-estate Upper Assam smoked teas, hand-stretched pizzas, and fresh baked goodies.",
      logoUrl: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=600&q=80",
      openingHours: "11:00 AM \u2013 10:30 PM (Daily)",
      status: "approved",
      verified: true,
      isFeatured: true,
      createdAt: "2026-09-15T09:40:00Z"
    },
    {
      id: "biz-3",
      merchantId: "usr-merchant-3",
      name: "NorthEast Mobile & Gadget Hub",
      category: "electronics",
      city: "Dibrugarh",
      locality: "Chowkidinghee",
      address: "Shop 5, City Centre Plaza, Chowkidinghee, Dibrugarh",
      landmark: "Near Chowkidinghee Bus Terminus",
      phone: "+91 97060 44221",
      whatsapp: "+919706044221",
      email: "nemobilehub@gmail.com",
      description: "Local electronics retail and service store offering brand smartphone accessories, tempered glass replacements, and certified gadget repair services.",
      logoUrl: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=600&q=80",
      openingHours: "9:30 AM \u2013 8:00 PM (Mon\u2013Sat)",
      status: "approved",
      verified: true,
      createdAt: "2026-09-18T10:00:00Z"
    },
    {
      id: "biz-4",
      merchantId: "usr-merchant-4",
      name: "Dibru Fresh Organics & Spices",
      category: "grocery",
      city: "Dibrugarh",
      locality: "Phoolbagan",
      address: "Phoolbagan Main Market, Dibrugarh",
      landmark: "Beside Phoolbagan Post Office",
      phone: "+91 94351 12900",
      whatsapp: "+919435112900",
      email: "dibru.organics@gmail.com",
      description: "Physical grocery and indigenous spice mart carrying pure wood-pressed mustard oils, authentic Lakadong turmeric, organic grains, and regional farm goods.",
      logoUrl: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80",
      openingHours: "7:30 AM \u2013 9:00 PM (Daily)",
      status: "approved",
      verified: true,
      createdAt: "2026-09-20T12:00:00Z"
    },
    {
      id: "biz-5",
      merchantId: "usr-merchant-5",
      name: "Lotus Glow Wellness & Salon",
      category: "beauty-salons",
      city: "Dibrugarh",
      locality: "Amolapatty",
      address: "First Floor, Shanti Complex, Amolapatty, Dibrugarh",
      landmark: "Near DHSK College Gate",
      phone: "+91 99540 77123",
      whatsapp: "+919954077123",
      email: "lotusglow.dbr@gmail.com",
      description: "Neighborhood unisex salon and makeover parlor offering bridal styling, herbal scalp treatments, facials, and hair care by trained specialists.",
      logoUrl: "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80",
      openingHours: "10:00 AM \u2013 7:30 PM (Closed Tuesdays)",
      status: "approved",
      verified: true,
      createdAt: "2026-09-22T14:00:00Z"
    },
    {
      id: "biz-6",
      merchantId: "usr-merchant-6",
      name: "Speedy Wheels Auto Care",
      category: "services",
      city: "Dibrugarh",
      locality: "Boiragimoth",
      address: "Near Old Railway Station Road, Boiragimoth, Dibrugarh",
      landmark: "Opposite Boiragimoth Namghar",
      phone: "+91 91011 22334",
      whatsapp: "+919101122334",
      email: "speedywheels.dbr@gmail.com",
      description: "Physical two-wheeler workshop providing mechanical checkups, foam washing, oil changes, tire puncture services, and general tune-ups.",
      logoUrl: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=600&q=80",
      openingHours: "8:30 AM \u2013 7:00 PM (Mon\u2013Sat)",
      status: "approved",
      verified: true,
      createdAt: "2026-09-25T16:00:00Z"
    },
    {
      id: "biz-7",
      merchantId: "usr-merchant-7",
      name: "Assam Cane & Craft Emporium",
      category: "home-lifestyle",
      city: "Dibrugarh",
      locality: "Gabharupathar",
      address: "Gabharupathar Bypass Road, Dibrugarh",
      landmark: "Near Bypass Flyover Junction",
      phone: "+91 98642 99001",
      whatsapp: "+919864299001",
      email: "cane.crafts@gmail.com",
      description: "Artisanal furniture showroom featuring sustainable Assam cane chairs, bamboo lighting, woven baskets, and hand-carved home decor pieces.",
      logoUrl: "https://images.unsplash.com/photo-1538688525198-9b88f6f53126?auto=format&fit=crop&w=600&q=80",
      openingHours: "10:00 AM \u2013 8:00 PM (Mon\u2013Sat)",
      status: "pending",
      // Pending shop for admin review
      verified: false,
      createdAt: "2026-09-28T11:00:00Z"
    }
  ];
  const offers = [
    // Multiple offers at Heritage Silks of Assam (biz-1)
    {
      id: "off-101",
      businessId: "biz-1",
      merchantId: "usr-merchant-1",
      merchantEmail: "heritage.silks@gmail.com",
      shopName: "Heritage Silks of Assam",
      city: "Dibrugarh",
      locality: "HS Road",
      address: "Shop 14-16, New Market Complex, HS Road, Dibrugarh",
      landmark: "Near Bata Showroom, HS Road",
      category: "fashion",
      headline: "Flat 25% Off on All Traditional Assamese Mekhela Sador & Ethnic Wear",
      discountValue: "25% OFF IN-STORE",
      description: "Visit our HS Road showroom to explore our festive handloom collection. Enjoy a flat 25% discount across pure Paat and Eri silk Mekhela Sador sets, handwoven cotton kurtas, and traditional gamosas.",
      terms: [
        "Visit our HS Road physical showroom to browse the collection and redeem.",
        "Mention or display this CityDeals listing at the cash counter before billing.",
        "Applicable on in-store purchases of \u20B92,500 and above.",
        "Not combinable with clearance rack discounts.",
        "Exchanges valid within 7 days with store receipt."
      ],
      contactPhone: "+91 94350 88210",
      contactWhatsapp: "+919435088210",
      locationUrl: "https://maps.google.com/?q=HS+Road+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80",
      openingHours: "10:00 AM \u2013 8:30 PM (Mon\u2013Sat)",
      validFrom: "2026-10-01T00:00:00Z",
      validUntil: "2026-11-15T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: true,
      sponsorTier: "featured",
      sponsorExpiry: "2026-11-10T23:59:59Z",
      viewsCount: 642,
      clicksCount: 88,
      createdAt: "2026-10-01T10:00:00Z",
      updatedAt: "2026-10-02T12:00:00Z"
    },
    {
      id: "off-101-b",
      businessId: "biz-1",
      merchantId: "usr-merchant-1",
      merchantEmail: "heritage.silks@gmail.com",
      shopName: "Heritage Silks of Assam",
      city: "Dibrugarh",
      locality: "HS Road",
      address: "Shop 14-16, New Market Complex, HS Road, Dibrugarh",
      landmark: "Near Bata Showroom, HS Road",
      category: "fashion",
      headline: "Special Festive Bonanza: Free Handwoven Cotton Stole on Any Silk Sador Set",
      discountValue: "FREE GIFT ON PURCHASE",
      description: "Receive a complimentary hand-embroidered Assam cotton stole or traditional gamosa with any pure silk bridal or festive Mekhela Sador purchased in-store.",
      terms: [
        "Available exclusively for in-store walk-in shoppers.",
        "One complimentary stole per qualifying bill.",
        "Valid while seasonal stock lasts at our HS Road branch."
      ],
      contactPhone: "+91 94350 88210",
      contactWhatsapp: "+919435088210",
      locationUrl: "https://maps.google.com/?q=HS+Road+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80",
      openingHours: "10:00 AM \u2013 8:30 PM (Mon\u2013Sat)",
      validFrom: "2026-10-05T00:00:00Z",
      validUntil: "2026-11-20T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: false,
      viewsCount: 310,
      clicksCount: 42,
      createdAt: "2026-10-05T10:00:00Z",
      updatedAt: "2026-10-05T10:00:00Z"
    },
    // Multiple offers at Chai & Chomp Bistro (biz-2)
    {
      id: "off-102",
      businessId: "biz-2",
      merchantId: "usr-merchant-2",
      merchantEmail: "chai.chomp@gmail.com",
      shopName: "Chai & Chomp Artisan Bistro",
      city: "Dibrugarh",
      locality: "Graham Bazar",
      address: "Plot 42, Riverview Lane, Graham Bazar, Dibrugarh",
      landmark: "Opposite State Bank of India, Graham Bazar",
      category: "cafes-restaurants",
      headline: "Buy 1 Get 1 Free on All Woodfired Pizzas & Fresh Pastas",
      discountValue: "BUY 1 GET 1 ON MENU",
      description: "Dine in with family or friends at our Graham Bazar cafe. Order any 10-inch hand-stretched pizza or signature pasta and get another of equal or lesser value completely free!",
      terms: [
        "Valid on dine-in and counter takeaway at our Graham Bazar cafe.",
        "Applicable Monday to Friday from 12:00 PM to 7:00 PM.",
        "Show this CityDeals offer screen to the server when placing your order.",
        "One redemption per table / dining group."
      ],
      contactPhone: "+91 88760 33419",
      contactWhatsapp: "+918876033419",
      locationUrl: "https://maps.google.com/?q=Graham+Bazar+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
      openingHours: "11:00 AM \u2013 10:30 PM (Daily)",
      validFrom: "2026-10-05T00:00:00Z",
      validUntil: "2026-11-20T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: true,
      sponsorTier: "spotlight",
      sponsorExpiry: "2026-11-05T23:59:59Z",
      viewsCount: 1204,
      clicksCount: 215,
      createdAt: "2026-10-05T14:30:00Z",
      updatedAt: "2026-10-06T09:15:00Z"
    },
    {
      id: "off-102-b",
      businessId: "biz-2",
      merchantId: "usr-merchant-2",
      merchantEmail: "chai.chomp@gmail.com",
      shopName: "Chai & Chomp Artisan Bistro",
      city: "Dibrugarh",
      locality: "Graham Bazar",
      address: "Plot 42, Riverview Lane, Graham Bazar, Dibrugarh",
      landmark: "Opposite State Bank of India, Graham Bazar",
      category: "cafes-restaurants",
      headline: "Evening High Tea: Complimentary Smoked Tea Cooler with Any Bakery Platter",
      discountValue: "FREE TEA COOLER",
      description: "Relax by the river breeze between 4:00 PM and 6:30 PM. Order any dessert or savory snack platter and enjoy a refreshing Upper Assam cold brew on the house.",
      terms: [
        "Dine-in only at the Graham Bazar outlet.",
        "Valid every day between 4:00 PM to 6:30 PM."
      ],
      contactPhone: "+91 88760 33419",
      contactWhatsapp: "+918876033419",
      locationUrl: "https://maps.google.com/?q=Graham+Bazar+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80",
      openingHours: "11:00 AM \u2013 10:30 PM (Daily)",
      validFrom: "2026-10-08T00:00:00Z",
      validUntil: "2026-11-25T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: false,
      viewsCount: 420,
      clicksCount: 56,
      createdAt: "2026-10-08T12:00:00Z",
      updatedAt: "2026-10-08T12:00:00Z"
    },
    // NorthEast Mobile (biz-3)
    {
      id: "off-103",
      businessId: "biz-3",
      merchantId: "usr-merchant-3",
      merchantEmail: "nemobilehub@gmail.com",
      shopName: "NorthEast Mobile & Gadget Hub",
      city: "Dibrugarh",
      locality: "Chowkidinghee",
      address: "Shop 5, City Centre Plaza, Chowkidinghee, Dibrugarh",
      landmark: "Near Chowkidinghee Bus Terminus",
      category: "electronics",
      headline: "Up to 40% Off on Premium Screen Guards & Certified Fast Charging Adapters",
      discountValue: "UP TO 40% OFF ACCESSORIES",
      description: "Visit our Chowkidinghee store for instant bubble-free tempered glass installation, phone cases, and genuine fast type-C charging adapters.",
      terms: [
        "Applicable across all in-stock mobile accessories and tempered glass.",
        "Includes complimentary bubble-free installation by our store technicians.",
        "Present the CityDeals listing at our Chowkidinghee store counter."
      ],
      contactPhone: "+91 97060 44221",
      contactWhatsapp: "+919706044221",
      locationUrl: "https://maps.google.com/?q=Chowkidinghee+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=800&q=80",
      openingHours: "9:30 AM \u2013 8:00 PM (Mon\u2013Sat)",
      validFrom: "2026-10-10T00:00:00Z",
      validUntil: "2026-10-31T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: true,
      sponsorTier: "boost",
      sponsorExpiry: "2026-10-24T23:59:59Z",
      viewsCount: 410,
      clicksCount: 62,
      createdAt: "2026-10-09T16:00:00Z",
      updatedAt: "2026-10-10T11:00:00Z"
    },
    // Dibru Fresh Organics (biz-4)
    {
      id: "off-104",
      businessId: "biz-4",
      merchantId: "usr-merchant-4",
      merchantEmail: "dibru.organics@gmail.com",
      shopName: "Dibru Fresh Organics & Spices",
      city: "Dibrugarh",
      locality: "Phoolbagan",
      address: "Phoolbagan Main Market, Dibrugarh",
      landmark: "Beside Phoolbagan Post Office",
      category: "grocery",
      headline: "Flat \u20B9150 Off on In-Store Purchases of Pure Wood-Pressed Mustard Oil & Spices",
      discountValue: "FLAT \u20B9150 OFF AT STORE",
      description: "Stock up your kitchen with natural goodness! Get flat \u20B9150 instant discount on 2-litre bottles of raw kacchi ghani mustard oil paired with organic high-curcumin Lakadong turmeric.",
      terms: [
        "Physical redemption at Phoolbagan market store.",
        "Minimum in-store basket purchase of \u20B9700.",
        "One redemption per family per week."
      ],
      contactPhone: "+91 94351 12900",
      contactWhatsapp: "+919435112900",
      locationUrl: "https://maps.google.com/?q=Phoolbagan+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80",
      openingHours: "7:30 AM \u2013 9:00 PM (Daily)",
      validFrom: "2026-10-08T00:00:00Z",
      validUntil: "2026-11-25T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: false,
      viewsCount: 388,
      clicksCount: 45,
      createdAt: "2026-10-08T11:30:00Z",
      updatedAt: "2026-10-08T11:30:00Z"
    },
    // Lotus Glow Salon (biz-5)
    {
      id: "off-105",
      businessId: "biz-5",
      merchantId: "usr-merchant-5",
      merchantEmail: "lotusglow.dbr@gmail.com",
      shopName: "Lotus Glow Wellness & Salon",
      city: "Dibrugarh",
      locality: "Amolapatty",
      address: "First Floor, Shanti Complex, Amolapatty, Dibrugarh",
      landmark: "Near DHSK College Gate",
      category: "beauty-salons",
      headline: "Festive Makeover Package: Herbal Glow Facial + Deep Conditioning Hair Spa at Special In-Salon Rate",
      discountValue: "SPECIAL SALON PACKAGE",
      description: "Pamper yourself ahead of festivities! Comprehensive in-salon package includes deep fruit cleanse facial, oxygen rejuvenation peel, botanical hair spa, and stress-relief scalp massage.",
      terms: [
        "Appointment booking by phone or WhatsApp recommended.",
        "Redeemable in person at our Amolapatty salon.",
        "Valid on all open days between 10:00 AM to 6:00 PM.",
        "Cannot be combined with bridal makeover bookings."
      ],
      contactPhone: "+91 99540 77123",
      contactWhatsapp: "+919954077123",
      locationUrl: "https://maps.google.com/?q=Amolapatty+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=800&q=80",
      openingHours: "10:00 AM \u2013 7:30 PM (Closed Tuesdays)",
      validFrom: "2026-10-02T00:00:00Z",
      validUntil: "2026-11-18T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: false,
      viewsCount: 520,
      clicksCount: 94,
      createdAt: "2026-10-02T15:00:00Z",
      updatedAt: "2026-10-03T10:00:00Z"
    },
    // Speedy Wheels (biz-6)
    {
      id: "off-106",
      businessId: "biz-6",
      merchantId: "usr-merchant-6",
      merchantEmail: "speedywheels.dbr@gmail.com",
      shopName: "Speedy Wheels Auto Care",
      city: "Dibrugarh",
      locality: "Boiragimoth",
      address: "Near Old Railway Station Road, Boiragimoth, Dibrugarh",
      landmark: "Opposite Boiragimoth Namghar",
      category: "services",
      headline: "Free 18-Point Two-Wheeler Safety Checkup & High-Pressure Foam Wash with Engine Oil Service",
      discountValue: "FREE FOAM WASH & CHECKUP",
      description: "Visit our Boiragimoth workshop to keep your bike or scooter in top condition. Purchase any branded synthetic lubricant and get a complimentary deep foam wash and 18-point brake/chain inspection.",
      terms: [
        "Physical walk-in service at our Boiragimoth garage.",
        "Engine oil charged at standard MRP based on selected brand (Castrol, Motul, Shell).",
        "Valid for all gear and gearless two-wheelers."
      ],
      contactPhone: "+91 91011 22334",
      contactWhatsapp: "+919101122334",
      locationUrl: "https://maps.google.com/?q=Boiragimoth+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=800&q=80",
      openingHours: "8:30 AM \u2013 7:00 PM (Mon\u2013Sat)",
      validFrom: "2026-10-12T00:00:00Z",
      validUntil: "2026-11-30T23:59:59Z",
      status: "approved",
      isActive: true,
      isSponsored: false,
      viewsCount: 290,
      clicksCount: 38,
      createdAt: "2026-10-12T09:00:00Z",
      updatedAt: "2026-10-12T09:00:00Z"
    },
    // PENDING OFFERS FOR ADMIN REVIEW FLOW
    {
      id: "off-pending-201",
      businessId: "biz-7",
      merchantId: "usr-merchant-7",
      merchantEmail: "cane.crafts@gmail.com",
      shopName: "Assam Cane & Craft Emporium",
      city: "Dibrugarh",
      locality: "Gabharupathar",
      address: "Gabharupathar Bypass Road, Dibrugarh",
      landmark: "Near Bypass Flyover Junction",
      category: "home-lifestyle",
      headline: "Flat 20% Off on Handcrafted Cane Armchairs & Handwoven Bamboo Ceiling Lamps",
      discountValue: "20% OFF IN-STORE",
      description: "Authentic sustainable furniture crafted from local Assam cane. Visit our Gabharupathar showroom to explore handcrafted lounge chairs, verandah sets, and artistic bamboo lamp shades.",
      terms: [
        "In-store selection at our Gabharupathar showroom.",
        "Valid on sets of 2 or more chairs.",
        "Free local home delivery within Dibrugarh municipal area.",
        "Show active CityDeals code at billing."
      ],
      contactPhone: "+91 98642 99001",
      contactWhatsapp: "+919864299001",
      locationUrl: "https://maps.google.com/?q=Gabharupathar+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1538688525198-9b88f6f53126?auto=format&fit=crop&w=800&q=80",
      openingHours: "10:00 AM \u2013 8:00 PM (Mon\u2013Sat)",
      validFrom: "2026-10-15T00:00:00Z",
      validUntil: "2026-12-05T23:59:59Z",
      status: "pending",
      isActive: true,
      rejectionReason: null,
      moderationNotes: "Submitted by shopkeeper on Oct 15. Awaiting initial admin check of business address and terms.",
      isSponsored: false,
      viewsCount: 0,
      clicksCount: 0,
      createdAt: "2026-10-15T11:20:00Z",
      updatedAt: "2026-10-15T11:20:00Z"
    },
    {
      id: "off-pending-202",
      businessId: "biz-1",
      merchantId: "usr-merchant-1",
      merchantEmail: "heritage.silks@gmail.com",
      shopName: "Heritage Silks of Assam",
      city: "Dibrugarh",
      locality: "HS Road",
      address: "Shop 14-16, New Market Complex, HS Road, Dibrugarh",
      landmark: "Near Bata Showroom, HS Road",
      category: "fashion",
      headline: "Diwali Special: Buy Any 2 Designer Kurtis & Get 1 Embroidered Cotton Dupatta Free",
      discountValue: "BUY 2 GET DUPATTA FREE",
      description: "Exclusive seasonal offer for the upcoming festival. Choose from our latest pure cotton and modal printed kurti collection.",
      terms: [
        "Applicable on in-store readymade tops and kurtis above \u20B9800 each.",
        "The free dupatta is chosen from the selected festive rack.",
        "No cash substitution or refund on free item."
      ],
      contactPhone: "+91 94350 88210",
      contactWhatsapp: "+919435088210",
      locationUrl: "https://maps.google.com/?q=HS+Road+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80",
      openingHours: "10:00 AM \u2013 8:30 PM (Mon\u2013Sat)",
      validFrom: "2026-10-16T00:00:00Z",
      validUntil: "2026-11-12T23:59:59Z",
      status: "pending",
      isActive: true,
      rejectionReason: null,
      moderationNotes: "New festive submission pending approval.",
      isSponsored: false,
      viewsCount: 0,
      clicksCount: 0,
      createdAt: "2026-10-16T07:15:00Z",
      updatedAt: "2026-10-16T07:15:00Z"
    },
    // REJECTED OFFER EXAMPLE
    {
      id: "off-rej-301",
      businessId: "biz-3",
      merchantId: "usr-merchant-3",
      merchantEmail: "nemobilehub@gmail.com",
      shopName: "NorthEast Mobile & Gadget Hub",
      city: "Dibrugarh",
      locality: "Chowkidinghee",
      address: "Shop 5, City Centre Plaza, Chowkidinghee, Dibrugarh",
      landmark: "Near Chowkidinghee Bus Terminus",
      category: "electronics",
      headline: "Unbelievable 90% Off on All Latest Smartphones Today Only",
      discountValue: "90% OFF SMARTPHONES",
      description: "Get branded 5G smartphones for under \u20B92,000.",
      terms: ["Subject to availability."],
      contactPhone: "+91 97060 44221",
      locationUrl: "https://maps.google.com/?q=Chowkidinghee+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80",
      openingHours: "9:30 AM \u2013 8:00 PM (Mon\u2013Sat)",
      validFrom: "2026-10-10T00:00:00Z",
      validUntil: "2026-10-11T23:59:59Z",
      status: "rejected",
      isActive: true,
      rejectionReason: "Misleading pricing claim: 90% discount on new flagship electronics without verified manufacturer authorization violates platform truth-in-advertising guidelines.",
      moderationNotes: "Rejected on Oct 11 by Admin. Clarification requested from merchant on actual terms.",
      isSponsored: false,
      viewsCount: 0,
      clicksCount: 0,
      createdAt: "2026-10-10T08:00:00Z",
      updatedAt: "2026-10-11T10:00:00Z"
    },
    // EXPIRED OFFER EXAMPLE
    {
      id: "off-exp-401",
      businessId: "biz-2",
      merchantId: "usr-merchant-2",
      merchantEmail: "chai.chomp@gmail.com",
      shopName: "Chai & Chomp Artisan Bistro",
      city: "Dibrugarh",
      locality: "Graham Bazar",
      address: "Plot 42, Riverview Lane, Graham Bazar, Dibrugarh",
      landmark: "Opposite SBI, Graham Bazar",
      category: "cafes-restaurants",
      headline: "Monsoon Evening Special: Flat 30% Off on Ginger Tea & Pakora Platters",
      discountValue: "30% OFF MONSOON SPECIAL",
      description: "Warm up during rainy afternoons with traditional Assamese ginger tea and crispy onion-paneer pakoras.",
      terms: ["Served between 4 PM to 7 PM only.", "Dine-in only at Graham Bazar."],
      contactPhone: "+91 88760 33419",
      locationUrl: "https://maps.google.com/?q=Graham+Bazar+Dibrugarh+Assam",
      imageUrl: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80",
      openingHours: "11:00 AM \u2013 10:30 PM (Daily)",
      validFrom: "2026-09-01T00:00:00Z",
      validUntil: "2026-09-30T23:59:59Z",
      status: "expired",
      isActive: true,
      isSponsored: false,
      viewsCount: 890,
      clicksCount: 142,
      createdAt: "2026-09-01T08:00:00Z",
      updatedAt: "2026-10-01T00:00:00Z"
    }
  ];
  const promotionRequests = [
    {
      id: "prq-101",
      merchantId: "usr-merchant-1",
      merchantEmail: "heritage.silks@gmail.com",
      businessId: "biz-1",
      offerId: "off-101",
      offerHeadline: "Flat 25% Off on All Traditional Assamese Mekhela Sador & Ethnic Wear",
      shopName: "Heritage Silks of Assam",
      packageId: "pkg-featured",
      packageName: "Featured Shop (30 Days)",
      tier: "featured",
      priceInr: 499,
      durationDays: 30,
      paymentMethod: "UPI Reference (Demo)",
      transactionReference: "UPI-REF-98442-DBR",
      status: "active",
      adminNotes: "Verified via demo bank transfer simulation on Oct 02.",
      requestedAt: "2026-10-01T15:00:00Z",
      activatedAt: "2026-10-02T12:00:00Z",
      expiresAt: "2026-11-01T12:00:00Z"
    },
    {
      id: "prq-102",
      merchantId: "usr-merchant-2",
      merchantEmail: "chai.chomp@gmail.com",
      businessId: "biz-2",
      offerId: "off-102",
      offerHeadline: "Buy 1 Get 1 Free on All Woodfired Pizzas & Fresh Pastas",
      shopName: "Chai & Chomp Artisan Bistro",
      packageId: "pkg-spotlight",
      packageName: "Homepage Spotlight (14 Days)",
      tier: "spotlight",
      priceInr: 999,
      durationDays: 14,
      paymentMethod: "Card / Net Banking (Demo)",
      transactionReference: "TXN-SPOT-887612",
      status: "pending_verification",
      adminNotes: "Merchant submitted payment ref. Pending admin verification.",
      requestedAt: "2026-10-16T04:30:00Z"
    }
  ];
  const reports = [
    {
      id: "rep-101",
      offerId: "off-103",
      offerHeadline: "Up to 40% Off on Premium Screen Guards & Certified Fast Charging Adapters",
      shopName: "NorthEast Mobile & Gadget Hub",
      reporterName: "Kallol Gogoi",
      reporterContact: "kallol.g@gmail.com",
      reason: "incorrect_terms",
      details: "Shopkeeper said only specific iPhone 13 models qualify for 40% off, but headline says all accessories without clear model exclusions.",
      status: "open",
      createdAt: "2026-10-14T16:45:00Z"
    }
  ];
  return {
    users,
    sessions: [],
    businesses,
    offers,
    categories: DEFAULT_CATEGORIES,
    cities: DEFAULT_CITIES,
    districts: DEFAULT_DISTRICTS,
    promotionPackages: DEFAULT_PROMOTION_PACKAGES,
    promotionRequests,
    reports,
    auditLogs: [],
    referrals: [],
    referralConfig: DEFAULT_REFERRAL_CONFIG,
    verificationRequests: [],
    dealSuggestions: [],
    products: [],
    orders: []
  };
}
var Store = class {
  constructor() {
    this.data = this.loadData();
    if (!this.data.products) this.data.products = [];
    if (!this.data.orders) this.data.orders = [];
    if (!this.data.promotionRequests) this.data.promotionRequests = [];
    if (!this.data.verificationRequests) this.data.verificationRequests = [];
    if (!this.data.dealSuggestions) this.data.dealSuggestions = [];
  }
  loadData() {
    try {
      if (!fs2.existsSync(DATA_DIR)) {
        fs2.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs2.existsSync(DB_FILE)) {
        const raw = fs2.readFileSync(DB_FILE, "utf-8");
        const parsed = JSON.parse(raw);
        if (parsed.offers && parsed.categories && parsed.cities && parsed.businesses) {
          if (!parsed.sessions) parsed.sessions = [];
          if (!parsed.auditLogs) parsed.auditLogs = [];
          if (!parsed.referrals) parsed.referrals = [];
          if (!parsed.referralConfig) parsed.referralConfig = DEFAULT_REFERRAL_CONFIG;
          if (!parsed.dealSuggestions) parsed.dealSuggestions = [];
          if (!parsed.districts) parsed.districts = DEFAULT_DISTRICTS;
          if (!parsed.products) parsed.products = [];
          if (!parsed.orders) parsed.orders = [];
          if (!parsed.promotionRequests) parsed.promotionRequests = [];
          if (!parsed.verificationRequests) parsed.verificationRequests = [];
          const knownDemoUserIds = /* @__PURE__ */ new Set(["usr-merchant-1", "usr-merchant-2", "usr-public-1"]);
          const knownDemoBizIds = /* @__PURE__ */ new Set(["biz-1", "biz-2", "biz-3", "biz-4", "biz-5", "biz-6", "biz-7"]);
          const knownDemoOfferIds = /* @__PURE__ */ new Set([
            "off-101",
            "off-101-b",
            "off-102",
            "off-102-b",
            "off-103",
            "off-104",
            "off-105",
            "off-106",
            "off-pending-201",
            "off-pending-202",
            "off-rej-301",
            "off-exp-401"
          ]);
          const knownDemoPromoIds = /* @__PURE__ */ new Set(["prq-101", "prq-102"]);
          const knownDemoReportIds = /* @__PURE__ */ new Set(["rep-101"]);
          parsed.users = (parsed.users || []).map((u) => {
            const isDemo = knownDemoUserIds.has(u.id);
            const referralCode = u.referralCode || generateReferralCode(u.name || "User", u.id);
            const referralCount = u.referralCount !== void 0 ? u.referralCount : (parsed.referrals || []).filter((r) => r.referrerId === u.id && r.status === "verified").length;
            if (!u.passwordHash) {
              const salt = crypto.randomBytes(16).toString("hex");
              let defaultPass = "CityDeals@12345";
              if (u.role === "admin" || u.email === "admin@citydeals.in") defaultPass = "Admin@12345";
              else if (u.email === "heritage.silks@gmail.com" || u.email === "chai.chomp@gmail.com") defaultPass = "Merchant@12345";
              else if (u.email === "shopper@citydeals.in" || u.role === "public") defaultPass = "Shopper@12345";
              return {
                ...u,
                passwordHash: hashPassword(defaultPass, salt),
                salt,
                isDemo,
                referralCode,
                referralCount
              };
            }
            return {
              ...u,
              isDemo,
              referralCode,
              referralCount
            };
          });
          const authorizedAdminEmails = /* @__PURE__ */ new Set(["citydeals.discoverlocal@gmail.com"]);
          if (process.env.ADMIN_EMAIL) {
            authorizedAdminEmails.add(process.env.ADMIN_EMAIL.trim().toLowerCase());
          }
          parsed.users.forEach((u) => {
            const uEmail = (u.email || "").trim().toLowerCase();
            if (authorizedAdminEmails.has(uEmail)) {
              if (u.role !== "admin") {
                u.role = "admin";
                console.log(`[CityDeals RBAC] Confirmed administrative role for ${u.email}`);
              }
            } else if (u.role === "admin") {
              u.role = "public";
              console.log(`[CityDeals RBAC] Safely separated regular user ${u.email} from admin privileges`);
            }
          });
          parsed.businesses = (parsed.businesses || []).map((b) => {
            const coords = getLocalityCoordinates(b.locality);
            return {
              ...b,
              latitude: b.latitude || coords.lat,
              longitude: b.longitude || coords.lng,
              isDemo: knownDemoBizIds.has(b.id)
            };
          });
          parsed.offers = (parsed.offers || []).filter((o) => !knownDemoOfferIds.has(o.id) && !o.isDemo).map((o) => {
            const parentBiz = parsed.businesses.find((b) => b.id === o.businessId);
            const coords = parentBiz?.latitude ? { lat: parentBiz.latitude, lng: parentBiz.longitude } : getLocalityCoordinates(o.locality);
            return {
              ...o,
              latitude: o.latitude || coords.lat,
              longitude: o.longitude || coords.lng,
              lastVerifiedAt: o.lastVerifiedAt || o.updatedAt || o.createdAt,
              verifiedBy: o.verifiedBy || "CityDeals Moderation Team",
              sharesCount: o.sharesCount || 0,
              isDemo: false
            };
          });
          parsed.promotionRequests = (parsed.promotionRequests || []).map((p) => ({
            ...p,
            isDemo: knownDemoPromoIds.has(p.id)
          }));
          parsed.reports = (parsed.reports || []).map((r) => ({
            ...r,
            isDemo: knownDemoReportIds.has(r.id)
          }));
          const DEMO_BIZ_IDS = /* @__PURE__ */ new Set(["biz-1", "biz-2", "biz-3", "biz-4", "biz-5", "biz-6", "biz-7"]);
          parsed.products = (parsed.products || []).map((p) => ({
            ...p,
            isDemo: Boolean(p.isDemo || DEMO_BIZ_IDS.has(p.businessId))
          }));
          parsed.orders = (parsed.orders || []).map((o) => ({
            ...o,
            isDemo: Boolean(o.isDemo || DEMO_BIZ_IDS.has(o.businessId))
          }));
          this.saveData(parsed);
          return parsed;
        }
      }
    } catch (e) {
      console.warn("Could not read existing database, initializing clean production setup:", e);
    }
    const initial = process.env.SEED_SAMPLE_DATA === "true" ? getSampleData() : getCleanProductionData();
    this.saveData(initial);
    return initial;
  }
  saveData(data) {
    if (data) {
      this.data = data;
    }
    try {
      if (!fs2.existsSync(DATA_DIR)) {
        fs2.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs2.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), "utf-8");
    } catch (e) {
      console.error("Failed to write database file:", e);
    }
  }
  resetSeed() {
    this.data = process.env.SEED_SAMPLE_DATA === "true" ? getSampleData() : getCleanProductionData();
    this.saveData();
    return this.data;
  }
  getData() {
    return this.data;
  }
  async initFirestoreSync() {
    try {
      const fromFirestore = await loadCollectionsFromFirestore();
      const PRE_RESET_BIZ_IDS = /* @__PURE__ */ new Set([
        "biz-1",
        "biz-2",
        "biz-3",
        "biz-4",
        "biz-5",
        "biz-6",
        "biz-7",
        "biz-1793006905634",
        "biz-usr-1792955234246-dc20d19a"
      ]);
      const PRE_RESET_USER_IDS = /* @__PURE__ */ new Set([
        "usr-admin-1",
        "usr-merchant-1",
        "usr-merchant-2",
        "usr-public-1",
        "usr-1792955234246-dc20d19a",
        "usr-1793006905517-4701b549",
        "usr-1793006838902-6b0332ee",
        "usr-1793009241489-cf061444",
        "usr-1793009212916-a6e08eaf"
      ]);
      if (fromFirestore.businesses && fromFirestore.businesses.length > 0) {
        const allowedBiz = fromFirestore.businesses.filter((b) => !PRE_RESET_BIZ_IDS.has(b.id) && !b.isDemo);
        for (const b of allowedBiz) {
          const idx = this.data.businesses.findIndex((existing) => existing.id === b.id);
          if (idx >= 0) {
            this.data.businesses[idx] = { ...this.data.businesses[idx], ...b };
          } else {
            this.data.businesses.push(b);
          }
        }
      }
      if (fromFirestore.offers && fromFirestore.offers.length > 0) {
        const allowedOffers = fromFirestore.offers.filter((o) => !PRE_RESET_BIZ_IDS.has(o.businessId) && !o.isDemo);
        for (const o of allowedOffers) {
          const idx = this.data.offers.findIndex((existing) => existing.id === o.id);
          if (idx >= 0) {
            this.data.offers[idx] = { ...this.data.offers[idx], ...o };
          } else {
            this.data.offers.push(o);
          }
        }
      }
      if (fromFirestore.products && fromFirestore.products.length > 0) {
        const allowedProds = fromFirestore.products.filter((p) => !PRE_RESET_BIZ_IDS.has(p.businessId) && !p.isDemo);
        for (const p of allowedProds) {
          const idx = this.data.products.findIndex((existing) => existing.id === p.id);
          if (idx >= 0) {
            this.data.products[idx] = { ...this.data.products[idx], ...p };
          } else {
            this.data.products.push(p);
          }
        }
      }
      if (fromFirestore.categories && fromFirestore.categories.length > 0) {
        this.data.categories = fromFirestore.categories;
      }
      if (fromFirestore.cities && fromFirestore.cities.length > 0) {
        this.data.cities = fromFirestore.cities;
      }
      this.data.promotionPackages = DEFAULT_PROMOTION_PACKAGES;
      if (fromFirestore.orders && fromFirestore.orders.length > 0) {
        const allowedOrders = fromFirestore.orders.filter((o) => !PRE_RESET_BIZ_IDS.has(o.businessId) && !o.isDemo);
        for (const ord of allowedOrders) {
          const idx = this.data.orders.findIndex((existing) => existing.id === ord.id);
          if (idx >= 0) {
            this.data.orders[idx] = { ...this.data.orders[idx], ...ord };
          } else {
            this.data.orders.push(ord);
          }
        }
      }
      if (fromFirestore.dealSuggestions && fromFirestore.dealSuggestions.length > 0) {
        this.data.dealSuggestions = fromFirestore.dealSuggestions.filter((s) => s.id !== "sug-1793347760395-8zwl3");
      }
      if (fromFirestore.reports && fromFirestore.reports.length > 0) {
        this.data.reports = fromFirestore.reports.filter((r) => r.id !== "rep-101");
      }
      if (fromFirestore.promotionRequests && fromFirestore.promotionRequests.length > 0) {
        const allowedPromo = fromFirestore.promotionRequests.filter((p) => p.id !== "prq-101" && p.id !== "prq-102");
        for (const pr of allowedPromo) {
          const idx = this.data.promotionRequests.findIndex((existing) => existing.id === pr.id);
          if (idx >= 0) {
            this.data.promotionRequests[idx] = { ...this.data.promotionRequests[idx], ...pr };
          } else {
            this.data.promotionRequests.push(pr);
          }
        }
      }
      if (fromFirestore.verificationRequests && fromFirestore.verificationRequests.length > 0) {
        for (const vr of fromFirestore.verificationRequests) {
          const idx = this.data.verificationRequests.findIndex((existing) => existing.id === vr.id);
          if (idx >= 0) {
            this.data.verificationRequests[idx] = { ...this.data.verificationRequests[idx], ...vr };
          } else {
            this.data.verificationRequests.push(vr);
          }
        }
      }
      if (fromFirestore.users) {
        const allowedUsers = fromFirestore.users.filter((u) => !PRE_RESET_USER_IDS.has(u.id) && u.email !== "admin@citydeals.in");
        for (const u of allowedUsers) {
          const idx = this.data.users.findIndex((existing) => existing.id === u.id);
          if (idx >= 0) {
            this.data.users[idx] = { ...this.data.users[idx], ...u };
          } else {
            this.data.users.push(u);
          }
        }
      }
      const ADMIN_EMAIL = "citydeals.discoverlocal@gmail.com";
      const existingAdmin = this.data.users.find((u) => (u.email || "").toLowerCase().trim() === ADMIN_EMAIL);
      if (!existingAdmin) {
        const saltAdmin = crypto.randomBytes(16).toString("hex");
        const adminPassword = process.env.ADMIN_INITIAL_PASSWORD || "Admin@12345";
        const newAdminUser = {
          id: "usr-admin-founder",
          name: "CityDeals Administrator",
          email: ADMIN_EMAIL,
          role: "admin",
          phone: "+91 98540 00000",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          passwordHash: hashPassword(adminPassword, saltAdmin),
          salt: saltAdmin,
          isDemo: false,
          referralCode: generateReferralCode("CityDeals Administrator", "usr-admin-founder"),
          referralCount: 0
        };
        this.data.users.push(newAdminUser);
      } else {
        existingAdmin.role = "admin";
      }
      for (const u of this.data.users) {
        const uEmail = (u.email || "").toLowerCase().trim();
        if (u.role === "admin" && uEmail !== ADMIN_EMAIL && uEmail !== (process.env.ADMIN_EMAIL || "").toLowerCase().trim()) {
          u.role = "public";
          console.log(`[CityDeals RBAC] Safely separated regular user ${u.email} to public customer role`);
        }
      }
      this.saveData();
      if (fromFirestore.districts && fromFirestore.districts.length > 0) {
        this.data.districts = fromFirestore.districts;
      } else {
        if (!this.data.districts || this.data.districts.length === 0) {
          this.data.districts = DEFAULT_DISTRICTS;
        }
        for (const dist of this.data.districts) {
          persistToFirestore("districts", dist.id, dist);
        }
      }
      for (const b of this.data.businesses) {
        if (!b.state) b.state = "Assam";
        if (!b.district) {
          if (b.city && b.city.toLowerCase().includes("tinsukia")) {
            b.district = "Tinsukia";
            b.districtId = "tinsukia";
          } else {
            b.district = "Dibrugarh";
            b.districtId = "dibrugarh";
          }
        }
        if (!b.fullAddress) b.fullAddress = b.address || `${b.locality}, ${b.district}`;
      }
      for (const o of this.data.offers) {
        if (!o.state) o.state = "Assam";
        if (!o.district) {
          if (o.city && o.city.toLowerCase().includes("tinsukia")) {
            o.district = "Tinsukia";
            o.districtId = "tinsukia";
          } else {
            o.district = "Dibrugarh";
            o.districtId = "dibrugarh";
          }
        }
        if (!o.fullAddress) o.fullAddress = o.address || `${o.locality}, ${o.district}`;
      }
      for (const localOffer of this.data.offers) {
        if (!PRE_RESET_BIZ_IDS.has(localOffer.businessId) && !localOffer.isDemo) {
          await persistToFirestore("offers", localOffer.id, localOffer).catch(() => {
          });
        }
      }
      this.saveData();
      console.log("\u2705 Synchronized CityDeals database state directly from Google Cloud Firestore collections!");
      await processOfferExpirations();
    } catch (err) {
      console.warn("\u26A0 Initial Firestore sync deferred:", err.message);
    }
  }
};
var db = new Store();
async function processOfferExpirations() {
  const now = /* @__PURE__ */ new Date();
  const offers = db.getData().offers;
  let expiredCount = 0;
  for (const offer of offers) {
    const expiryStr = offer.expiryDate || offer.validUntil;
    if (expiryStr) {
      const expiry = new Date(expiryStr);
      if (expiry < now && offer.status !== "expired") {
        offer.status = "expired";
        offer.isActive = false;
        offer.expiryDate = expiryStr;
        if (!offer.startDate) offer.startDate = offer.validFrom || offer.createdAt || now.toISOString();
        offer.updatedAt = now.toISOString();
        expiredCount++;
        await persistToFirestore("offers", offer.id, offer).catch(() => {
        });
      }
    }
    if (offer.isSponsored && offer.sponsorExpiry) {
      const spExpiry = new Date(offer.sponsorExpiry);
      if (spExpiry < now) {
        offer.isSponsored = false;
        offer.sponsorExpiry = null;
        offer.sponsorBadge = void 0;
        await persistToFirestore("offers", offer.id, offer).catch(() => {
        });
      }
    }
  }
  const promoRequests = db.getData().promotionRequests;
  for (const pr of promoRequests) {
    if (pr.status === "active" && pr.expiresAt) {
      const exp = new Date(pr.expiresAt);
      if (exp < now) {
        pr.status = "expired";
        await persistToFirestore("promotionRequests", pr.id, pr).catch(() => {
        });
      }
    }
  }
  if (expiredCount > 0) {
    db.saveData();
    console.log(`[Expiration Engine] Successfully marked ${expiredCount} expired offer(s) based on server-side time.`);
  }
  return expiredCount;
}
setInterval(() => {
  processOfferExpirations().catch((err) => {
    console.error("[Scheduled Expiration Error]:", err.message);
  });
}, 60 * 1e3);
function getRequester(req) {
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.substring(7).trim();
    if (!token) return null;
    if (token.includes(".") && token.split(".").length === 3) {
      try {
        const payloadJson = Buffer.from(token.split(".")[1], "base64").toString("utf-8");
        const payload = JSON.parse(payloadJson);
        const nowSec = Math.floor(Date.now() / 1e3);
        if (payload.aud === "arboreal-maker-n3kqt" && payload.iss === "https://securetoken.google.com/arboreal-maker-n3kqt" && payload.exp > nowSec && payload.sub) {
          const uid = payload.sub;
          const email = (payload.email || "").toLowerCase().trim();
          const TRUSTED_ADMIN_UIDS = /* @__PURE__ */ new Set([
            "usr-admin-founder",
            "firebase-uid-admin-citydeals-789",
            "Qx2QmFZluVMRftETWEQ44USyIDs1"
          ]);
          const isAuthorizedAdmin = (email === "citydeals.discoverlocal@gmail.com" || (process.env.ADMIN_EMAIL ? email === process.env.ADMIN_EMAIL.toLowerCase().trim() : false)) && (TRUSTED_ADMIN_UIDS.has(uid) || db.getData().users.some((u) => u.id === uid && u.role === "admin"));
          let user = db.getData().users.find((u) => u.id === uid);
          if (!user) {
            const newUser = {
              id: uid,
              name: payload.name || (email ? email.split("@")[0] : "User"),
              email,
              role: isAuthorizedAdmin ? "admin" : "public",
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              referralCode: generateReferralCode(payload.name || "User", uid),
              referralCount: 0
            };
            db.getData().users.push(newUser);
            db.saveData();
            persistToFirestore("users", newUser.id, sanitizeUser(newUser));
            if (isAuthorizedAdmin) {
              persistToFirestore("admins", newUser.id, { id: newUser.id, email: newUser.email, assignedAt: (/* @__PURE__ */ new Date()).toISOString() });
            }
            user = newUser;
          } else {
            if (isAuthorizedAdmin) {
              if (user.role !== "admin") {
                user.role = "admin";
                db.saveData();
                persistToFirestore("users", user.id, sanitizeUser(user));
                persistToFirestore("admins", user.id, { id: user.id, email: user.email, assignedAt: (/* @__PURE__ */ new Date()).toISOString() });
              }
            } else if (user.role === "admin") {
              user.role = "public";
              db.saveData();
              persistToFirestore("users", user.id, sanitizeUser(user));
              removeFromFirestore("admins", user.id);
            }
          }
          return sanitizeUser(user);
        }
      } catch {
      }
    }
    const now = /* @__PURE__ */ new Date();
    const session = db.getData().sessions.find((s) => s.token === token && new Date(s.expiresAt) > now);
    if (session) {
      const stored = db.getData().users.find((u) => u.id === session.userId);
      if (stored) {
        return sanitizeUser(stored);
      }
    }
  }
  return null;
}
function recordAuditLog(actor, action, targetType, targetId, details) {
  const log = {
    id: `log-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
    actorId: actor.id,
    actorEmail: actor.email,
    actorRole: actor.role,
    action,
    targetType,
    targetId,
    details,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  db.getData().auditLogs.unshift(log);
  if (db.getData().auditLogs.length > 500) {
    db.getData().auditLogs.pop();
  }
  db.saveData();
  persistToFirestore("auditLogs", log.id, log);
}
async function startServer() {
  await db.initFirestoreSync();
  const app = express();
  app.set("trust proxy", 1);
  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ extended: true, limit: "10mb" }));
  app.use((req, res, next) => {
    const acceptEncoding = String(req.headers["accept-encoding"] || "");
    if (!acceptEncoding.includes("gzip") || req.method === "HEAD") {
      return next();
    }
    const origJson = res.json.bind(res);
    res.json = ((body) => {
      try {
        const serialized = JSON.stringify(body);
        if (serialized && Buffer.byteLength(serialized, "utf8") > 1024 && !res.headersSent) {
          const gz = zlib.gzipSync(serialized);
          res.setHeader("Content-Encoding", "gzip");
          res.setHeader("Vary", "Accept-Encoding");
          res.setHeader("Content-Type", "application/json; charset=utf-8");
          return res.send(gz);
        }
      } catch {
      }
      return origJson(body);
    });
    next();
  });
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1e3,
    // 15 minutes
    max: 20,
    // 20 attempts per window
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false, forwardedHeader: false },
    message: { error: "Too many authentication attempts from this IP. Please try again after 15 minutes." }
  });
  const passwordResetLimiter = rateLimit({
    windowMs: 60 * 60 * 1e3,
    // 1 hour
    max: 6,
    // 6 attempts per hour
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false, forwardedHeader: false },
    message: { error: "Too many password reset requests from this IP. Please try again in an hour." }
  });
  const ordersLimiter = rateLimit({
    windowMs: 60 * 60 * 1e3,
    // 1 hour
    max: 60,
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false, forwardedHeader: false },
    message: { error: "Order submission limit exceeded for this IP. Please wait before placing more orders." }
  });
  setInterval(() => {
    try {
      const now = Date.now();
      const initial = db.getData().sessions.length;
      db.getData().sessions = db.getData().sessions.filter((s) => new Date(s.expiresAt).getTime() > now);
      if (db.getData().sessions.length !== initial) {
        db.saveData();
      }
    } catch {
    }
  }, 15 * 60 * 1e3);
  app.get("/api/config", (_req, res) => {
    const data = db.getData();
    res.json({
      status: "ok",
      launchCity: "Dibrugarh",
      launchDistricts: ["Dibrugarh", "Tinsukia"],
      state: "Assam",
      country: "India",
      cities: data.cities,
      districts: data.districts || DEFAULT_DISTRICTS,
      categories: data.categories,
      promotionPackages: data.promotionPackages,
      concept: "Dynamic Multi-District Hyperlocal Shop & In-Store Offers Directory for Assam"
    });
  });
  app.get("/api/districts", (_req, res) => {
    const districts = db.getData().districts || DEFAULT_DISTRICTS;
    res.json({
      districts: districts.filter((d) => d.isActive !== false).map((d) => ({
        ...d,
        localities: (d.localities || []).filter((l) => l.isActive !== false)
      }))
    });
  });
  app.get("/api/offers", (req, res) => {
    const { district, city, category, locality, search, sort, userLat, userLng, maxDistanceKm } = req.query;
    const now = /* @__PURE__ */ new Date();
    const allOffers = db.getData().offers;
    const allBusinesses = db.getData().businesses;
    for (const o of allOffers) {
      const expStr = o.expiryDate || o.validUntil;
      if (expStr && new Date(expStr) < now && o.status !== "expired") {
        o.status = "expired";
        o.isActive = false;
        o.expiryDate = expStr;
        o.updatedAt = now.toISOString();
        persistToFirestore("offers", o.id, o).catch(() => {
        });
      }
    }
    let filtered = allOffers.filter((o) => {
      if (o.isDemo) return false;
      if (o.status !== "approved") return false;
      if (o.isActive === false) return false;
      const validUntil = new Date(o.expiryDate || o.validUntil);
      if (validUntil < now) return false;
      const shop = allBusinesses.find((b) => b.id === o.businessId);
      if (shop && (shop.status !== "approved" || shop.isDemo)) return false;
      return true;
    });
    const targetDistrict = (district || city || "").trim();
    if (targetDistrict && targetDistrict.toLowerCase() !== "all") {
      const qDist = targetDistrict.toLowerCase();
      filtered = filtered.filter(
        (o) => o.district && o.district.toLowerCase() === qDist || o.city && o.city.toLowerCase() === qDist
      );
    }
    if (category && typeof category === "string" && category.toLowerCase() !== "all") {
      filtered = filtered.filter((o) => o.category.toLowerCase() === category.toLowerCase());
    }
    if (search && typeof search === "string" && search.trim() !== "") {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter((o) => {
        return o.headline.toLowerCase().includes(q) || o.shopName.toLowerCase().includes(q) || o.description.toLowerCase().includes(q) || o.locality.toLowerCase().includes(q) || o.category.toLowerCase().includes(q) || o.landmark && o.landmark.toLowerCase().includes(q);
      });
    }
    const uLat = userLat ? parseFloat(userLat) : NaN;
    const uLng = userLng ? parseFloat(userLng) : NaN;
    const maxDist = maxDistanceKm ? parseFloat(maxDistanceKm) : null;
    const hasUserCoords = !isNaN(uLat) && !isNaN(uLng);
    filtered = filtered.map((o) => {
      let lat = o.latitude;
      let lng = o.longitude;
      if (!lat || !lng) {
        const parentShop = allBusinesses.find((b) => b.id === o.businessId);
        if (parentShop && parentShop.latitude && parentShop.longitude) {
          lat = parentShop.latitude;
          lng = parentShop.longitude;
        } else {
          const coords = getLocalityCoordinates(o.locality, o.district || o.city);
          lat = coords.lat;
          lng = coords.lng;
        }
      }
      const dist = hasUserCoords ? calculateDistanceKm(uLat, uLng, lat, lng) : void 0;
      return {
        ...o,
        latitude: lat,
        longitude: lng,
        distanceKm: dist
      };
    });
    if (hasUserCoords && maxDist !== null && !isNaN(maxDist)) {
      filtered = filtered.filter((o) => o.distanceKm !== void 0 && o.distanceKm <= maxDist);
    }
    filtered.sort((a, b) => {
      if (a.isSponsored && !b.isSponsored) return -1;
      if (!a.isSponsored && b.isSponsored) return 1;
      if (sort === "nearest" && hasUserCoords) {
        return (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999);
      }
      if (sort === "expiring_soon") {
        return new Date(a.validUntil).getTime() - new Date(b.validUntil).getTime();
      }
      if (sort === "popular") {
        return (b.viewsCount || 0) - (a.viewsCount || 0);
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    const cleanLocality = typeof locality === "string" ? locality.trim() : "";
    let primaryOffers = [];
    let districtWideOffers = [];
    let nearbyOffers = [];
    if (cleanLocality && cleanLocality.toLowerCase() !== "all") {
      const qLoc = cleanLocality.toLowerCase();
      primaryOffers = filtered.filter((o) => o.locality.toLowerCase().trim() === qLoc);
      districtWideOffers = filtered.filter((o) => Boolean(o.isDistrictWide) && o.locality.toLowerCase().trim() !== qLoc);
      nearbyOffers = filtered.filter((o) => !o.isDistrictWide && o.locality.toLowerCase().trim() !== qLoc);
    } else {
      primaryOffers = filtered;
      districtWideOffers = filtered.filter((o) => Boolean(o.isDistrictWide));
      nearbyOffers = [];
    }
    res.json({
      count: cleanLocality && cleanLocality.toLowerCase() !== "all" ? primaryOffers.length : filtered.length,
      totalDistrictOffers: filtered.length,
      offers: cleanLocality && cleanLocality.toLowerCase() !== "all" ? primaryOffers : filtered,
      primaryOffers,
      districtWideOffers,
      nearbyOffers,
      selectedLocality: cleanLocality || "all",
      selectedDistrict: targetDistrict || "all"
    });
  });
  app.get("/api/shops", (req, res) => {
    const { district, city, category, locality, search, userLat, userLng, maxDistanceKm, sort } = req.query;
    const now = /* @__PURE__ */ new Date();
    const allBusinesses = db.getData().businesses;
    const allOffers = db.getData().offers;
    let approvedShops = allBusinesses.filter((b) => b.status === "approved" && !b.isDemo);
    const targetDistrict = (district || city || "").trim();
    if (targetDistrict && targetDistrict.toLowerCase() !== "all") {
      const qDist = targetDistrict.toLowerCase();
      approvedShops = approvedShops.filter(
        (b) => b.district && b.district.toLowerCase() === qDist || b.city && b.city.toLowerCase() === qDist
      );
    }
    if (category && typeof category === "string" && category.toLowerCase() !== "all") {
      approvedShops = approvedShops.filter((b) => b.category.toLowerCase() === category.toLowerCase());
    }
    if (locality && typeof locality === "string" && locality.toLowerCase() !== "all") {
      approvedShops = approvedShops.filter((b) => b.locality.toLowerCase() === locality.toLowerCase());
    }
    if (search && typeof search === "string" && search.trim() !== "") {
      const q = search.toLowerCase().trim();
      approvedShops = approvedShops.filter(
        (b) => b.name.toLowerCase().includes(q) || b.locality.toLowerCase().includes(q) || b.category.toLowerCase().includes(q) || b.landmark && b.landmark.toLowerCase().includes(q)
      );
    }
    const uLat = userLat ? parseFloat(userLat) : NaN;
    const uLng = userLng ? parseFloat(userLng) : NaN;
    const maxDist = maxDistanceKm ? parseFloat(maxDistanceKm) : null;
    const hasUserCoords = !isNaN(uLat) && !isNaN(uLng);
    let grouped = approvedShops.map((shop) => {
      let lat = shop.latitude;
      let lng = shop.longitude;
      if (!lat || !lng) {
        const coords = getLocalityCoordinates(shop.locality);
        lat = coords.lat;
        lng = coords.lng;
      }
      const dist = hasUserCoords ? calculateDistanceKm(uLat, uLng, lat, lng) : void 0;
      const updatedShop = {
        ...shop,
        latitude: lat,
        longitude: lng,
        distanceKm: dist
      };
      const activeOffers = allOffers.filter(
        (o) => !o.isDemo && o.businessId === shop.id && o.status === "approved" && o.isActive !== false && new Date(o.validUntil) >= now
      ).map((o) => ({
        ...o,
        latitude: lat,
        longitude: lng,
        distanceKm: dist
      }));
      return {
        business: updatedShop,
        activeOffers
      };
    });
    if (hasUserCoords && maxDist !== null && !isNaN(maxDist)) {
      grouped = grouped.filter((g) => g.business.distanceKm !== void 0 && g.business.distanceKm <= maxDist);
    }
    if (sort === "nearest" && hasUserCoords) {
      grouped.sort((a, b) => (a.business.distanceKm ?? 9999) - (b.business.distanceKm ?? 9999));
    }
    res.json({ count: grouped.length, shops: grouped });
  });
  app.get("/api/shops/:id", (req, res) => {
    const { id } = req.params;
    const business = db.getData().businesses.find((b) => b.id === id);
    if (!business) {
      res.status(404).json({ error: "Shop not found" });
      return;
    }
    const offers = db.getData().offers.filter((o) => o.businessId === id && o.status === "approved" && o.isActive !== false);
    res.json({ business, offers });
  });
  app.get("/api/radar", (req, res) => {
    const now = /* @__PURE__ */ new Date();
    const data = db.getData();
    const { district, city } = req.query;
    const targetLocation = (district || city || "").trim();
    const isFiltered = targetLocation && targetLocation.toLowerCase() !== "all";
    const qLoc = targetLocation.toLowerCase();
    let activeApprovedOffers = data.offers.filter(
      (o) => !o.isDemo && o.status === "approved" && o.isActive !== false && new Date(o.validUntil) >= now
    );
    if (isFiltered) {
      activeApprovedOffers = activeApprovedOffers.filter(
        (o) => o.district && o.district.toLowerCase() === qLoc || o.city && o.city.toLowerCase() === qLoc
      );
    }
    let approvedBusinesses = data.businesses.filter((b) => !b.isDemo && b.status === "approved");
    if (isFiltered) {
      approvedBusinesses = approvedBusinesses.filter(
        (b) => b.district && b.district.toLowerCase() === qLoc || b.city && b.city.toLowerCase() === qLoc
      );
    }
    const trendingOffers = [...activeApprovedOffers].sort((a, b) => (b.viewsCount || 0) + (b.clicksCount || 0) * 2 - ((a.viewsCount || 0) + (a.clicksCount || 0) * 2)).slice(0, 6);
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1e3);
    let newOffersToday = activeApprovedOffers.filter((o) => new Date(o.createdAt) >= oneDayAgo);
    if (newOffersToday.length < 3 && activeApprovedOffers.length > 0) {
      newOffersToday = [...activeApprovedOffers].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 6);
    }
    const threeDaysLater = new Date(Date.now() + 72 * 60 * 60 * 1e3);
    let expiringSoonOffers = activeApprovedOffers.filter((o) => new Date(o.validUntil) <= threeDaysLater).sort((a, b) => new Date(a.validUntil).getTime() - new Date(b.validUntil).getTime());
    if (expiringSoonOffers.length === 0 && activeApprovedOffers.length > 0) {
      expiringSoonOffers = [...activeApprovedOffers].sort((a, b) => new Date(a.validUntil).getTime() - new Date(b.validUntil).getTime()).slice(0, 4);
    }
    const popularShops = [...approvedBusinesses].map((b) => {
      const offersCount = activeApprovedOffers.filter((o) => o.businessId === b.id).length;
      return { ...b, activeOffersCount: offersCount };
    }).sort((a, b) => {
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return b.activeOffersCount - a.activeOffersCount;
    }).slice(0, 6);
    const recentlyVerifiedOffers = [...activeApprovedOffers].filter((o) => o.lastVerifiedAt).sort((a, b) => new Date(b.lastVerifiedAt).getTime() - new Date(a.lastVerifiedAt).getTime()).slice(0, 6);
    res.json({
      trendingOffers,
      newOffersToday,
      expiringSoonOffers,
      popularShops,
      recentlyVerifiedOffers: recentlyVerifiedOffers.length > 0 ? recentlyVerifiedOffers : activeApprovedOffers.slice(0, 4),
      meta: {
        city: targetLocation || "All Locations",
        lastUpdated: now.toISOString(),
        activeDealsCount: activeApprovedOffers.length
      }
    });
  });
  app.post("/api/community/suggest-deal", (req, res) => {
    const { shopName, locality, category, offerHeadline, estimatedDiscount, details, submitterName, submitterContact } = req.body;
    if (!shopName || typeof shopName !== "string" || shopName.trim().length < 2) {
      res.status(400).json({ error: "Shop name is required." });
      return;
    }
    if (!offerHeadline || typeof offerHeadline !== "string" || offerHeadline.trim().length < 3) {
      res.status(400).json({ error: "Deal headline or description is required." });
      return;
    }
    const suggestion = {
      id: `sug-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      shopName: shopName.trim(),
      locality: locality?.trim() || "Dibrugarh",
      category: category?.trim() || "other-shops",
      offerHeadline: offerHeadline.trim(),
      estimatedDiscount: estimatedDiscount?.trim() || void 0,
      details: details?.trim() || void 0,
      submitterName: submitterName?.trim() || "Citizen Shopper",
      submitterContact: submitterContact?.trim() || void 0,
      status: "pending",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (!db.getData().dealSuggestions) {
      db.getData().dealSuggestions = [];
    }
    db.getData().dealSuggestions.unshift(suggestion);
    db.saveData();
    persistToFirestore("dealSuggestions", suggestion.id, suggestion);
    res.json({
      success: true,
      message: "Thank you! Your deal suggestion has been submitted for verification by the Dibrugarh CityDeals team.",
      suggestion
    });
  });
  app.get("/api/offers/:id", (req, res) => {
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    const requester = getRequester(req);
    const isOwner = requester && requester.id === offer.merchantId;
    const isAdmin = requester && requester.role === "admin";
    if ((offer.isDemo || offer.status !== "approved") && !isOwner && !isAdmin) {
      res.status(403).json({ error: "Offer is not approved or is currently pending review." });
      return;
    }
    if (offer.status === "approved" && !offer.isDemo) {
      offer.viewsCount = (offer.viewsCount || 0) + 1;
      db.saveData();
    }
    const otherShopOffers = db.getData().offers.filter(
      (o) => !o.isDemo && o.businessId === offer.businessId && o.id !== offer.id && o.status === "approved" && o.isActive !== false && new Date(o.validUntil) >= /* @__PURE__ */ new Date()
    );
    const business = db.getData().businesses.find((b) => b.id === offer.businessId) || null;
    res.json({ offer, shop: business, otherOffers: otherShopOffers });
  });
  app.post("/api/offers/:id/click", (req, res) => {
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (offer) {
      offer.clicksCount = (offer.clicksCount || 0) + 1;
      db.saveData();
      res.json({ success: true, clicksCount: offer.clicksCount });
    } else {
      res.status(404).json({ error: "Offer not found" });
    }
  });
  app.post("/api/offers/:id/share", (req, res) => {
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (offer) {
      offer.sharesCount = (offer.sharesCount || 0) + 1;
      db.saveData();
      res.json({ success: true, sharesCount: offer.sharesCount });
    } else {
      res.status(404).json({ error: "Offer not found" });
    }
  });
  app.post("/api/offers/:id/view", (req, res) => {
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (offer && offer.status === "approved" && !offer.isDemo) {
      offer.viewsCount = (offer.viewsCount || 0) + 1;
      db.saveData();
      res.json({ success: true, viewsCount: offer.viewsCount });
    } else {
      res.status(404).json({ error: "Offer not found or not active" });
    }
  });
  app.post("/api/offers/:id/report", (req, res) => {
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    const { reason, details, reporterName, reporterContact } = req.body;
    if (!reason || !details) {
      res.status(400).json({ error: "Reason and details are required" });
      return;
    }
    const newReport = {
      id: `rep-${Date.now()}`,
      offerId: offer.id,
      offerHeadline: offer.headline,
      shopName: offer.shopName,
      reporterName: reporterName || "Anonymous Citizen",
      reporterContact: reporterContact || "",
      reason,
      details,
      status: "open",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.getData().reports.unshift(newReport);
    db.saveData();
    persistToFirestore("reports", newReport.id, newReport);
    res.json({
      success: true,
      message: "Thank you for reporting. Our Dibrugarh moderation team will investigate this offer.",
      report: newReport
    });
  });
  app.get("/api/products", (req, res) => {
    const { city, district, category, locality, search, shopId, sort, userLat, userLng, maxDistanceKm, minPrice, maxPrice } = req.query;
    const allProducts = db.getData().products || [];
    const allBusinesses = db.getData().businesses;
    let filtered = allProducts.filter((p) => {
      if (p.isDemo) return false;
      if (p.status !== "approved") return false;
      if (p.isActive === false) return false;
      const shop = allBusinesses.find((b) => b.id === p.businessId);
      if (!shop || shop.isDemo) return false;
      if (shop.status === "rejected" || shop.status === "suspended") return false;
      return true;
    });
    const targetLoc = district || city;
    if (targetLoc && typeof targetLoc === "string" && targetLoc.toLowerCase() !== "all") {
      const q = targetLoc.toLowerCase().trim();
      filtered = filtered.filter((p) => {
        const pCity = (p.city || "").toLowerCase();
        const parentBiz = allBusinesses.find((b) => b.id === p.businessId);
        const bDistrict = (parentBiz?.district || parentBiz?.city || "").toLowerCase();
        return pCity === q || pCity.includes(q) || q.includes(pCity) || bDistrict === q || bDistrict.includes(q) || q.includes(bDistrict);
      });
    }
    if (category && typeof category === "string" && category.toLowerCase() !== "all") {
      filtered = filtered.filter((p) => p.category === category);
    }
    if (locality && typeof locality === "string" && locality.toLowerCase() !== "all") {
      filtered = filtered.filter((p) => p.locality.toLowerCase() === locality.toLowerCase());
    }
    if (shopId && typeof shopId === "string") {
      filtered = filtered.filter((p) => p.businessId === shopId);
    }
    if (search && typeof search === "string" && search.trim() !== "") {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter(
        (p) => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.shopName.toLowerCase().includes(q) || p.locality.toLowerCase().includes(q)
      );
    }
    if (minPrice && !isNaN(Number(minPrice))) {
      filtered = filtered.filter((p) => p.price >= Number(minPrice));
    }
    if (maxPrice && !isNaN(Number(maxPrice))) {
      filtered = filtered.filter((p) => p.price <= Number(maxPrice));
    }
    const hasUserCoords = userLat !== void 0 && userLng !== void 0 && !isNaN(Number(userLat)) && !isNaN(Number(userLng));
    const maxDist = maxDistanceKm !== void 0 ? Number(maxDistanceKm) : null;
    if (hasUserCoords) {
      const uLat = Number(userLat);
      const uLng = Number(userLng);
      filtered = filtered.map((p) => {
        const parentBiz = allBusinesses.find((b) => b.id === p.businessId);
        const lat = p.latitude || parentBiz?.latitude || getLocalityCoordinates(p.locality).lat;
        const lng = p.longitude || parentBiz?.longitude || getLocalityCoordinates(p.locality).lng;
        const dist = calculateDistanceKm(uLat, uLng, lat, lng);
        return {
          ...p,
          latitude: lat,
          longitude: lng,
          distanceKm: dist
        };
      });
      if (maxDist !== null && !isNaN(maxDist)) {
        filtered = filtered.filter((p) => p.distanceKm !== void 0 && p.distanceKm <= maxDist);
      }
    }
    if (sort === "price-low") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sort === "price-high") {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sort === "popular") {
      filtered.sort((a, b) => (b.ordersCount || 0) * 3 + (b.viewsCount || 0) - ((a.ordersCount || 0) * 3 + (a.viewsCount || 0)));
    } else if (sort === "nearest" && hasUserCoords) {
      filtered.sort((a, b) => (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999));
    } else {
      filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    res.json({ count: filtered.length, products: filtered });
  });
  app.get("/api/products/:id", (req, res) => {
    const { id } = req.params;
    const allProducts = db.getData().products || [];
    const product = allProducts.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    const requester = getRequester(req);
    const isOwner = requester && requester.id === product.merchantId;
    const isAdmin = requester && requester.role === "admin";
    const business = db.getData().businesses.find((b) => b.id === product.businessId) || null;
    if ((product.isDemo || product.status !== "approved" || business && business.isDemo) && !isOwner && !isAdmin) {
      res.status(403).json({ error: "This product is pending review or currently unavailable." });
      return;
    }
    if (product.status === "approved" && !product.isDemo) {
      product.viewsCount = (product.viewsCount || 0) + 1;
      db.saveData();
    }
    const otherShopProducts = allProducts.filter(
      (p) => p.businessId === product.businessId && p.id !== product.id && p.status === "approved" && p.isActive !== false
    ).slice(0, 6);
    res.json({ product, shop: business, otherProducts: otherShopProducts });
  });
  app.post("/api/orders", ordersLimiter, (req, res) => {
    const { businessId, items, customerName, customerPhone, customerEmail, fulfillmentType, deliveryAddress, customerNotes } = req.body;
    if (!businessId || typeof businessId !== "string") {
      res.status(400).json({ error: "Shop/Business ID is required." });
      return;
    }
    const business = db.getData().businesses.find((b) => b.id === businessId);
    if (!business) {
      res.status(404).json({ error: "Selected shop was not found." });
      return;
    }
    if (!items || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: "At least one product item is required to place an order." });
      return;
    }
    if (!customerName || typeof customerName !== "string" || customerName.trim().length < 2) {
      res.status(400).json({ error: "Customer name is required (minimum 2 characters)." });
      return;
    }
    const cleanPhone = String(customerPhone || "").replace(/\D/g, "");
    if (!cleanPhone || cleanPhone.length < 10) {
      res.status(400).json({ error: "Please enter a valid 10-digit mobile contact number." });
      return;
    }
    const fType = fulfillmentType === "pickup" ? "pickup" : "delivery";
    if (fType === "delivery" && (!deliveryAddress || typeof deliveryAddress !== "string" || deliveryAddress.trim().length < 5)) {
      res.status(400).json({ error: "Delivery address is required for local home delivery orders." });
      return;
    }
    const allProducts = db.getData().products || [];
    const orderItems = [];
    let subtotal = 0;
    for (const item of items) {
      const prod = allProducts.find((p) => p.id === item.productId);
      if (!prod) {
        res.status(400).json({ error: `Product with ID ${item.productId} was not found.` });
        return;
      }
      if (prod.businessId !== businessId) {
        res.status(400).json({
          error: `Item "${prod.name}" belongs to a different shop. CityDeals orders must be placed per individual shop.`
        });
        return;
      }
      if (!prod.inStock || prod.stockQuantity <= 0) {
        res.status(400).json({ error: `"${prod.name}" is currently out of stock.` });
        return;
      }
      const qty = Math.max(1, Math.min(99, Number(item.quantity) || 1));
      const linePrice = prod.price * qty;
      subtotal += linePrice;
      prod.stockQuantity = Math.max(0, prod.stockQuantity - qty);
      if (prod.stockQuantity === 0) {
        prod.inStock = false;
      }
      prod.ordersCount = (prod.ordersCount || 0) + qty;
      orderItems.push({
        productId: prod.id,
        productName: prod.name,
        price: prod.price,
        quantity: qty,
        imageUrl: prod.imageUrl,
        category: prod.category
      });
    }
    const deliveryFee = fType === "pickup" ? 0 : subtotal >= 1e3 ? 0 : 30;
    const totalAmount = subtotal + deliveryFee;
    const requester = getRequester(req);
    const orderNumber = `CD-ORD-${Date.now().toString().slice(-5)}`;
    const newOrder = {
      id: `ord-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
      orderNumber,
      customerId: requester?.id,
      customerName: customerName.trim(),
      customerPhone: String(customerPhone).trim(),
      customerEmail: customerEmail ? String(customerEmail).trim() : void 0,
      businessId: business.id,
      merchantId: business.merchantId,
      shopName: business.name,
      shopAddress: business.address,
      shopPhone: business.phone,
      shopWhatsapp: business.whatsapp,
      items: orderItems,
      subtotal,
      deliveryFee,
      totalAmount,
      fulfillmentType: fType,
      deliveryAddress: fType === "delivery" ? deliveryAddress?.trim() : void 0,
      customerNotes: customerNotes ? String(customerNotes).trim() : void 0,
      status: "pending",
      paymentMethod: fType === "pickup" ? "pay_at_store" : "cash_on_delivery",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (!db.getData().orders) db.getData().orders = [];
    db.getData().orders.unshift(newOrder);
    db.saveData();
    persistToFirestore("orders", newOrder.id, newOrder);
    for (const item of newOrder.items) {
      const prod = allProducts.find((p) => p.id === item.productId);
      if (prod) {
        persistToFirestore("products", prod.id, prod);
      }
    }
    recordAuditLog(
      requester || { id: "usr-guest", name: customerName, email: customerEmail || "guest@citydeals.in", role: "public", createdAt: (/* @__PURE__ */ new Date()).toISOString() },
      "create",
      "order",
      newOrder.id,
      `Placed shopping order ${newOrder.orderNumber} for \u20B9${newOrder.totalAmount} at ${business.name}`
    );
    console.log(`[CityDeals Orders] New order ${newOrder.orderNumber} placed for ${business.name}.`);
    res.status(201).json({
      success: true,
      message: `Your order ${newOrder.orderNumber} has been received by ${business.name}!`,
      order: newOrder
    });
  });
  app.get("/api/orders/my", (req, res) => {
    const requester = getRequester(req);
    const phone = req.query.phone;
    const allOrders = db.getData().orders || [];
    let customerOrders = allOrders.filter((ord) => {
      if (requester && ord.customerId === requester.id) return true;
      if (phone && ord.customerPhone.replace(/\D/g, "") === phone.replace(/\D/g, "")) return true;
      return false;
    });
    res.json({ count: customerOrders.length, orders: customerOrders });
  });
  app.get("/api/orders/:id", (req, res) => {
    const { id } = req.params;
    const allOrders = db.getData().orders || [];
    const order = allOrders.find((o) => o.id === id || o.orderNumber === id);
    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }
    res.json({ order });
  });
  app.post("/api/orders/:id/cancel", (req, res) => {
    const { id } = req.params;
    const { reason } = req.body;
    const allOrders = db.getData().orders || [];
    const order = allOrders.find((o) => o.id === id);
    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }
    if (order.status !== "pending" && order.status !== "accepted") {
      res.status(400).json({ error: `Cannot cancel an order that is already ${order.status.replace(/_/g, " ")}.` });
      return;
    }
    order.status = "cancelled";
    order.merchantNotes = reason || "Order cancelled by customer.";
    order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const allProducts = db.getData().products || [];
    for (const item of order.items) {
      const prod = allProducts.find((p) => p.id === item.productId);
      if (prod) {
        prod.stockQuantity += item.quantity;
        prod.inStock = true;
        persistToFirestore("products", prod.id, prod);
      }
    }
    db.saveData();
    persistToFirestore("orders", order.id, order);
    res.json({ success: true, message: "Order has been cancelled.", order });
  });
  app.get("/api/auth/demo-credentials", (_req, res) => {
    res.status(404).json({
      error: "Demo credentials have been permanently disabled to protect real authentication security."
    });
  });
  app.post("/api/auth/register", authLimiter, (req, res) => {
    const { name, email, password, role, phone, referralCode } = req.body;
    if (!name || typeof name !== "string" || name.trim().length < 2) {
      res.status(400).json({ error: "Full name is required (minimum 2 characters)." });
      return;
    }
    if (!email || typeof email !== "string" || !email.includes("@")) {
      res.status(400).json({ error: "A valid email address is required." });
      return;
    }
    if (!password || typeof password !== "string" || password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters long." });
      return;
    }
    if (role === "admin") {
      res.status(403).json({
        error: "Administrator accounts cannot be self-registered. Admin access requires direct platform provisioning."
      });
      return;
    }
    const normalizedEmail = email.toLowerCase().trim();
    const existing = db.getData().users.find((u) => u.email.toLowerCase() === normalizedEmail);
    if (existing) {
      res.status(400).json({ error: "An account with this email address already exists. Please sign in instead." });
      return;
    }
    let referrer = null;
    let referralStatus = null;
    let referralNotes = "";
    if (referralCode && typeof referralCode === "string" && referralCode.trim() !== "") {
      const cleanedCode = referralCode.trim().toUpperCase();
      const found = db.getData().users.find((u) => u.referralCode?.toUpperCase() === cleanedCode);
      if (found) {
        if (found.email.toLowerCase() === normalizedEmail) {
          referrer = null;
          referralNotes = "Self-referral rejected (matching email address)";
        } else {
          referrer = found;
          const clientIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown";
          const recentFromIp = (db.getData().referrals || []).filter(
            (r) => r.ipAddress === clientIp && Date.now() - new Date(r.createdAt).getTime() < 36e5
          );
          if (recentFromIp.length >= 3) {
            referralStatus = "flagged";
            referralNotes = "Flagged for review: Multiple registrations detected from same IP within 1 hour.";
          } else {
            referralStatus = "verified";
            referralNotes = "Attributed to verified referral link.";
          }
        }
      }
    }
    const salt = crypto.randomBytes(16).toString("hex");
    const passwordHash = hashPassword(password, salt);
    const assignedRole = role === "merchant" ? "merchant" : "public";
    const newUserId = `usr-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
    const userReferralCode = generateReferralCode(name.trim(), newUserId);
    const newUser = {
      id: newUserId,
      name: name.trim(),
      email: normalizedEmail,
      role: assignedRole,
      phone: phone ? String(phone).trim() : void 0,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      passwordHash,
      salt,
      referralCode: userReferralCode,
      referredBy: referrer ? referrer.referralCode : void 0,
      referralCount: 0,
      isDemo: false
    };
    db.getData().users.push(newUser);
    if (referrer && referralStatus) {
      const newReferral = {
        id: `ref-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
        referrerId: referrer.id,
        referrerName: referrer.name,
        referrerEmail: referrer.email,
        referrerCode: referrer.referralCode || "",
        referredUserId: newUser.id,
        referredUserName: newUser.name,
        referredUserEmail: newUser.email,
        referredUserRole: newUser.role,
        status: referralStatus,
        notes: referralNotes,
        ipAddress: req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        verifiedAt: referralStatus === "verified" ? (/* @__PURE__ */ new Date()).toISOString() : void 0
      };
      if (!db.getData().referrals) db.getData().referrals = [];
      db.getData().referrals.unshift(newReferral);
      if (referralStatus === "verified") {
        referrer.referralCount = (referrer.referralCount || 0) + 1;
      }
      recordAuditLog(
        referrer,
        "referral_attributed",
        "referral",
        newUser.id,
        `New ${newUser.role} user "${newUser.name}" joined via referral code "${referrer.referralCode}". Status: ${referralStatus}`
      );
    }
    const token = generateSecureToken();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString();
    const session = {
      token,
      userId: newUser.id,
      role: newUser.role,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      expiresAt
    };
    db.getData().sessions.push(session);
    db.saveData();
    persistToFirestore("users", newUser.id, sanitizeUser(newUser));
    if (referrer && referralStatus) {
      persistToFirestore("users", referrer.id, sanitizeUser(referrer));
    }
    res.status(201).json({
      success: true,
      message: "Account registered successfully.",
      token,
      user: sanitizeUser(newUser),
      business: null
    });
  });
  app.post("/api/auth/login", authLimiter, (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "Both email and password are required." });
      return;
    }
    const normalizedEmail = String(email).toLowerCase().trim();
    const user = db.getData().users.find((u) => u.email.toLowerCase() === normalizedEmail);
    if (!user || !user.passwordHash || !user.salt) {
      res.status(401).json({ error: "Invalid email or password." });
      return;
    }
    const isValid = verifyPassword(String(password), user.passwordHash, user.salt);
    if (!isValid) {
      res.status(401).json({ error: "Invalid email or password." });
      return;
    }
    const now = /* @__PURE__ */ new Date();
    db.getData().sessions = db.getData().sessions.filter((s) => s.userId !== user.id || new Date(s.expiresAt) > now);
    const token = generateSecureToken();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString();
    const session = {
      token,
      userId: user.id,
      role: user.role,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      expiresAt
    };
    db.getData().sessions.push(session);
    db.saveData();
    const business = db.getData().businesses.find((b) => b.merchantId === user.id) || null;
    res.json({
      success: true,
      token,
      user: sanitizeUser(user),
      business
    });
  });
  app.post("/api/auth/logout", (req, res) => {
    const authHeader = req.headers["authorization"];
    if (authHeader && authHeader.startsWith("Bearer ")) {
      const token = authHeader.substring(7).trim();
      const initialCount = db.getData().sessions.length;
      db.getData().sessions = db.getData().sessions.filter((s) => s.token !== token);
      if (db.getData().sessions.length !== initialCount) {
        db.saveData();
      }
    }
    res.json({ success: true, message: "Logged out successfully." });
  });
  app.get("/api/auth/me", (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Session expired or not authenticated." });
      return;
    }
    const business = db.getData().businesses.find((b) => b.merchantId === requester.id) || null;
    res.json({ user: requester, business });
  });
  app.post("/api/auth/forgot-password", passwordResetLimiter, (req, res) => {
    const { email } = req.body;
    if (!email || typeof email !== "string" || !email.includes("@")) {
      res.status(400).json({ error: "Please enter a valid email address." });
      return;
    }
    const normalizedEmail = email.toLowerCase().trim();
    const user = db.getData().users.find((u) => u.email.toLowerCase() === normalizedEmail);
    if (!user) {
      res.status(404).json({
        error: "No CityDeals account found with this email address. Please check your spelling or register for a new account."
      });
      return;
    }
    const resetToken = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1e3).toISOString();
    if (!db.getData().passwordResets) {
      db.getData().passwordResets = [];
    }
    db.getData().passwordResets = db.getData().passwordResets.filter(
      (pr) => pr.email.toLowerCase() !== normalizedEmail || pr.usedAt
    );
    const resetRecord = {
      id: `pr-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`,
      email: user.email,
      userId: user.id,
      token: resetToken,
      expiresAt,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    db.getData().passwordResets.push(resetRecord);
    db.saveData();
    let origin = process.env.APP_URL;
    if (!origin || origin === "MY_APP_URL") {
      const forwardedProto = req.headers["x-forwarded-proto"] || "https";
      const forwardedHost = req.headers["x-forwarded-host"] || req.headers.host;
      if (forwardedHost) {
        origin = `${forwardedProto}://${forwardedHost}`;
      } else if (req.headers.origin) {
        origin = String(req.headers.origin);
      } else if (req.headers.referer) {
        try {
          origin = new URL(String(req.headers.referer)).origin;
        } catch {
          origin = `http://localhost:${PORT}`;
        }
      } else {
        origin = `http://localhost:${PORT}`;
      }
    }
    const resetUrl = `${origin}/?reset_token=${resetToken}`;
    recordAuditLog(
      user,
      "password_reset_requested",
      "user",
      user.id,
      `Password reset email generated for ${user.email}. Valid for 60 minutes.`
    );
    console.log(`[CityDeals Auth] Password reset email sent to: ${user.email}`);
    console.log(`[CityDeals Auth] Verification link: ${resetUrl}`);
    res.json({
      success: true,
      message: `Password reset instructions have been sent to ${user.email}.`,
      email: user.email,
      resetToken,
      resetLink: resetUrl,
      expiresInMinutes: 60
    });
  });
  app.get("/api/auth/verify-reset-token", (req, res) => {
    const token = req.query.token;
    if (!token || typeof token !== "string") {
      res.status(400).json({ valid: false, error: "Password reset token is missing." });
      return;
    }
    const resets = db.getData().passwordResets || [];
    const record = resets.find((pr) => pr.token === token.trim());
    if (!record) {
      res.status(400).json({ valid: false, error: "Invalid or unknown password reset link. Please request a new one." });
      return;
    }
    if (record.usedAt) {
      res.status(400).json({ valid: false, error: "This password reset link has already been used. Please request a new one." });
      return;
    }
    if (new Date(record.expiresAt) < /* @__PURE__ */ new Date()) {
      res.status(400).json({
        valid: false,
        error: "This password reset link has expired. Password reset links are valid for 60 minutes."
      });
      return;
    }
    const user = db.getData().users.find((u) => u.id === record.userId);
    if (!user) {
      res.status(404).json({ valid: false, error: "Associated user account no longer exists." });
      return;
    }
    res.json({
      valid: true,
      email: user.email,
      name: user.name
    });
  });
  app.post("/api/auth/reset-password", passwordResetLimiter, (req, res) => {
    const { token, newPassword } = req.body;
    if (!token || typeof token !== "string") {
      res.status(400).json({ error: "Password reset token is required." });
      return;
    }
    if (!newPassword || typeof newPassword !== "string" || newPassword.length < 6) {
      res.status(400).json({ error: "New password must be at least 6 characters long." });
      return;
    }
    const resets = db.getData().passwordResets || [];
    const record = resets.find((pr) => pr.token === token.trim());
    if (!record) {
      res.status(400).json({ error: "Invalid or unknown password reset link. Please request a new one." });
      return;
    }
    if (record.usedAt) {
      res.status(400).json({ error: "This password reset link has already been used. Please request a new one." });
      return;
    }
    if (new Date(record.expiresAt) < /* @__PURE__ */ new Date()) {
      res.status(400).json({ error: "This password reset link has expired. Please request a new one." });
      return;
    }
    const user = db.getData().users.find((u) => u.id === record.userId);
    if (!user) {
      res.status(404).json({ error: "Associated user account was not found." });
      return;
    }
    const salt = crypto.randomBytes(16).toString("hex");
    const passwordHash = hashPassword(newPassword, salt);
    user.salt = salt;
    user.passwordHash = passwordHash;
    record.usedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.getData().sessions = db.getData().sessions.filter((s) => s.userId !== user.id);
    db.saveData();
    persistToFirestore("users", user.id, sanitizeUser(user));
    recordAuditLog(
      user,
      "password_reset_completed",
      "user",
      user.id,
      `Password successfully reset for ${user.email}. All previous sessions invalidated.`
    );
    console.log(`[CityDeals Auth] Password successfully reset for: ${user.email}`);
    res.json({
      success: true,
      message: "Your password has been reset successfully. Please sign in with your new password.",
      email: user.email
    });
  });
  app.get("/api/referrals/validate/:code", (req, res) => {
    const { code } = req.params;
    if (!code || typeof code !== "string") {
      res.status(400).json({ valid: false, message: "Referral code is required." });
      return;
    }
    const cleanCode = code.trim().toUpperCase();
    const referrer = db.getData().users.find((u) => u.referralCode?.toUpperCase() === cleanCode);
    if (!referrer) {
      res.status(404).json({ valid: false, message: "Invalid or unknown referral code." });
      return;
    }
    res.json({
      valid: true,
      code: referrer.referralCode,
      referrerName: referrer.name.split(" ")[0],
      // First name only for privacy
      referrerRole: referrer.role,
      referrer: {
        name: referrer.name.split(" ")[0],
        role: referrer.role,
        code: referrer.referralCode || ""
      },
      message: `You've been invited by ${referrer.name.split(" ")[0]} to discover local offers on CityDeals!`
    });
  });
  app.get("/api/referrals/me", (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "The caller doesn't have permission. Authentication required." });
      return;
    }
    const currentUser = db.getData().users.find((u) => u.id === requester.id);
    if (!currentUser) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    if (!currentUser.referralCode) {
      currentUser.referralCode = generateReferralCode(currentUser.name, currentUser.id);
      db.saveData();
    }
    const userReferrals = (db.getData().referrals || []).filter((r) => r.referrerId === requester.id);
    const verifiedCount = userReferrals.filter((r) => r.status === "verified").length;
    const pendingCount = userReferrals.filter((r) => r.status === "pending" || r.status === "flagged").length;
    res.json({
      referralCode: currentUser.referralCode,
      referralCount: verifiedCount,
      pendingCount,
      campaignConfig: db.getData().referralConfig || DEFAULT_REFERRAL_CONFIG,
      referrals: userReferrals.map((r) => ({
        id: r.id,
        referredUserName: r.referredUserName.split(" ")[0] + " " + (r.referredUserName.split(" ")[1]?.[0] || "") + ".",
        referredUserRole: r.referredUserRole,
        status: r.status,
        createdAt: r.createdAt
      }))
    });
  });
  const requireMerchantOrAdmin = (req, res, next) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "The caller doesn't have permission. Authentication required." });
      return;
    }
    if (requester.role !== "merchant" && requester.role !== "admin") {
      res.status(403).json({
        error: "The caller doesn't have permission. Merchant privilege required. Public accounts cannot access merchant tools."
      });
      return;
    }
    next();
  };
  app.get("/api/merchant/business", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    const business = db.getData().businesses.find((b) => b.merchantId === requester.id);
    res.json({ business: business || null });
  });
  const handleSaveBusiness = (req, res) => {
    const requester = getRequester(req);
    const {
      name,
      category,
      state,
      district,
      districtId,
      city,
      locality,
      localityId,
      address,
      fullAddress,
      landmark,
      phone,
      whatsapp,
      description,
      logoUrl,
      openingHours
    } = req.body;
    const resolvedDistrict = district || city || "Dibrugarh";
    const resolvedDistrictId = districtId || resolvedDistrict.toLowerCase().replace(/\s+/g, "_");
    const resolvedState = state || "Assam";
    const resolvedFullAddress = fullAddress || address || `${locality}, ${resolvedDistrict}`;
    if (!name || !category || !locality || !phone) {
      res.status(400).json({ error: "Shop name, category, district, locality, address and phone are required." });
      return;
    }
    const coords = getLocalityCoordinates(locality, resolvedDistrict);
    let business = db.getData().businesses.find((b) => b.merchantId === requester.id);
    if (business) {
      business.name = name;
      business.category = category;
      business.state = resolvedState;
      business.district = resolvedDistrict;
      business.districtId = resolvedDistrictId;
      business.city = resolvedDistrict;
      business.locality = locality;
      if (localityId) business.localityId = localityId;
      business.address = address || business.address || resolvedFullAddress;
      business.fullAddress = resolvedFullAddress;
      business.landmark = landmark || business.landmark;
      business.phone = phone;
      business.whatsapp = whatsapp || business.whatsapp;
      business.description = description || business.description;
      business.openingHours = openingHours || business.openingHours || "10:00 AM \u2013 8:00 PM (Mon\u2013Sat)";
      business.latitude = coords.lat;
      business.longitude = coords.lng;
      if (logoUrl) business.logoUrl = logoUrl;
    } else {
      business = {
        id: `biz-${Date.now()}`,
        merchantId: requester.id,
        name,
        category,
        state: resolvedState,
        district: resolvedDistrict,
        districtId: resolvedDistrictId,
        city: resolvedDistrict,
        locality,
        localityId: localityId || locality.toLowerCase().replace(/\s+/g, "-"),
        address: address || resolvedFullAddress,
        fullAddress: resolvedFullAddress,
        landmark: landmark || "",
        phone,
        whatsapp: whatsapp || phone,
        email: requester.email,
        description: description || "",
        logoUrl: logoUrl || "https://images.unsplash.com/photo-1556740738-b6a63e27c4df?auto=format&fit=crop&w=400&q=80",
        openingHours: openingHours || "10:00 AM \u2013 8:30 PM (Mon\u2013Sat)",
        status: "pending",
        // Strictly starts as pending until approved by admin
        verified: false,
        latitude: coords.lat,
        longitude: coords.lng,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        isDemo: false
      };
      db.getData().businesses.push(business);
      requester.businessId = business.id;
    }
    db.saveData();
    persistToFirestore("businesses", business.id, business);
    persistToFirestore("users", requester.id, requester);
    res.json({ success: true, business });
  };
  app.put("/api/merchant/business", requireMerchantOrAdmin, handleSaveBusiness);
  app.post("/api/merchant/business", requireMerchantOrAdmin, handleSaveBusiness);
  app.get("/api/merchant/offers", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    const merchantOffers = db.getData().offers.filter((o) => o.merchantId === requester.id || o.merchantEmail === requester.email);
    res.json({
      count: merchantOffers.length,
      offers: merchantOffers
    });
  });
  app.post("/api/merchant/offers", requireMerchantOrAdmin, async (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "The caller doesn't have permission. Authentication required." });
      return;
    }
    if (requester.role !== "merchant" && requester.role !== "admin") {
      res.status(403).json({
        error: "The caller doesn't have permission to manage offers. Only verified shopkeepers and administrators are authorized."
      });
      return;
    }
    const {
      headline,
      discountValue,
      description,
      category,
      state,
      district,
      districtId,
      city,
      locality,
      localityId,
      address,
      fullAddress,
      landmark,
      terms,
      contactPhone,
      contactWhatsapp,
      locationUrl,
      imageUrl,
      validFrom,
      validUntil,
      startDate,
      expiryDate,
      openingHours,
      isDistrictWide
    } = req.body;
    const effectiveExpiry = expiryDate || validUntil;
    if (!headline || !discountValue || !category || !effectiveExpiry) {
      res.status(400).json({ error: "Headline, discount value, category and validity/expiry date are required." });
      return;
    }
    const isAdmin = requester.role === "admin";
    const business = db.getData().businesses.find((b) => b.merchantId === requester.id);
    const shopName = business?.name || req.body.shopName || (isAdmin ? "CityDeals Verified Partner" : `${requester.name}'s Shop`);
    const submittedDist = typeof district === "string" && district.trim() ? district.trim() : typeof city === "string" && city.trim() ? city.trim() : null;
    const resolvedDistrict = submittedDist || business?.district || business?.city || "Dibrugarh";
    const resolvedDistrictId = districtId || business?.districtId || resolvedDistrict.toLowerCase().replace(/\s+/g, "_");
    const submittedLocality = typeof locality === "string" && locality.trim() ? locality.trim() : null;
    const resolvedLocality = submittedLocality || business?.locality || `${resolvedDistrict} Central`;
    const resolvedState = state || business?.state || "Assam";
    const resolvedFullAddress = typeof fullAddress === "string" && fullAddress.trim() ? fullAddress.trim() : typeof address === "string" && address.trim() ? address.trim() : business?.fullAddress || business?.address || `${resolvedLocality}, ${resolvedDistrict}`;
    const coords = getLocalityCoordinates(resolvedLocality, resolvedDistrict);
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    const effectiveStart = startDate || validFrom || nowIso;
    const offerId = `off-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
    const newOffer = {
      id: offerId,
      businessId: business?.id || (isAdmin ? "biz-admin-direct" : `biz-${requester.id}`),
      merchantId: requester.id,
      merchantEmail: requester.email,
      shopName,
      state: resolvedState,
      district: resolvedDistrict,
      districtId: resolvedDistrictId,
      city: resolvedDistrict,
      // backwards compatibility
      locality: resolvedLocality,
      localityId: localityId || resolvedLocality.toLowerCase().replace(/\s+/g, "-"),
      address: address || resolvedFullAddress,
      fullAddress: resolvedFullAddress,
      landmark: landmark || business?.landmark || "",
      category,
      headline,
      discountValue,
      description: description || "",
      terms: Array.isArray(terms) && terms.length > 0 ? terms : [
        `Visit physical shop in ${resolvedLocality}, ${resolvedDistrict} to redeem.`,
        "Present CityDeals offer screen at cash counter before billing.",
        "Cannot be combined with other store promotions."
      ],
      contactPhone: contactPhone || business?.phone || "+91 94350 00000",
      contactWhatsapp: contactWhatsapp || business?.whatsapp || contactPhone,
      locationUrl: locationUrl || `https://maps.google.com/?q=${encodeURIComponent(resolvedLocality + " " + resolvedDistrict + " Assam")}`,
      imageUrl: imageUrl || "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80",
      openingHours: openingHours || business?.openingHours || "10:00 AM \u2013 8:00 PM",
      validFrom: effectiveStart,
      validUntil: effectiveExpiry,
      startDate: effectiveStart,
      expiryDate: effectiveExpiry,
      status: isAdmin ? "approved" : "pending",
      isActive: true,
      isDistrictWide: Boolean(isDistrictWide),
      latitude: coords.lat,
      longitude: coords.lng,
      rejectionReason: null,
      moderationNotes: isAdmin ? "Created and approved directly by authorized administrator." : "Awaiting initial administrator review.",
      isSponsored: false,
      viewsCount: 0,
      clicksCount: 0,
      createdAt: nowIso,
      updatedAt: nowIso,
      isDemo: false
    };
    try {
      await persistToFirestore("offers", newOffer.id, newOffer);
      db.getData().offers.unshift(newOffer);
      db.saveData();
    } catch (dbErr) {
      console.error("[Offer Creation Error] Failed to persist offer to Firestore:", dbErr.message);
      res.status(500).json({
        error: "Failed to write offer document to Firestore database. Please check connection and try again."
      });
      return;
    }
    res.status(201).json({
      success: true,
      message: isAdmin ? "Offer published directly by administrator and is live in the public directory." : "Offer submitted successfully! It is now pending admin moderation before appearing in the public shop directory.",
      offer: newOffer
    });
  });
  app.put("/api/merchant/offers/:id", requireMerchantOrAdmin, async (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "The caller doesn't have permission. Authentication required." });
      return;
    }
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    if (offer.merchantId !== requester.id && requester.role !== "admin") {
      res.status(403).json({ error: "The caller doesn't have permission to modify this offer." });
      return;
    }
    const fields = req.body;
    if (fields.headline) offer.headline = fields.headline;
    if (fields.discountValue) offer.discountValue = fields.discountValue;
    if (fields.description !== void 0) offer.description = fields.description;
    if (fields.category) offer.category = fields.category;
    if (fields.terms) offer.terms = fields.terms;
    if (fields.state) offer.state = fields.state;
    if (fields.district) {
      offer.district = fields.district;
      offer.districtId = fields.districtId || fields.district.toLowerCase().replace(/\s+/g, "_");
      offer.city = fields.district;
    }
    if (fields.locality) {
      offer.locality = fields.locality;
      if (fields.localityId) offer.localityId = fields.localityId;
      const coords = getLocalityCoordinates(fields.locality, offer.district || offer.city);
      offer.latitude = coords.lat;
      offer.longitude = coords.lng;
    }
    if (fields.address) offer.address = fields.address;
    if (fields.fullAddress) offer.fullAddress = fields.fullAddress;
    if (fields.landmark !== void 0) offer.landmark = fields.landmark;
    if (fields.contactPhone) offer.contactPhone = fields.contactPhone;
    if (fields.contactWhatsapp) offer.contactWhatsapp = fields.contactWhatsapp;
    if (fields.validUntil || fields.expiryDate) {
      offer.validUntil = fields.validUntil || fields.expiryDate;
      offer.expiryDate = fields.expiryDate || fields.validUntil;
    }
    if (fields.validFrom || fields.startDate) {
      offer.validFrom = fields.validFrom || fields.startDate;
      offer.startDate = fields.startDate || fields.validFrom;
    }
    if (fields.imageUrl) offer.imageUrl = fields.imageUrl;
    if (fields.openingHours) offer.openingHours = fields.openingHours;
    if (fields.isDistrictWide !== void 0) offer.isDistrictWide = Boolean(fields.isDistrictWide);
    if (offer.status === "rejected" || offer.status === "approved") {
      offer.status = "pending";
      offer.rejectionReason = null;
      offer.moderationNotes = "Re-submitted with updates by merchant. Awaiting admin review.";
    }
    offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await persistToFirestore("offers", offer.id, offer);
      db.saveData();
    } catch (err) {
      res.status(500).json({ error: "Failed to update offer in Firestore: " + err.message });
      return;
    }
    res.json({
      success: true,
      message: "Offer updated and queued for admin review.",
      offer
    });
  });
  app.post("/api/merchant/offers/:id/toggle-active", requireMerchantOrAdmin, async (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    if (offer.merchantId !== requester.id && requester.role !== "admin") {
      res.status(403).json({ error: "The caller doesn't have permission to modify this offer." });
      return;
    }
    offer.isActive = !offer.isActive;
    offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    try {
      await persistToFirestore("offers", offer.id, offer);
      db.saveData();
    } catch (err) {
      res.status(500).json({ error: "Failed to sync status change to Firestore: " + err.message });
      return;
    }
    res.json({
      success: true,
      message: offer.isActive ? "Offer activated." : "Offer deactivated and hidden from directory.",
      isActive: offer.isActive
    });
  });
  app.delete("/api/merchant/offers/:id", requireMerchantOrAdmin, async (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "The caller doesn't have permission. Authentication required." });
      return;
    }
    const { id } = req.params;
    const index = db.getData().offers.findIndex((o) => o.id === id);
    if (index === -1) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    const offer = db.getData().offers[index];
    if (offer.merchantId !== requester.id && requester.role !== "admin") {
      res.status(403).json({ error: "The caller doesn't have permission to modify this offer." });
      return;
    }
    db.getData().offers.splice(index, 1);
    db.saveData();
    try {
      await removeFromFirestore("offers", id);
    } catch (err) {
      console.warn(`[Firestore Delete Notice] Could not delete offer ${id} from Firestore:`, err.message);
    }
    res.json({ success: true, message: "Offer deleted successfully" });
  });
  app.post("/api/merchant/promotion-requests", requireMerchantOrAdmin, async (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const { offerId, packageId, paymentMethod, transactionReference } = req.body;
    if (!offerId || !packageId) {
      res.status(400).json({ error: "Offer ID and Package ID are required" });
      return;
    }
    const offer = db.getData().offers.find((o) => o.id === offerId);
    if (!offer) {
      res.status(404).json({ error: "Target offer not found" });
      return;
    }
    if (offer.status !== "approved") {
      res.status(400).json({
        error: "Only approved offers can be promoted. Please wait for administrator approval of your offer."
      });
      return;
    }
    const pkg = db.getData().promotionPackages.find((p) => p.id === packageId);
    if (!pkg) {
      res.status(404).json({ error: "Promotion package not found" });
      return;
    }
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    const newRequest = {
      id: `prq-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
      merchantId: requester.id,
      merchantEmail: requester.email,
      businessId: offer.businessId,
      offerId: offer.id,
      offerHeadline: offer.headline,
      shopName: offer.shopName,
      packageId: pkg.id,
      packageName: `${pkg.name} (${pkg.durationDays} Days)`,
      tier: pkg.tier,
      priceInr: pkg.priceInr,
      feeAmount: pkg.priceInr,
      durationDays: pkg.durationDays,
      paymentMethod: paymentMethod || "UPI Transfer (GPay / PhonePe / Paytm)",
      transactionReference: transactionReference || `REF-${Date.now().toString().slice(-6)}`,
      paymentReference: transactionReference || `REF-${Date.now().toString().slice(-6)}`,
      paymentStatus: "pending",
      status: "pending",
      // Promotion must remain inactive until admin approval
      adminNotes: "Submitted by merchant. Awaiting administrator verification of payment reference.",
      requestedAt: nowIso,
      createdAt: nowIso
    };
    try {
      await persistToFirestore("promotionRequests", newRequest.id, newRequest);
      db.getData().promotionRequests.unshift(newRequest);
      db.saveData();
    } catch (err) {
      res.status(500).json({ error: "Failed to save promotion request: " + err.message });
      return;
    }
    res.status(201).json({
      success: true,
      message: "Promotion request submitted for admin payment verification. Promotion remains inactive until approved by admin.",
      promotionRequest: newRequest
    });
  });
  app.get("/api/merchant/promotion-requests", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const requests = db.getData().promotionRequests.filter((pr) => pr.merchantId === requester.id);
    res.json({ promotionRequests: requests });
  });
  app.get("/api/merchant/verification", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const verificationList = db.getData().verificationRequests || [];
    const request = verificationList.find((vr) => vr.merchantId === requester.id);
    const business = db.getData().businesses.find((b) => b.merchantId === requester.id);
    res.json({
      request: request || null,
      business: business || null,
      verificationFee: 499
    });
  });
  app.post("/api/merchant/verification-requests", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const business = db.getData().businesses.find((b) => b.merchantId === requester.id);
    if (!business) {
      res.status(400).json({ error: "Please register your shop profile before applying for verification." });
      return;
    }
    const {
      tradeLicenseNumber,
      gstNumber,
      documentType,
      documentUrl,
      documentName,
      paymentMethod,
      paymentReference
    } = req.body;
    if (!documentUrl || typeof documentUrl !== "string" || documentUrl.trim().length === 0) {
      res.status(400).json({ error: "Please upload a valid business verification document (Trade License, GST Certificate, or Establishment Proof)." });
      return;
    }
    if (!paymentReference || typeof paymentReference !== "string" || paymentReference.trim().length < 3) {
      res.status(400).json({ error: "Please enter a valid payment transaction reference / UTR number." });
      return;
    }
    if (!db.getData().verificationRequests) {
      db.getData().verificationRequests = [];
    }
    const existing = db.getData().verificationRequests.find(
      (vr) => vr.merchantId === requester.id && (vr.status === "pending_review" || vr.status === "verified")
    );
    if (existing && existing.status === "verified") {
      res.status(400).json({ error: "Your shop is already verified with an active trust badge." });
      return;
    }
    const newRequest = {
      id: `vreq-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
      businessId: business.id,
      merchantId: requester.id,
      merchantEmail: requester.email,
      shopName: business.name,
      ownerName: requester.name,
      phone: business.phone || requester.phone || "",
      locality: business.locality,
      district: business.district || business.city || "Dibrugarh",
      address: business.fullAddress || business.address || "",
      tradeLicenseNumber: tradeLicenseNumber ? String(tradeLicenseNumber).trim() : void 0,
      gstNumber: gstNumber ? String(gstNumber).trim() : void 0,
      documentType: documentType || "trade_license",
      documentUrl: String(documentUrl).trim(),
      documentName: documentName ? String(documentName).trim() : "Verification_Document.pdf",
      verificationFee: 499,
      paymentMethod: paymentMethod || "UPI Transfer (GPay / PhonePe / Paytm)",
      paymentReference: String(paymentReference).trim(),
      status: "pending_review",
      adminNotes: "Submitted by shopkeeper. Awaiting administrative review and document authentication.",
      requestedAt: (/* @__PURE__ */ new Date()).toISOString(),
      isDemo: false
    };
    db.getData().verificationRequests.unshift(newRequest);
    db.saveData();
    persistToFirestore("verificationRequests", newRequest.id, newRequest);
    recordAuditLog(
      requester,
      "submit_verification",
      "business",
      business.id,
      `Merchant submitted shop verification application for "${business.name}" (Ref: ${newRequest.paymentReference})`
    );
    res.status(201).json({
      success: true,
      message: "Shop verification request submitted successfully! CityDeals administrators will verify your credentials within 24 hours.",
      request: newRequest
    });
  });
  app.get("/api/merchant/products", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const business = db.getData().businesses.find((b) => b.merchantId === requester.id);
    if (!business) {
      res.json({ count: 0, products: [] });
      return;
    }
    const allProducts = db.getData().products || [];
    const merchantProducts = allProducts.filter((p) => p.businessId === business.id);
    res.json({ count: merchantProducts.length, products: merchantProducts });
  });
  app.post("/api/merchant/products", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const business = db.getData().businesses.find((b) => b.merchantId === requester.id);
    if (!business) {
      res.status(400).json({ error: "Please register your shop profile before adding catalog products." });
      return;
    }
    const {
      name,
      category,
      description,
      price,
      originalPrice,
      stockQuantity,
      imageUrl,
      additionalImages,
      videoUrl,
      deliveryAvailable,
      pickupAvailable,
      fulfillmentOptions
    } = req.body;
    if (!name || typeof name !== "string" || name.trim().length < 2) {
      res.status(400).json({ error: "Product name is required (minimum 2 characters)." });
      return;
    }
    if (!price || isNaN(Number(price)) || Number(price) <= 0) {
      res.status(400).json({ error: "Please enter a valid product price in INR." });
      return;
    }
    const stock = stockQuantity !== void 0 ? Math.max(0, Number(stockQuantity)) : 10;
    const cleanPrice = Math.round(Number(price));
    const cleanOrigPrice = originalPrice && !isNaN(Number(originalPrice)) ? Math.round(Number(originalPrice)) : void 0;
    const cleanAdditionalImages = Array.isArray(additionalImages) ? additionalImages.filter((img) => typeof img === "string" && img.trim().length > 0) : [];
    const isDelivery = deliveryAvailable !== void 0 ? Boolean(deliveryAvailable) : true;
    const isPickup = pickupAvailable !== void 0 ? Boolean(pickupAvailable) : true;
    const fOptions = Array.isArray(fulfillmentOptions) && fulfillmentOptions.length > 0 ? fulfillmentOptions : [
      ...isDelivery ? ["delivery"] : [],
      ...isPickup ? ["pickup"] : []
    ];
    const newProduct = {
      id: `prod-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`,
      businessId: business.id,
      merchantId: requester.id,
      merchantEmail: requester.email,
      shopName: business.name,
      city: business.district || business.city || "Dibrugarh",
      locality: business.locality,
      address: business.address,
      category: category || business.category || "other-shops",
      name: name.trim(),
      description: description ? String(description).trim() : "Authentic product from local shop.",
      price: cleanPrice,
      originalPrice: cleanOrigPrice,
      stockQuantity: stock,
      inStock: stock > 0,
      imageUrl: imageUrl?.trim() || (cleanAdditionalImages[0] || "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=800&q=80"),
      additionalImages: cleanAdditionalImages,
      videoUrl: videoUrl ? String(videoUrl).trim() : void 0,
      deliveryAvailable: isDelivery,
      pickupAvailable: isPickup,
      fulfillmentOptions: fOptions,
      status: "pending",
      // Always requires admin approval
      isActive: true,
      contactPhone: business.phone,
      contactWhatsapp: business.whatsapp,
      latitude: business.latitude,
      longitude: business.longitude,
      viewsCount: 0,
      ordersCount: 0,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      isDemo: false
    };
    if (!db.getData().products) db.getData().products = [];
    db.getData().products.unshift(newProduct);
    db.saveData();
    persistToFirestore("products", newProduct.id, newProduct);
    recordAuditLog(
      requester,
      "create",
      "product",
      newProduct.id,
      `Submitted product "${newProduct.name}" for \u20B9${newProduct.price} for moderation`
    );
    res.status(201).json({
      success: true,
      message: "Product submitted successfully! It will appear in CityDeals Shopping once approved by moderation.",
      product: newProduct
    });
  });
  app.put("/api/merchant/products/:id", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const { id } = req.params;
    const allProducts = db.getData().products || [];
    const product = allProducts.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    if (product.merchantId !== requester.id && requester.role !== "admin") {
      res.status(403).json({ error: "You do not have permission to edit this product." });
      return;
    }
    const {
      name,
      category,
      description,
      price,
      originalPrice,
      stockQuantity,
      inStock,
      imageUrl,
      additionalImages,
      videoUrl,
      isActive,
      deliveryAvailable,
      pickupAvailable,
      fulfillmentOptions
    } = req.body;
    if (name) product.name = String(name).trim();
    if (category) product.category = String(category);
    if (description !== void 0) product.description = String(description).trim();
    if (price !== void 0 && !isNaN(Number(price))) product.price = Math.round(Number(price));
    if (originalPrice !== void 0) product.originalPrice = originalPrice ? Math.round(Number(originalPrice)) : void 0;
    if (stockQuantity !== void 0 && !isNaN(Number(stockQuantity))) {
      product.stockQuantity = Math.max(0, Number(stockQuantity));
      product.inStock = product.stockQuantity > 0;
    }
    if (inStock !== void 0) product.inStock = Boolean(inStock);
    if (imageUrl) product.imageUrl = String(imageUrl).trim();
    if (Array.isArray(additionalImages)) {
      product.additionalImages = additionalImages.filter((img) => typeof img === "string" && img.trim().length > 0);
    }
    if (videoUrl !== void 0) product.videoUrl = videoUrl ? String(videoUrl).trim() : void 0;
    if (isActive !== void 0) product.isActive = Boolean(isActive);
    if (deliveryAvailable !== void 0) product.deliveryAvailable = Boolean(deliveryAvailable);
    if (pickupAvailable !== void 0) product.pickupAvailable = Boolean(pickupAvailable);
    if (Array.isArray(fulfillmentOptions)) {
      product.fulfillmentOptions = fulfillmentOptions;
    }
    product.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("products", product.id, product);
    res.json({ success: true, message: "Product updated successfully.", product });
  });
  app.post("/api/merchant/products/:id/toggle-stock", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const { id } = req.params;
    const allProducts = db.getData().products || [];
    const product = allProducts.find((p) => p.id === id);
    if (!product || product.merchantId !== requester.id && requester.role !== "admin") {
      res.status(404).json({ error: "Product not found or access denied." });
      return;
    }
    product.inStock = !product.inStock;
    product.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("products", product.id, product);
    res.json({ success: true, inStock: product.inStock, message: `Product marked as ${product.inStock ? "In Stock" : "Out of Stock"}.` });
  });
  app.delete("/api/merchant/products/:id", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const { id } = req.params;
    const allProducts = db.getData().products || [];
    const index = allProducts.findIndex((p) => p.id === id);
    if (index === -1) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    if (allProducts[index].merchantId !== requester.id && requester.role !== "admin") {
      res.status(403).json({ error: "Permission denied." });
      return;
    }
    allProducts.splice(index, 1);
    db.saveData();
    removeFromFirestore("products", id);
    res.json({ success: true, message: "Product removed from catalog." });
  });
  app.get("/api/merchant/orders", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const userBusinesses = db.getData().businesses.filter((b) => b.merchantId === requester.id);
    const userBizIds = new Set(userBusinesses.map((b) => b.id));
    if (requester.businessId) userBizIds.add(requester.businessId);
    const allOrders = db.getData().orders || [];
    const merchantOrders = allOrders.filter(
      (o) => o.merchantId === requester.id || userBizIds.has(o.businessId)
    );
    res.json({ count: merchantOrders.length, orders: merchantOrders });
  });
  app.post("/api/merchant/orders/:id/status", requireMerchantOrAdmin, (req, res) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const { id } = req.params;
    const { status, merchantNotes } = req.body;
    const validStatuses = [
      "pending",
      "accepted",
      "rejected",
      "preparing",
      "ready_for_pickup",
      "out_for_delivery",
      "delivered",
      "cancelled"
    ];
    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: `Invalid order status: ${status}` });
      return;
    }
    const allOrders = db.getData().orders || [];
    const order = allOrders.find((o) => o.id === id);
    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }
    if (order.merchantId !== requester.id && requester.role !== "admin") {
      res.status(403).json({ error: "Permission denied. You can only update orders for your own shop." });
      return;
    }
    const oldStatus = order.status;
    order.status = status;
    if (merchantNotes) order.merchantNotes = String(merchantNotes).trim();
    order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("orders", order.id, order);
    recordAuditLog(
      requester,
      "update_order_status",
      "order",
      order.id,
      `Changed order ${order.orderNumber} status from ${oldStatus} to ${status}`
    );
    res.json({ success: true, message: `Order status updated to ${status.replace(/_/g, " ")}.`, order });
  });
  const requireAdmin = (req, res, next) => {
    const requester = getRequester(req);
    if (!requester) {
      res.status(401).json({ error: "The caller doesn't have permission. Authentication required." });
      return;
    }
    const isAuthorizedAdmin = requester.role === "admin" && (requester.email.toLowerCase().trim() === "citydeals.discoverlocal@gmail.com" || (process.env.ADMIN_EMAIL ? requester.email.toLowerCase().trim() === process.env.ADMIN_EMAIL.toLowerCase().trim() : false));
    if (!isAuthorizedAdmin) {
      res.status(403).json({ error: "The caller doesn't have permission. Administrator privilege required." });
      return;
    }
    next();
  };
  app.get("/api/admin/stats", requireAdmin, (req, res) => {
    const data = db.getData();
    const includeDemo = req.query.includeDemo === "true";
    const targetOffers = includeDemo ? data.offers : data.offers.filter((o) => !o.isDemo);
    const targetBusinesses = includeDemo ? data.businesses : data.businesses.filter((b) => !b.isDemo);
    const targetReports = includeDemo ? data.reports : data.reports.filter((r) => !r.isDemo);
    const targetPromotions = includeDemo ? data.promotionRequests : data.promotionRequests.filter((p) => !p.isDemo);
    const allUsers = data.users || [];
    const uniqueNonAdminUsers = /* @__PURE__ */ new Map();
    const adminUids = /* @__PURE__ */ new Set(["usr-admin-founder", "firebase-uid-admin-citydeals-789", "Qx2QmFZluVMRftETWEQ44USyIDs1"]);
    for (const u of allUsers) {
      if (u.role === "admin" || adminUids.has(u.id) || u.email && u.email.toLowerCase().trim() === "citydeals.discoverlocal@gmail.com") {
        continue;
      }
      const key = u.email ? u.email.toLowerCase().trim() : u.id;
      if (!uniqueNonAdminUsers.has(key)) {
        uniqueNonAdminUsers.set(key, u);
      }
    }
    const uniqueUsersList = Array.from(uniqueNonAdminUsers.values());
    const totalRegisteredUsers = uniqueUsersList.length;
    const totalCustomers = uniqueUsersList.filter((u) => u.role === "public" || u.role === "customer").length;
    const totalMerchants = uniqueUsersList.filter((u) => u.role === "merchant").length;
    const pendingOffers = targetOffers.filter((o) => o.status === "pending").length;
    const approvedOffers = targetOffers.filter((o) => o.status === "approved" && o.isActive !== false).length;
    const rejectedOffers = targetOffers.filter((o) => o.status === "rejected").length;
    const openReports = targetReports.filter((r) => r.status === "open").length;
    const pendingPromotions = targetPromotions.filter((p) => p.status === "pending_verification").length;
    const totalViews = targetOffers.reduce((acc, o) => acc + (o.viewsCount || 0), 0);
    const totalClicks = targetOffers.reduce((acc, o) => acc + (o.clicksCount || 0), 0);
    const totalShares = targetOffers.reduce((acc, o) => acc + (o.sharesCount || 0), 0);
    const pendingShops = targetBusinesses.filter((b) => b.status === "pending").length;
    const allProducts = data.products || [];
    const pendingProducts = allProducts.filter((p) => p.status === "pending").length;
    const allOrders = data.orders || [];
    const totalOrders = allOrders.length;
    const pendingOrders = allOrders.filter((o) => o.status === "pending").length;
    res.json({
      stats: {
        totalRegisteredUsers,
        totalCustomers,
        totalMerchants,
        totalOffers: targetOffers.length,
        pendingOffers,
        approvedOffers,
        rejectedOffers,
        totalShops: targetBusinesses.length,
        openReports,
        pendingPromotions,
        pendingShops,
        totalViews,
        totalClicks,
        totalShares,
        pendingProducts,
        totalProducts: allProducts.length,
        totalOrders,
        pendingOrders
      }
    });
  });
  app.get("/api/admin/products", requireAdmin, (req, res) => {
    const { status, search } = req.query;
    let list = [...db.getData().products || []];
    if (status && typeof status === "string" && status !== "all") {
      list = list.filter((p) => p.status === status);
    }
    if (search && typeof search === "string" && search.trim() !== "") {
      const q = search.toLowerCase().trim();
      list = list.filter((p) => p.name.toLowerCase().includes(q) || p.shopName.toLowerCase().includes(q));
    }
    list.sort((a, b) => {
      if (a.status === "pending" && b.status !== "pending") return -1;
      if (a.status !== "pending" && b.status === "pending") return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    res.json({ products: list });
  });
  app.post("/api/admin/products/:id/approve", requireAdmin, (req, res) => {
    const { id } = req.params;
    const allProducts = db.getData().products || [];
    const product = allProducts.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    const requester = getRequester(req);
    product.status = "approved";
    product.isActive = true;
    product.rejectionReason = void 0;
    product.moderationNotes = `Approved by admin on ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`;
    product.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("products", product.id, product);
    recordAuditLog(
      requester,
      "approve_product",
      "product",
      product.id,
      `Approved product "${product.name}" for shop "${product.shopName}"`
    );
    res.json({
      success: true,
      message: `Product "${product.name}" approved and live in CityDeals Shopping marketplace!`,
      product
    });
  });
  app.post("/api/admin/products/:id/reject", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { reason, moderationNotes } = req.body;
    if (!reason || String(reason).trim() === "") {
      res.status(400).json({ error: "Rejection reason is mandatory when rejecting a product." });
      return;
    }
    const allProducts = db.getData().products || [];
    const product = allProducts.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    const requester = getRequester(req);
    product.status = "rejected";
    product.rejectionReason = String(reason).trim();
    product.moderationNotes = moderationNotes || `Rejected by admin on ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`;
    product.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("products", product.id, product);
    recordAuditLog(
      requester,
      "reject_product",
      "product",
      product.id,
      `Rejected product "${product.name}": ${String(reason).trim()}`
    );
    res.json({
      success: true,
      message: "Product rejected.",
      product
    });
  });
  app.post("/api/admin/products/:id/suspend", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { reason } = req.body;
    const allProducts = db.getData().products || [];
    const product = allProducts.find((p) => p.id === id);
    if (!product) {
      res.status(404).json({ error: "Product not found" });
      return;
    }
    const requester = getRequester(req);
    product.status = "suspended";
    product.moderationNotes = reason || "Suspended by admin due to policy violation or merchant inquiry.";
    product.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("products", product.id, product);
    recordAuditLog(
      requester,
      "suspend_product",
      "product",
      product.id,
      `Suspended product "${product.name}": ${reason || "Violation or inquiry"}`
    );
    res.json({ success: true, message: "Product suspended from shopping marketplace.", product });
  });
  app.get("/api/admin/orders", requireAdmin, (req, res) => {
    const { status, search } = req.query;
    let list = [...db.getData().orders || []];
    if (status && typeof status === "string" && status !== "all") {
      list = list.filter((o) => o.status === status);
    }
    if (search && typeof search === "string" && search.trim() !== "") {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (o) => o.orderNumber.toLowerCase().includes(q) || o.customerName.toLowerCase().includes(q) || o.customerPhone.includes(q) || o.shopName.toLowerCase().includes(q)
      );
    }
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json({ count: list.length, orders: list });
  });
  app.get("/api/admin/offers", requireAdmin, (req, res) => {
    const { status, search } = req.query;
    let list = [...db.getData().offers];
    if (status && typeof status === "string" && status !== "all") {
      list = list.filter((o) => o.status === status);
    }
    if (search && typeof search === "string" && search.trim() !== "") {
      const q = search.toLowerCase().trim();
      list = list.filter((o) => o.headline.toLowerCase().includes(q) || o.shopName.toLowerCase().includes(q));
    }
    list.sort((a, b) => {
      if (a.status === "pending" && b.status !== "pending") return -1;
      if (a.status !== "pending" && b.status === "pending") return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    res.json({ offers: list });
  });
  app.post("/api/admin/offers/:id/approve", requireAdmin, async (req, res) => {
    const { id } = req.params;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    const requester = getRequester(req);
    offer.status = "approved";
    offer.isActive = true;
    offer.rejectionReason = null;
    offer.moderationNotes = `Approved by admin on ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`;
    offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const parentShop = db.getData().businesses.find((b) => b.id === offer.businessId);
    if (parentShop && parentShop.status === "pending") {
      parentShop.status = "approved";
    }
    db.saveData();
    try {
      await persistToFirestore("offers", offer.id, offer);
      if (parentShop && parentShop.status === "approved") {
        await persistToFirestore("businesses", parentShop.id, parentShop);
      }
    } catch (err) {
      console.warn(`[Firestore Approve Warning] Offer ${offer.id} Firestore write failed:`, err.message);
    }
    recordAuditLog(
      requester,
      "approve_offer",
      "offer",
      offer.id,
      `Approved offer "${offer.headline}" for shop "${offer.shopName}"`
    );
    res.json({
      success: true,
      message: `Offer "${offer.headline}" approved and live in the Dibrugarh shop directory!`,
      offer
    });
  });
  app.post("/api/admin/offers/:id/reject", requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { reason, moderationNotes } = req.body;
    if (!reason || reason.trim() === "") {
      res.status(400).json({ error: "Rejection reason is mandatory when rejecting an offer." });
      return;
    }
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    const requester = getRequester(req);
    offer.status = "rejected";
    offer.rejectionReason = reason.trim();
    offer.moderationNotes = moderationNotes || `Rejected by admin on ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`;
    offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    try {
      await persistToFirestore("offers", offer.id, offer);
    } catch (err) {
      console.warn(`[Firestore Reject Warning] Offer ${offer.id} Firestore write failed:`, err.message);
    }
    recordAuditLog(
      requester,
      "reject_offer",
      "offer",
      offer.id,
      `Rejected offer "${offer.headline}": ${reason.trim()}`
    );
    res.json({
      success: true,
      message: "Offer rejected and merchant notification logged.",
      offer
    });
  });
  app.post("/api/admin/offers/:id/suspend", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { reason } = req.body;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    const requester = getRequester(req);
    offer.status = "suspended";
    offer.moderationNotes = reason || "Suspended by admin due to violation or merchant inquiry.";
    offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("offers", offer.id, offer);
    recordAuditLog(
      requester,
      "suspend_offer",
      "offer",
      offer.id,
      `Suspended offer "${offer.headline}": ${reason || "Violation or inquiry"}`
    );
    res.json({ success: true, message: "Offer suspended from directory view.", offer });
  });
  app.post("/api/admin/offers/:id/sponsor", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { isSponsored, tier, durationDays } = req.body;
    const offer = db.getData().offers.find((o) => o.id === id);
    if (!offer) {
      res.status(404).json({ error: "Offer not found" });
      return;
    }
    const requester = getRequester(req);
    offer.isSponsored = Boolean(isSponsored);
    offer.sponsorTier = isSponsored ? tier || "boost" : null;
    if (isSponsored) {
      const days = Number(durationDays) || 7;
      const expiry = /* @__PURE__ */ new Date();
      expiry.setDate(expiry.getDate() + days);
      offer.sponsorExpiry = expiry.toISOString();
    } else {
      offer.sponsorExpiry = null;
    }
    offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    db.saveData();
    persistToFirestore("offers", offer.id, offer);
    recordAuditLog(
      requester,
      isSponsored ? "sponsor_offer" : "unsponsor_offer",
      "offer",
      offer.id,
      isSponsored ? `Granted sponsorship tier ${offer.sponsorTier} for ${durationDays || 7} days` : "Removed sponsorship"
    );
    res.json({
      success: true,
      message: isSponsored ? `Offer sponsored with ${offer.sponsorTier} tier.` : "Sponsorship removed.",
      offer
    });
  });
  app.get("/api/admin/shops", requireAdmin, (_req, res) => {
    res.json({ shops: db.getData().businesses });
  });
  app.post("/api/admin/shops/:id/approve", requireAdmin, (req, res) => {
    const { id } = req.params;
    const shop = db.getData().businesses.find((b) => b.id === id);
    if (!shop) {
      res.status(404).json({ error: "Shop not found" });
      return;
    }
    const requester = getRequester(req);
    shop.status = "approved";
    shop.verified = true;
    db.saveData();
    persistToFirestore("businesses", shop.id, shop);
    recordAuditLog(requester, "approve_shop", "business", shop.id, `Approved shop profile for "${shop.name}"`);
    res.json({ success: true, message: `Shop "${shop.name}" approved.`, shop });
  });
  app.post("/api/admin/shops/:id/reject", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { reason } = req.body;
    const shop = db.getData().businesses.find((b) => b.id === id);
    if (!shop) {
      res.status(404).json({ error: "Shop not found" });
      return;
    }
    const requester = getRequester(req);
    shop.status = "rejected";
    shop.rejectionReason = reason || "Shop verification unapproved.";
    db.saveData();
    persistToFirestore("businesses", shop.id, shop);
    recordAuditLog(
      requester,
      "reject_shop",
      "business",
      shop.id,
      `Rejected shop profile for "${shop.name}": ${reason || "Unapproved"}`
    );
    res.json({ success: true, message: `Shop "${shop.name}" rejected.`, shop });
  });
  app.get("/api/admin/reports", requireAdmin, (_req, res) => {
    res.json({ reports: db.getData().reports });
  });
  app.post("/api/admin/reports/:id/resolve", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { status, adminNotes, suspendOffer } = req.body;
    const report = db.getData().reports.find((r) => r.id === id);
    if (!report) {
      res.status(404).json({ error: "Report not found" });
      return;
    }
    const requester = getRequester(req);
    report.status = status || "resolved_action_taken";
    report.adminNotes = adminNotes || "";
    report.resolvedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (suspendOffer) {
      const offer = db.getData().offers.find((o) => o.id === report.offerId);
      if (offer) {
        offer.status = "suspended";
        offer.moderationNotes = `Suspended following user report #${report.id}: ${report.details}`;
        offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        persistToFirestore("offers", offer.id, offer);
      }
    }
    db.saveData();
    persistToFirestore("reports", report.id, report);
    recordAuditLog(
      requester,
      "resolve_report",
      "report",
      report.id,
      `Resolved report for "${report.shopName}" (${status}, suspended: ${Boolean(suspendOffer)})`
    );
    res.json({ success: true, message: "Report resolved.", report });
  });
  app.get("/api/admin/promotion-requests", requireAdmin, (_req, res) => {
    res.json({ promotionRequests: db.getData().promotionRequests });
  });
  app.post("/api/admin/promotion-requests/:id/action", requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { action, adminNotes, startDate, expiresAt, durationDays } = req.body;
    const prq = db.getData().promotionRequests.find((p) => p.id === id);
    if (!prq) {
      res.status(404).json({ error: "Promotion request not found" });
      return;
    }
    const requester = getRequester(req);
    const offer = db.getData().offers.find((o) => o.id === prq.offerId);
    if (action === "approve") {
      prq.status = "approved";
      prq.paymentStatus = "verified";
      prq.adminNotes = adminNotes || "Payment reference verified and promotion approved by administrator.";
      const start = startDate ? new Date(startDate) : /* @__PURE__ */ new Date();
      prq.startDate = start.toISOString();
      const days = durationDays && !isNaN(Number(durationDays)) ? Number(durationDays) : prq.durationDays;
      const expiry = new Date(start);
      expiry.setDate(expiry.getDate() + days);
      prq.expiresAt = expiresAt ? new Date(expiresAt).toISOString() : expiry.toISOString();
    } else if (action === "activate") {
      prq.status = "active";
      prq.paymentStatus = "verified";
      prq.adminNotes = adminNotes || "Promotion campaign activated by administrator.";
      const start = startDate ? new Date(startDate) : prq.startDate ? new Date(prq.startDate) : /* @__PURE__ */ new Date();
      prq.startDate = start.toISOString();
      prq.activatedAt = (/* @__PURE__ */ new Date()).toISOString();
      if (expiresAt) {
        prq.expiresAt = new Date(expiresAt).toISOString();
      } else {
        const days = durationDays && !isNaN(Number(durationDays)) ? Number(durationDays) : prq.durationDays;
        const expiry = new Date(start);
        expiry.setDate(expiry.getDate() + days);
        prq.expiresAt = expiry.toISOString();
      }
      if (offer) {
        offer.isSponsored = true;
        offer.sponsorTier = prq.tier;
        offer.sponsorBadge = prq.tier === "homepage_featured" ? "Homepage Featured" : "Promoted";
        offer.sponsorExpiry = prq.expiresAt;
        offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        await persistToFirestore("offers", offer.id, offer).catch(() => {
        });
      }
    } else if (action === "deactivate") {
      prq.status = "expired";
      prq.adminNotes = adminNotes || "Promotion deactivated by administrator.";
      if (offer) {
        offer.isSponsored = false;
        offer.sponsorExpiry = null;
        offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        await persistToFirestore("offers", offer.id, offer).catch(() => {
        });
      }
    } else {
      prq.status = "rejected";
      prq.paymentStatus = "rejected";
      prq.adminNotes = adminNotes || "Promotion request rejected by administrator.";
      if (offer) {
        offer.isSponsored = false;
        offer.sponsorExpiry = null;
        offer.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        await persistToFirestore("offers", offer.id, offer).catch(() => {
        });
      }
    }
    db.saveData();
    await persistToFirestore("promotionRequests", prq.id, prq).catch(() => {
    });
    recordAuditLog(
      requester,
      `promotion_${action}`,
      "promotion",
      prq.id,
      `${action === "approve" || action === "activate" ? "Activated" : action === "deactivate" ? "Deactivated" : "Rejected"} promotion for "${prq.shopName}" (${prq.packageName})`
    );
    res.json({ success: true, message: `Promotion ${action}d successfully.`, promotionRequest: prq });
  });
  app.get("/api/admin/verification-requests", requireAdmin, (_req, res) => {
    const list = db.getData().verificationRequests || [];
    res.json({ requests: list });
  });
  app.post("/api/admin/verification-requests/:id/action", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { action, adminNotes } = req.body;
    const list = db.getData().verificationRequests || [];
    const vreq = list.find((vr) => vr.id === id);
    if (!vreq) {
      res.status(404).json({ error: "Verification request not found." });
      return;
    }
    const requester = getRequester(req);
    const business = db.getData().businesses.find((b) => b.id === vreq.businessId || b.merchantId === vreq.merchantId);
    if (action === "approve") {
      vreq.status = "verified";
      vreq.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
      const validUntil = /* @__PURE__ */ new Date();
      validUntil.setFullYear(validUntil.getFullYear() + 1);
      vreq.validUntil = validUntil.toISOString();
      vreq.adminNotes = adminNotes || "Business verified by administration after document authentication.";
      if (business) {
        business.isVerified = true;
        business.verifiedBadge = true;
        business.verified = true;
        business.verificationValidUntil = vreq.validUntil;
        business.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
        business.verificationRequestId = vreq.id;
        persistToFirestore("businesses", business.id, business);
        const shopOffers = db.getData().offers.filter((o) => o.businessId === business.id || o.merchantId === business.merchantId);
        const nowIso = (/* @__PURE__ */ new Date()).toISOString();
        for (const o of shopOffers) {
          o.lastVerifiedAt = nowIso;
          o.verifiedBy = "CityDeals Administration";
          persistToFirestore("offers", o.id, o);
        }
      }
    } else if (action === "revoke") {
      vreq.status = "revoked";
      vreq.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
      vreq.adminNotes = adminNotes || "Verification revoked by administration.";
      if (business) {
        business.isVerified = false;
        business.verifiedBadge = false;
        persistToFirestore("businesses", business.id, business);
      }
    } else {
      vreq.status = "rejected";
      vreq.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
      vreq.adminNotes = adminNotes || "Verification rejected. Supporting documents invalid or illegible.";
      if (business) {
        business.isVerified = false;
        business.verifiedBadge = false;
        persistToFirestore("businesses", business.id, business);
      }
    }
    db.saveData();
    persistToFirestore("verificationRequests", vreq.id, vreq);
    recordAuditLog(
      requester,
      `shop_verification_${action}`,
      "business",
      vreq.businessId,
      `${action === "approve" ? "Approved & Granted Verified Badge" : action === "revoke" ? "Revoked Badge" : "Rejected Verification"} for "${vreq.shopName}"`
    );
    res.json({
      success: true,
      message: `Shop verification ${action}d successfully!`,
      request: vreq,
      business: business || null
    });
  });
  app.get("/api/promotion-packages", (_req, res) => {
    res.json({ packages: db.getData().promotionPackages || [] });
  });
  app.put("/api/admin/promotion-packages/:id", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { priceInr, durationDays, description, badge, features } = req.body;
    const pkg = db.getData().promotionPackages.find((p) => p.id === id);
    if (!pkg) {
      res.status(404).json({ error: "Package not found." });
      return;
    }
    if (typeof priceInr === "number" && priceInr >= 0) pkg.priceInr = priceInr;
    if (typeof durationDays === "number" && durationDays > 0) pkg.durationDays = durationDays;
    if (description) pkg.description = description;
    if (badge !== void 0) pkg.badge = badge;
    if (Array.isArray(features)) pkg.features = features;
    db.saveData();
    persistToFirestore("promotionPackages", pkg.id, pkg);
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "update_promotion_package",
      "package",
      pkg.id,
      `Updated pricing/terms for package "${pkg.name}" (\u20B9${pkg.priceInr}, ${pkg.durationDays}d)`
    );
    res.json({ success: true, message: "Promotion package updated successfully.", package: pkg });
  });
  app.get("/api/admin/deal-suggestions", requireAdmin, (_req, res) => {
    res.json({ suggestions: db.getData().dealSuggestions || [] });
  });
  app.post("/api/admin/deal-suggestions/:id/action", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { action, notes } = req.body;
    const list = db.getData().dealSuggestions || [];
    const item = list.find((s) => s.id === id);
    if (!item) {
      res.status(404).json({ error: "Suggestion not found." });
      return;
    }
    item.status = action === "verify" ? "verified_added" : "dismissed";
    item.reviewedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (notes) item.adminNotes = notes;
    db.saveData();
    persistToFirestore("dealSuggestions", item.id, item);
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      `deal_suggestion_${action}`,
      "suggestion",
      item.id,
      `${action === "verify" ? "Verified" : "Dismissed"} deal suggestion "${item.offerHeadline}" for ${item.shopName}`
    );
    res.json({ success: true, message: `Suggestion ${item.status}.`, suggestion: item });
  });
  app.get("/api/admin/audit-logs", requireAdmin, (_req, res) => {
    res.json({ auditLogs: db.getData().auditLogs || [] });
  });
  app.get("/api/admin/referrals", requireAdmin, (_req, res) => {
    const allReferrals = db.getData().referrals || [];
    const config = db.getData().referralConfig || DEFAULT_REFERRAL_CONFIG;
    const totalVerified = allReferrals.filter((r) => r.status === "verified").length;
    const totalFlagged = allReferrals.filter((r) => r.status === "flagged").length;
    const totalPending = allReferrals.filter((r) => r.status === "pending").length;
    const referrerMap = /* @__PURE__ */ new Map();
    allReferrals.forEach((r) => {
      if (r.status === "verified") {
        const cur = referrerMap.get(r.referrerId) || {
          id: r.referrerId,
          name: r.referrerName,
          email: r.referrerEmail,
          code: r.referrerCode,
          role: "user",
          count: 0
        };
        cur.count += 1;
        referrerMap.set(r.referrerId, cur);
      }
    });
    const topReferrers = Array.from(referrerMap.values()).sort((a, b) => b.count - a.count).slice(0, 15);
    res.json({
      stats: {
        totalReferrals: allReferrals.length,
        totalVerified,
        totalFlagged,
        totalPending
      },
      config,
      topReferrers,
      referrals: allReferrals
    });
  });
  app.put("/api/admin/referrals/config", requireAdmin, (req, res) => {
    const { isActive, campaignName, rulesDescription, rewardDescription, qualifyingAction } = req.body;
    const config = db.getData().referralConfig || { ...DEFAULT_REFERRAL_CONFIG };
    if (typeof isActive === "boolean") config.isActive = isActive;
    if (campaignName) config.campaignName = campaignName;
    if (rulesDescription) config.rulesDescription = rulesDescription;
    if (rewardDescription) config.rewardDescription = rewardDescription;
    if (qualifyingAction) config.qualifyingAction = qualifyingAction;
    db.getData().referralConfig = config;
    db.saveData();
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "update_referral_config",
      "referral",
      "campaign_config",
      `Updated referral campaign settings: ${config.campaignName}`
    );
    res.json({ success: true, message: "Referral campaign settings updated successfully.", config });
  });
  app.post("/api/admin/referrals/:id/status", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { status, notes } = req.body;
    const referral = (db.getData().referrals || []).find((r) => r.id === id);
    if (!referral) {
      res.status(404).json({ error: "Referral record not found" });
      return;
    }
    const oldStatus = referral.status;
    referral.status = status;
    if (notes) referral.notes = notes;
    if (status === "verified") referral.verifiedAt = (/* @__PURE__ */ new Date()).toISOString();
    const referrer = db.getData().users.find((u) => u.id === referral.referrerId);
    if (referrer) {
      if (oldStatus !== "verified" && status === "verified") {
        referrer.referralCount = (referrer.referralCount || 0) + 1;
      } else if (oldStatus === "verified" && status !== "verified") {
        referrer.referralCount = Math.max(0, (referrer.referralCount || 1) - 1);
      }
    }
    db.saveData();
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "update_referral_status",
      "referral",
      referral.id,
      `Updated referral ${referral.id} status from ${oldStatus} to ${status}`
    );
    res.json({ success: true, message: `Referral status updated to ${status}.`, referral });
  });
  app.get("/api/admin/districts", requireAdmin, (_req, res) => {
    const districts = db.getData().districts || DEFAULT_DISTRICTS;
    res.json({ districts });
  });
  app.post("/api/admin/districts", requireAdmin, (req, res) => {
    const { name, state = "Assam", isLaunchMarket = false, localities = [] } = req.body;
    if (!name || typeof name !== "string" || !name.trim()) {
      res.status(400).json({ error: "District name is required." });
      return;
    }
    const cleanName = name.trim();
    const id = cleanName.toLowerCase().replace(/[^a-z0-9]/g, "_");
    const existing = (db.getData().districts || []).find((d) => d.id === id);
    if (existing) {
      res.status(400).json({ error: `District with ID "${id}" already exists.` });
      return;
    }
    const newDistrict = {
      id,
      name: cleanName,
      state: state.trim(),
      isActive: true,
      isLaunchMarket: Boolean(isLaunchMarket),
      localities: Array.isArray(localities) ? localities : []
    };
    if (!db.getData().districts) db.getData().districts = [];
    db.getData().districts.push(newDistrict);
    const cityIdx = db.getData().cities.findIndex((c) => c.id === id);
    if (cityIdx >= 0) {
      db.getData().cities[cityIdx].name = cleanName;
    } else {
      db.getData().cities.push({
        id,
        name: cleanName,
        state: state.trim(),
        districtId: id,
        districtName: cleanName,
        isLaunchMarket: Boolean(isLaunchMarket),
        localities: newDistrict.localities.map((l) => l.name)
      });
    }
    db.saveData();
    persistToFirestore("districts", newDistrict.id, newDistrict);
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "create_district",
      "promotion",
      newDistrict.id,
      `Created new district "${newDistrict.name}", state "${newDistrict.state}"`
    );
    res.status(201).json({ success: true, district: newDistrict });
  });
  app.put("/api/admin/districts/:id", requireAdmin, (req, res) => {
    const { id } = req.params;
    const { name, state, isActive, isLaunchMarket } = req.body;
    const district = (db.getData().districts || []).find((d) => d.id === id);
    if (!district) {
      res.status(404).json({ error: "District not found" });
      return;
    }
    if (name && typeof name === "string" && name.trim()) district.name = name.trim();
    if (state && typeof state === "string" && state.trim()) district.state = state.trim();
    if (typeof isActive === "boolean") district.isActive = isActive;
    if (typeof isLaunchMarket === "boolean") district.isLaunchMarket = isLaunchMarket;
    const cityItem = db.getData().cities.find((c) => c.id === id);
    if (cityItem) {
      cityItem.name = district.name;
      cityItem.isLaunchMarket = district.isLaunchMarket;
    }
    db.saveData();
    persistToFirestore("districts", district.id, district);
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "update_district",
      "promotion",
      district.id,
      `Updated district "${district.name}" (isActive: ${district.isActive})`
    );
    res.json({ success: true, district });
  });
  app.post("/api/admin/districts/:districtId/localities", requireAdmin, (req, res) => {
    const { districtId } = req.params;
    const { name, latitude, longitude } = req.body;
    if (!name || typeof name !== "string" || !name.trim()) {
      res.status(400).json({ error: "Locality name is required." });
      return;
    }
    const district = (db.getData().districts || []).find((d) => d.id === districtId);
    if (!district) {
      res.status(404).json({ error: "District not found" });
      return;
    }
    const cleanLocalityName = name.trim();
    const locId = cleanLocalityName.toLowerCase().replace(/[^a-z0-9]/g, "-");
    const existing = (district.localities || []).find((l) => l.id === locId || l.name.toLowerCase() === cleanLocalityName.toLowerCase());
    if (existing) {
      res.status(400).json({ error: `Locality "${cleanLocalityName}" already exists in ${district.name}.` });
      return;
    }
    const coords = latitude && longitude ? { lat: parseFloat(latitude), lng: parseFloat(longitude) } : getLocalityCoordinates(cleanLocalityName, district.name);
    const newLocality = {
      id: locId,
      name: cleanLocalityName,
      districtId: district.id,
      districtName: district.name,
      state: district.state,
      isActive: true,
      latitude: coords.lat,
      longitude: coords.lng
    };
    if (!district.localities) district.localities = [];
    district.localities.push(newLocality);
    const cityItem = db.getData().cities.find((c) => c.id === districtId);
    if (cityItem) {
      if (!cityItem.localities.includes(cleanLocalityName)) {
        cityItem.localities.push(cleanLocalityName);
      }
    }
    db.saveData();
    persistToFirestore("districts", district.id, district);
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "add_locality",
      "promotion",
      `${district.id}/${newLocality.id}`,
      `Added locality "${newLocality.name}" to ${district.name}`
    );
    res.status(201).json({ success: true, locality: newLocality, district });
  });
  app.put("/api/admin/districts/:districtId/localities/:localityId", requireAdmin, (req, res) => {
    const { districtId, localityId } = req.params;
    const { name, isActive, latitude, longitude } = req.body;
    const district = (db.getData().districts || []).find((d) => d.id === districtId);
    if (!district) {
      res.status(404).json({ error: "District not found" });
      return;
    }
    const locality = (district.localities || []).find((l) => l.id === localityId);
    if (!locality) {
      res.status(404).json({ error: "Locality not found in this district" });
      return;
    }
    if (name && typeof name === "string" && name.trim()) locality.name = name.trim();
    if (typeof isActive === "boolean") locality.isActive = isActive;
    if (latitude !== void 0) locality.latitude = parseFloat(latitude);
    if (longitude !== void 0) locality.longitude = parseFloat(longitude);
    db.saveData();
    persistToFirestore("districts", district.id, district);
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "update_locality",
      "promotion",
      `${district.id}/${locality.id}`,
      `Updated locality "${locality.name}" (isActive: ${locality.isActive})`
    );
    res.json({ success: true, locality, district });
  });
  app.delete("/api/admin/districts/:districtId/localities/:localityId", requireAdmin, (req, res) => {
    const { districtId, localityId } = req.params;
    const district = (db.getData().districts || []).find((d) => d.id === districtId);
    if (!district) {
      res.status(404).json({ error: "District not found" });
      return;
    }
    const locIdx = (district.localities || []).findIndex((l) => l.id === localityId);
    if (locIdx === -1) {
      res.status(404).json({ error: "Locality not found in this district" });
      return;
    }
    const removed = district.localities[locIdx];
    district.localities.splice(locIdx, 1);
    const cityItem = db.getData().cities.find((c) => c.id === districtId);
    if (cityItem) {
      cityItem.localities = cityItem.localities.filter((loc) => loc !== removed.name);
    }
    db.saveData();
    persistToFirestore("districts", district.id, district);
    const requester = getRequester(req);
    recordAuditLog(
      requester,
      "delete_locality",
      "promotion",
      `${district.id}/${localityId}`,
      `Removed locality "${removed.name}" from ${district.name}`
    );
    res.json({ success: true, message: `Locality ${removed.name} removed.`, district });
  });
  app.post("/api/admin/seed-reset", requireAdmin, (_req, res) => {
    res.status(403).json({
      error: "Database reset is strictly disabled to prevent loss of genuine user records and active merchant offers."
    });
  });
  app.get("/.well-known/assetlinks.json", (_req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.json([
      {
        relation: ["delegate_permission/common.handle_all_urls"],
        target: {
          namespace: "android_app",
          package_name: "in.citydeals.app",
          sha256_cert_fingerprints: [
            // Standard Android Keystore / Play Store SHA-256 fingerprint
            "14:6D:E9:83:C5:73:06:50:D8:EE:B9:95:2F:34:FC:64:16:A0:83:42:E6:1D:BE:A8:8A:04:96:B2:3F:CF:44:E5"
          ]
        }
      }
    ]);
  });
  app.get("/google494a9977d66ff2c0.html", (_req, res) => {
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.status(200).send("google-site-verification: google494a9977d66ff2c0.html\n");
  });
  app.get("/robots.txt", (req, res) => {
    const proto = req.headers["x-forwarded-proto"]?.split(",")[0]?.trim() || req.protocol || "https";
    const host = req.get("host");
    const sitemapLine = host ? `
Sitemap: ${proto}://${host}/sitemap.xml
` : "\n";
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Cache-Control", "public, max-age=86400");
    res.status(200).send(
      `User-agent: *
Allow: /
Disallow: /api/
Disallow: /admin
Disallow: /merchant
${sitemapLine}`
    );
  });
  app.get("/sitemap.xml", (req, res) => {
    const proto = req.headers["x-forwarded-proto"]?.split(",")[0]?.trim() || req.protocol || "https";
    const host = req.get("host") || "localhost:3000";
    const baseUrl = `${proto}://${host}`;
    const lastMod = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    res.setHeader("Content-Type", "application/xml; charset=utf-8");
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.status(200).send(
      `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}/</loc>
    <lastmod>${lastMod}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
`
    );
  });
  app.all("/api/*", (_req, res) => {
    res.status(404).json({ error: "Endpoint not found" });
  });
  const distPath = path2.join(__dirname2, "dist");
  const isProduction = process.env.NODE_ENV === "production";
  if (isProduction && fs2.existsSync(path2.join(distPath, "index.html"))) {
    app.use(
      express.static(distPath, {
        index: false,
        setHeaders: (res, filePath) => {
          const normalized = filePath.replace(/\\/g, "/");
          if (normalized.includes("/assets/")) {
            res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
          } else if (normalized.endsWith("index.html") || normalized.endsWith("sw.js")) {
            res.setHeader("Cache-Control", "no-cache, must-revalidate");
          } else if (/\.(png|svg|ico|webp|jpg|jpeg|json|txt|xml)$/i.test(normalized)) {
            res.setHeader("Cache-Control", "public, max-age=86400");
          }
        }
      })
    );
    const prodHtmlPath = path2.join(distPath, "index.html");
    const cachedProdHtml = fs2.readFileSync(prodHtmlPath, "utf-8");
    app.get("*", (req, res) => {
      if (req.path.startsWith("/api")) {
        res.status(404).json({ error: "Not found" });
        return;
      }
      const proto = req.headers["x-forwarded-proto"]?.split(",")[0]?.trim() || req.protocol || "https";
      const host = req.get("host");
      const isPrivateRoute = req.path.startsWith("/admin") || req.path.startsWith("/merchant");
      let html = host ? cachedProdHtml.replace("</head>", `  <link rel="canonical" href="${proto}://${host}${isPrivateRoute ? req.path : "/"}" />
  </head>`) : cachedProdHtml;
      if (isPrivateRoute) {
        html = html.replace('<meta name="robots" content="index, follow" />', '<meta name="robots" content="noindex, nofollow" />');
      }
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      res.setHeader("Cache-Control", "no-cache, must-revalidate");
      res.status(200).send(html);
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[CityDeals] Local Shop Directory Server live on http://0.0.0.0:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("[CityDeals] Server startup failure:", err);
  process.exit(1);
});
export {
  processOfferExpirations
};
