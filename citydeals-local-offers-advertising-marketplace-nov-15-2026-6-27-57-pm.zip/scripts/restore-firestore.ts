import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc } from 'firebase/firestore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const configPath = path.join(__dirname, '..', 'firebase-applet-config.json');
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function runRestore() {
  const backupFile = process.argv[2];
  if (!backupFile) {
    console.error('❌ Error: Please specify the backup file to restore.');
    console.log('Usage: npx tsx scripts/restore-firestore.ts <path-to-backup.json>');
    process.exit(1);
  }

  const resolvedPath = path.resolve(backupFile);
  if (!fs.existsSync(resolvedPath)) {
    console.error(`❌ Error: Backup file not found at ${resolvedPath}`);
    process.exit(1);
  }

  const data: Record<string, any[]> = JSON.parse(fs.readFileSync(resolvedPath, 'utf-8'));
  console.log(`♻️ Restoring Firestore collections from ${resolvedPath}...`);

  for (const [colName, docs] of Object.entries(data)) {
    if (!Array.isArray(docs) || docs.length === 0) continue;
    console.log(`Restoring ${docs.length} docs to "${colName}"...`);
    for (const item of docs) {
      const { _id, ...docData } = item;
      const targetId = _id || docData.id;
      if (!targetId) continue;
      await setDoc(doc(firestore, colName, targetId), docData, { merge: true });
    }
    console.log(`  ✓ Finished "${colName}"`);
  }

  console.log('✅ Firestore restore completed successfully!');
  process.exit(0);
}

runRestore().catch(err => {
  console.error('❌ Restore failed:', err);
  process.exit(1);
});
