#!/usr/bin/env node

/**
 * CityDeals Secure Admin Setup Script
 * 
 * Usage:
 *   node scripts/setup-admin.js <email> <password> [fullName]
 * 
 * Example:
 *   node scripts/setup-admin.js faizalsheikh2006@gmail.com "SecurePass@2026" "Faizal Sheikh"
 * 
 * This script runs locally on the server to safely create or elevate an authorized
 * administrator account without exposing private passwords or allowing client-side elevation.
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, '..', 'data', 'citydeals_db.json');

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function generateReferralCode(name, id) {
  const cleanPrefix = (name.replace(/[^a-zA-Z]/g, '').slice(0, 4) || 'ADMN').toUpperCase();
  const uniqueHex = crypto.createHash('md5').update(id + name).digest('hex').slice(0, 4).toUpperCase();
  return `${cleanPrefix}${uniqueHex}`;
}

function run() {
  const args = process.argv.slice(2);
  const email = args[0]?.trim().toLowerCase();
  const password = args[1]?.trim();
  const fullName = args[2]?.trim() || 'CityDeals Administrator';

  if (!email || !email.includes('@')) {
    console.error('❌ Error: Please provide a valid email address.');
    console.log('Usage: node scripts/setup-admin.js <email> <password> [fullName]');
    console.log('Example: node scripts/setup-admin.js faizalsheikh2006@gmail.com "MyAdminPass@123" "Faizal Sheikh"');
    process.exit(1);
  }

  if (!fs.existsSync(DB_PATH)) {
    console.error(`❌ Error: Database file not found at ${DB_PATH}`);
    process.exit(1);
  }

  const rawData = fs.readFileSync(DB_PATH, 'utf-8');
  let db;
  try {
    db = JSON.parse(rawData);
  } catch (err) {
    console.error('❌ Error: Failed to parse database JSON file.', err);
    process.exit(1);
  }

  if (!Array.isArray(db.users)) {
    db.users = [];
  }

  const existingUserIndex = db.users.findIndex(
    (u) => u.email && u.email.trim().toLowerCase() === email
  );

  if (existingUserIndex >= 0) {
    // Elevate existing user
    const existing = db.users[existingUserIndex];
    existing.role = 'admin';
    if (fullName && fullName !== 'CityDeals Administrator') {
      existing.name = fullName;
    }
    if (password) {
      const salt = crypto.randomBytes(16).toString('hex');
      existing.salt = salt;
      existing.passwordHash = hashPassword(password, salt);
    }
    console.log(`✅ Success: User "${email}" has been promoted to role "admin".`);
    if (password) {
      console.log(`🔑 Password updated for "${email}".`);
    } else {
      console.log(`ℹ️ Existing password preserved.`);
    }
  } else {
    // Create new admin user
    if (!password || password.length < 6) {
      console.error('❌ Error: Password is required for new admin and must be at least 6 characters.');
      process.exit(1);
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const newId = `usr-admin-${Date.now().toString(36)}`;
    const newAdmin = {
      id: newId,
      name: fullName,
      email: email,
      role: 'admin',
      phone: '+91 98540 00000',
      createdAt: new Date().toISOString(),
      passwordHash: hashPassword(password, salt),
      salt: salt,
      isDemo: false,
      referralCode: generateReferralCode(fullName, newId),
      referralCount: 0,
    };

    db.users.push(newAdmin);
    console.log(`✅ Success: New administrator account created for "${email}".`);
    console.log(`   Name: ${fullName}`);
    console.log(`   Role: admin`);
    console.log(`   Referral Code: ${newAdmin.referralCode}`);
  }

  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
  console.log(`💾 Database file successfully updated at: ${DB_PATH}`);
}

run();
