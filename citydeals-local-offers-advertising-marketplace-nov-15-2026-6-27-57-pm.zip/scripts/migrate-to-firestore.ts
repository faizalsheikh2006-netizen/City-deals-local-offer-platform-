import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc } from 'firebase/firestore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const configPath = path.join(__dirname, '..', 'firebase-applet-config.json');
const dbPath = path.join(__dirname, '..', 'data', 'citydeals_db.json');

const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app, firebaseConfig.firestoreDatabaseId);

const clean = (obj: any) => {
  const res: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) res[k] = v;
  }
  return res;
};

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function migrateCollection(collectionName: string, items: any[], idField = 'id') {
  if (!Array.isArray(items) || items.length === 0) return;
  console.log(`Migrating ${items.length} records to "${collectionName}"...`);
  for (const item of items) {
    const id = item[idField];
    if (!id) continue;
    try {
      await setDoc(doc(firestore, collectionName, id), clean(item), { merge: true });
      console.log(`  ✓ [${collectionName}] ${id}`);
    } catch (err: any) {
      console.error(`  ✗ [${collectionName}] ${id}: ${err.message}`);
    }
    await sleep(50);
  }
}

async function runMigration() {
  console.log('🚀 Starting CityDeals data migration to Firestore...');
  const rawData = fs.readFileSync(dbPath, 'utf-8');
  const source = JSON.parse(rawData);

  // 1. Categories
  await migrateCollection('categories', source.categories);

  // 2. Cities
  await migrateCollection('cities', source.cities);

  // 3. Promotion Packages
  await migrateCollection('promotionPackages', source.promotionPackages);

  // 4. Users (sanitized)
  if (Array.isArray(source.users)) {
    console.log(`Migrating ${source.users.length} records to "users"...`);
    for (const item of source.users) {
      const { passwordHash, salt, ...safeUser } = item;
      try {
        await setDoc(doc(firestore, 'users', item.id), clean(safeUser), { merge: true });
        console.log(`  ✓ [users] ${item.id} (${item.email})`);
      } catch (err: any) {
        console.error(`  ✗ [users] ${item.id}: ${err.message}`);
      }

      // Seed admins
      if (item.role === 'admin' || item.email === 'faizalsheikh2006@gmail.com' || item.email === 'admin@citydeals.in') {
        try {
          await setDoc(doc(firestore, 'admins', item.id), {
            userId: item.id,
            email: item.email,
            role: 'admin',
            createdAt: item.createdAt || new Date().toISOString()
          }, { merge: true });
          console.log(`  👑 [admins] Registered ${item.id} (${item.email})`);
        } catch (err: any) {
          console.error(`  ✗ [admins] ${item.id}: ${err.message}`);
        }
      }
      await sleep(50);
    }
  }

  // 5. Businesses
  await migrateCollection('businesses', source.businesses);

  // 6. Offers
  await migrateCollection('offers', source.offers);

  // 7. Products
  await migrateCollection('products', source.products);

  // 8. Orders
  await migrateCollection('orders', source.orders);

  // 9. Reports
  await migrateCollection('reports', source.reports);

  // 10. Deal Suggestions
  await migrateCollection('dealSuggestions', source.dealSuggestions);

  // 11. Promotion Requests
  await migrateCollection('promotionRequests', source.promotionRequests);

  // 12. Audit Logs
  await migrateCollection('auditLogs', source.auditLogs);

  console.log('🎉 All existing records migrated to Firestore successfully!');
  process.exit(0);
}

runMigration().catch(err => {
  console.error('Fatal migration error:', err);
  process.exit(1);
});
