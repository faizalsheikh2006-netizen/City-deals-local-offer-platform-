import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const configPath = path.join(__dirname, '..', 'firebase-applet-config.json');
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app, firebaseConfig.firestoreDatabaseId);

const COLLECTIONS = [
  'users',
  'admins',
  'businesses',
  'offers',
  'products',
  'orders',
  'categories',
  'cities',
  'promotionPackages',
  'promotionRequests',
  'reports',
  'dealSuggestions',
  'auditLogs'
];

async function runBackup() {
  console.log('📦 Starting Firestore snapshot backup...');
  const backupData: Record<string, any[]> = {};

  for (const colName of COLLECTIONS) {
    try {
      const snap = await getDocs(collection(firestore, colName));
      backupData[colName] = snap.docs.map(d => ({ _id: d.id, ...d.data() }));
      console.log(`  ✓ Exported ${backupData[colName].length} documents from "${colName}"`);
    } catch (err: any) {
      console.warn(`  ⚠ Warning reading "${colName}": ${err.message}`);
      backupData[colName] = [];
    }
  }

  const backupDir = path.join(__dirname, '..', 'data', 'backups');
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupFile = path.join(backupDir, `firestore_backup_${timestamp}.json`);
  fs.writeFileSync(backupFile, JSON.stringify(backupData, null, 2), 'utf-8');

  console.log(`✅ Snapshot backup saved to: ${backupFile}`);
  process.exit(0);
}

runBackup().catch(err => {
  console.error('❌ Backup failed:', err);
  process.exit(1);
});
