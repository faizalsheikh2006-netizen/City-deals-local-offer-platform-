import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  initializeFirestore,
  getFirestore,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  runTransaction,
  DocumentData,
  QueryConstraint
} from 'firebase/firestore';
import { initializeApp as initAdminApp, getApps as getAdminApps } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const possibleConfigPaths = [
  path.join(process.cwd(), 'firebase-applet-config.json'),
  path.join(__dirname, 'firebase-applet-config.json'),
  path.join(__dirname, '..', 'firebase-applet-config.json'),
];

let configPath = possibleConfigPaths.find((p) => fs.existsSync(p));
if (!configPath) {
  throw new Error('firebase-applet-config.json not found in root directory');
}

const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

// Initialize Firebase App for Firestore queries
const clientApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const firestore = initializeFirestore(
  clientApp,
  {
    ignoreUndefinedProperties: true,
  },
  firebaseConfig.firestoreDatabaseId
);

// Initialize Firebase Admin App for token verification
const adminApp = getAdminApps().length > 0 ? getAdminApps()[0] : initAdminApp({ projectId: firebaseConfig.projectId });
export const adminAuth = getAdminAuth(adminApp);

export {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  runTransaction
};

console.log(`🔥 Connected server to Firestore database: [${firebaseConfig.firestoreDatabaseId}] in project [${firebaseConfig.projectId}]`);
