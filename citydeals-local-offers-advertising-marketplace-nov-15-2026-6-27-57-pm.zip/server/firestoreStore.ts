import {
  firestore,
  adminAuth,
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
} from './firestore';
import { User, AuditLog } from '../src/types/index';

// Helper to remove undefined fields before writing to Firestore
export function sanitizeForFirestore<T extends Record<string, any>>(obj: T): Record<string, any> {
  const result: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      if (value !== null && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date)) {
        result[key] = sanitizeForFirestore(value);
      } else {
        result[key] = value;
      }
    }
  }
  return result;
}

// Persist single document to Firestore
export async function persistToFirestore(
  collectionName: string,
  docId: string,
  data: Record<string, any>
): Promise<void> {
  try {
    const cleanData = sanitizeForFirestore(data);
    await setDoc(doc(firestore, collectionName, docId), cleanData, { merge: true });
  } catch (err: any) {
    console.error(`[Firestore Error] Failed to persist to ${collectionName}/${docId}:`, err.message);
    throw err;
  }
}

// Delete document from Firestore
export async function removeFromFirestore(
  collectionName: string,
  docId: string
): Promise<void> {
  try {
    await deleteDoc(doc(firestore, collectionName, docId));
  } catch (err: any) {
    console.error(`[Firestore Error] Failed to delete from ${collectionName}/${docId}:`, err.message);
    throw err;
  }
}

// Verify Firebase ID Token and resolve user
export async function verifyFirebaseIdToken(token: string): Promise<{ uid: string; email: string; name?: string } | null> {
  try {
    const decoded = await adminAuth.verifyIdToken(token);
    return {
      uid: decoded.uid,
      email: decoded.email || '',
      name: decoded.name || decoded.email?.split('@')[0] || 'User',
    };
  } catch {
    return null;
  }
}

// Load all primary operational collections from Firestore
export async function loadCollectionsFromFirestore(): Promise<{
  businesses?: any[];
  offers?: any[];
  products?: any[];
  orders?: any[];
  categories?: any[];
  cities?: any[];
  districts?: any[];
  promotionPackages?: any[];
  promotionRequests?: any[];
  verificationRequests?: any[];
  reports?: any[];
  dealSuggestions?: any[];
  auditLogs?: any[];
  users?: any[];
}> {
  const result: Record<string, any[] | undefined> = {};
  const targetCollections = [
    'businesses',
    'offers',
    'products',
    'orders',
    'categories',
    'cities',
    'districts',
    'promotionPackages',
    'promotionRequests',
    'verificationRequests',
    'reports',
    'dealSuggestions',
    'auditLogs',
    'users',
  ];

  const fetchWithTimeout = async (col: string, ms = 8000) => {
    return Promise.race([
      getDocs(collection(firestore, col)),
      new Promise<null>((_, reject) =>
        setTimeout(() => reject(new Error(`Timeout fetching ${col}`)), ms)
      ),
    ]);
  };

  for (const col of targetCollections) {
    try {
      const snap = (await fetchWithTimeout(col)) as any;
      result[col] = snap?.docs ? snap.docs.map((d: any) => ({ ...d.data(), id: d.id })) : [];
    } catch {
      // Mark as undefined so callers know not to overwrite existing memory with empty array
      result[col] = undefined;
    }
  }

  return result as any;
}
