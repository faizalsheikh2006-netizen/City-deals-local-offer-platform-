import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { validateFirestoreConnection } from './lib/firebase';
import { initGA } from './lib/analytics';

// Initialize Google Analytics 4 (deferred to idle after load)
initGA();

// Verify live Firestore connection after initial render
if (typeof window !== 'undefined') {
  const runValidation = () => {
    validateFirestoreConnection();
  };
  if ('requestIdleCallback' in window) {
    (window as any).requestIdleCallback(runValidation, { timeout: 2500 });
  } else {
    setTimeout(runValidation, 800);
  }
}

// Register PWA service worker in supported browsers (HTTPS or localhost)
if ('serviceWorker' in navigator && (window.location.protocol === 'https:' || window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        console.log('[CityDeals PWA] Service worker registered successfully:', reg.scope);
      })
      .catch((err) => {
        console.warn('[CityDeals PWA] Service worker registration failed:', err);
      });
  });
}

createRoot(document.getElementById('root')!).render(<App />);
