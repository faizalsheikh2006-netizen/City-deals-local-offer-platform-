import { useState, useCallback } from 'react';

const STORAGE_KEY = 'citydeals_recent_searches';
const MAX_SEARCHES = 8;

export function useRecentSearches() {
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          return parsed
            .filter((item) => typeof item === 'string' && item.trim().length > 0)
            .slice(0, MAX_SEARCHES);
        }
      }
    } catch {
      // fallback on localStorage failure or parse error
    }
    return [];
  });

  const saveSearch = useCallback((query: string) => {
    const trimmed = query.trim();
    if (!trimmed || trimmed.length < 2) return;

    setRecentSearches((prev) => {
      // Deduplicate (case-insensitive) and move latest to top
      const filtered = prev.filter((item) => item.toLowerCase() !== trimmed.toLowerCase());
      const updated = [trimmed, ...filtered].slice(0, MAX_SEARCHES);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore storage quota issues
      }
      return updated;
    });
  }, []);

  const removeSearch = useCallback((queryToRemove: string) => {
    setRecentSearches((prev) => {
      const updated = prev.filter((item) => item !== queryToRemove);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  }, []);

  const clearAllSearches = useCallback(() => {
    setRecentSearches([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }, []);

  return {
    recentSearches,
    saveSearch,
    removeSearch,
    clearAllSearches,
  };
}
