import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { Offer, PromotionPackage } from '../types/index';
import {
  Sparkles,
  X,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  QrCode,
  ShieldCheck,
} from 'lucide-react';

interface PromotionRequestModalProps {
  initialData?: { offerId?: string; packageId?: string; offer?: Offer };
  onClose: () => void;
}

export const PromotionRequestModal: React.FC<PromotionRequestModalProps> = ({
  initialData,
  onClose,
}) => {
  const { promotionPackages, showToast, triggerRefresh } = useApp();

  const [merchantOffers, setMerchantOffers] = useState<Offer[]>([]);
  const [selectedOfferId, setSelectedOfferId] = useState<string>(initialData?.offerId || '');
  const [selectedPkgId, setSelectedPkgId] = useState<string>(initialData?.packageId || 'pkg-popular');
  const [paymentMethod, setPaymentMethod] = useState<string>('UPI Transfer (GPay / PhonePe / Paytm)');
  const [txnRef, setTxnRef] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingOffers, setIsLoadingOffers] = useState(true);

  const approvedOffers = merchantOffers.filter((o) => o.status === 'approved');

  useEffect(() => {
    async function loadOffers() {
      try {
        setIsLoadingOffers(true);
        const res = await api.getMerchantOffers();
        setMerchantOffers(res.offers);
        const approved = res.offers.filter((o) => o.status === 'approved');
        if (!selectedOfferId && approved.length > 0) {
          setSelectedOfferId(approved[0].id);
        } else if (initialData?.offerId) {
          setSelectedOfferId(initialData.offerId);
        }
      } catch (err) {
        console.error('Failed to load merchant offers:', err);
      } finally {
        setIsLoadingOffers(false);
      }
    }
    loadOffers();
  }, []);

  const selectedPkg = promotionPackages.find((p) => p.id === selectedPkgId) || promotionPackages[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOfferId) {
      showToast('Please select an approved offer to promote', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.requestPromotion({
        offerId: selectedOfferId,
        packageId: selectedPkgId,
        paymentMethod,
        transactionReference: txnRef.trim(),
      });

      showToast('Promotion request submitted for admin payment verification!', 'success');
      triggerRefresh();
      onClose();
    } catch (err: any) {
      showToast(err.message || 'Failed to submit promotion request', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500 text-slate-950 font-bold">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Request Sponsored Placement</h2>
              <p className="text-xs text-slate-300">Boost your approved offer across Dibrugarh & Tinsukia</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pricing disclaimer */}
        <div className="bg-amber-50 px-6 py-3 border-b border-amber-200 text-xs text-amber-900 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">Transparent Demonstration Terms:</p>
            <p className="mt-0.5 leading-relaxed text-amber-800">
              Select an introductory promotion plan below. Following submission, an administrator verifies payment before activating your campaign. No automatic activation upon button click.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Target offer selector */}
          <div className="space-y-1.5">
            <label htmlFor="promo-offer-select" className="block text-xs font-bold text-slate-700">
              Select Approved Offer to Boost <span className="text-red-500">*</span>
            </label>
            {isLoadingOffers ? (
              <p className="text-xs text-slate-600">Loading your offers...</p>
            ) : approvedOffers.length === 0 ? (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800">
                You do not have any approved offers yet. Promotions can only be requested for offers that have been reviewed and approved by administrators.
              </div>
            ) : (
              <select
                id="promo-offer-select"
                value={selectedOfferId}
                onChange={(e) => setSelectedOfferId(e.target.value)}
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-medium bg-white text-slate-900"
                required
              >
                {approvedOffers.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.headline} ({o.locality}, {o.discountValue})
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Package Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700">
              Choose Introductory Promotion Plan
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {promotionPackages.map((pkg) => {
                const isSelected = selectedPkgId === pkg.id;
                return (
                  <div
                    key={pkg.id}
                    onClick={() => setSelectedPkgId(pkg.id)}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'border-2 border-blue-600 bg-blue-50/60 shadow-xs ring-2 ring-blue-500/20'
                        : 'border-slate-200 bg-white hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 block uppercase">
                        {pkg.badge || pkg.tier}
                      </span>
                      <h4 className="text-xs font-extrabold text-slate-900 mt-0.5">{pkg.name}</h4>
                    </div>
                    <div className="mt-2">
                      <p className="text-base font-black text-slate-900">₹{pkg.priceInr}</p>
                      <span className="text-[10px] text-slate-500">{pkg.durationDays} days active</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Package preview */}
          {selectedPkg && (
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-2">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Package Benefits Included:</span>
              </span>
              <ul className="space-y-1 text-slate-600">
                {selectedPkg.features.map((feat, i) => (
                  <li key={i} className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Genuine Payment Channel & Transaction Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div>
              <label htmlFor="promo-payment-method" className="block text-xs font-bold text-slate-700 mb-1">
                Payment Channel
              </label>
              <select
                id="promo-payment-method"
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 bg-white text-slate-900 font-medium"
              >
                <option value="UPI Transfer (GPay / PhonePe / Paytm)">UPI Transfer (GPay / PhonePe / Paytm)</option>
                <option value="Direct Bank Transfer (NEFT / IMPS / RTGS)">Direct Bank Transfer (NEFT / IMPS)</option>
                <option value="Debit / Credit Card">Debit / Credit Card</option>
                <option value="Field Representative / Cheque">Dibrugarh Field Representative</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Transaction Reference / UTR Number
              </label>
              <input
                type="text"
                value={txnRef}
                onChange={(e) => setTxnRef(e.target.value)}
                placeholder="e.g. 429381749201 or Bank Ref"
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900 font-mono font-bold"
                required
              />
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-[11px] text-slate-600 space-y-1">
            <p className="font-semibold text-slate-800 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>Admin Verification Policy</span>
            </p>
            <p>
              Your promotion is activated immediately upon administrator verification of your transaction reference. No auto-charges or hidden recurring fees.
            </p>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || approvedOffers.length === 0}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-md transition-all disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isSubmitting ? 'Submitting...' : `Submit Request (₹${selectedPkg?.priceInr || 99})`}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
