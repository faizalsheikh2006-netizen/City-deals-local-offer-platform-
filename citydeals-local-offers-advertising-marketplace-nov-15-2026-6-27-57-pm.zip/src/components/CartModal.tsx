import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ShoppingBag,
  Store,
  Trash2,
  Plus,
  Minus,
  Truck,
  ArrowRight,
  ShieldCheck,
  MapPin,
  AlertCircle,
} from 'lucide-react';

export const CartModal: React.FC = () => {
  const {
    cart,
    closeModal,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    openModal,
    setActiveView,
  } = useApp();

  const [fulfillmentType, setFulfillmentType] = useState<'delivery' | 'pickup'>('delivery');

  if (!cart || cart.items.length === 0) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl max-w-md w-full p-8 text-center shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-200">
          <button
            onClick={closeModal}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="w-8 h-8" />
          </div>

          <h3 className="text-lg font-black text-slate-900">Your shopping cart is empty</h3>
          <p className="text-xs text-slate-500 mt-2 mb-6">
            Discover Assamese silk, authentic tea, handicrafts, gadgets & daily essentials from local Dibrugarh shops.
          </p>

          <button
            onClick={() => {
              closeModal();
              setActiveView('shopping');
            }}
            className="w-full py-3 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm shadow-md shadow-blue-500/25 transition-all cursor-pointer"
          >
            Browse CityDeals Shopping
          </button>
        </div>
      </div>
    );
  }

  const subtotal = cart.items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee = fulfillmentType === 'delivery' ? (subtotal >= 1000 ? 0 : 30) : 0;
  const totalAmount = subtotal + deliveryFee;

  const handleProceedToCheckout = () => {
    openModal('checkout', { fulfillmentType });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-slate-900">Your Shopping Cart</h3>
              <p className="text-xs text-slate-500 font-medium">Fulfilling directly from {cart.shopName}</p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Shop Info Alert Banner */}
        <div className="bg-blue-50/80 px-4 py-2.5 border-b border-blue-100 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-blue-900 font-bold truncate">
            <Store className="w-4 h-4 text-blue-600 shrink-0" />
            <span className="truncate">{cart.shopName} • {cart.shopAddress}</span>
          </div>
          <button
            onClick={clearCart}
            className="text-[11px] text-rose-600 hover:underline font-bold shrink-0 ml-2 cursor-pointer"
          >
            Clear Cart
          </button>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
          {cart.items.map((item) => (
            <div
              key={item.product.id}
              className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200/80"
            >
              <img
                src={item.product.imageUrl}
                alt={item.product.name}
                className="w-16 h-16 rounded-xl object-cover bg-slate-200 shrink-0"
              />

              <div className="flex-1 min-w-0">
                <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 truncate">
                  {item.product.name}
                </h4>
                <p className="text-xs font-black text-blue-700 mt-0.5">
                  ₹{item.product.price.toLocaleString('en-IN')} each
                </p>

                {/* Quantity Controls */}
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center border border-slate-200 rounded-lg bg-white">
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      className="w-6 h-6 flex items-center justify-center text-slate-600 hover:bg-slate-100 rounded-l cursor-pointer"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-7 text-center text-xs font-extrabold text-slate-900">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      className="w-6 h-6 flex items-center justify-center text-slate-600 hover:bg-slate-100 rounded-r cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <span className="text-xs font-black text-slate-900 ml-auto">
                    ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                  </span>

                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                    title="Remove item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Fulfillment Choice */}
        <div className="px-4 sm:px-5 py-3 border-t border-slate-100 bg-slate-50/50">
          <p className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 mb-2">
            Fulfillment Preference
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setFulfillmentType('delivery')}
              className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                fulfillmentType === 'delivery'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Truck className="w-4 h-4 shrink-0" />
              <div className="text-left">
                <p className="leading-tight">Home Delivery</p>
                <p className={`text-[10px] ${fulfillmentType === 'delivery' ? 'text-blue-100' : 'text-slate-400'}`}>
                  {subtotal >= 1000 ? 'Free (₹0)' : '₹30 flat in town'}
                </p>
              </div>
            </button>

            <button
              onClick={() => setFulfillmentType('pickup')}
              className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                fulfillmentType === 'pickup'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Store className="w-4 h-4 shrink-0" />
              <div className="text-left">
                <p className="leading-tight">Store Pickup</p>
                <p className={`text-[10px] ${fulfillmentType === 'pickup' ? 'text-blue-100' : 'text-slate-400'}`}>
                  Free • Pick up at shop
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* Footer Order Summary & Checkout Button */}
        <div className="p-4 sm:p-5 border-t border-slate-200 bg-white rounded-b-3xl space-y-3">
          <div className="space-y-1.5 text-xs text-slate-600">
            <div className="flex justify-between">
              <span>Items Subtotal</span>
              <span className="font-bold text-slate-900">₹{subtotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between">
              <span>Fulfillment Fee</span>
              <span className="font-bold text-slate-900">
                {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
              </span>
            </div>
            <div className="flex justify-between text-sm sm:text-base font-black text-slate-900 pt-1.5 border-t border-slate-100">
              <span>Total Payable</span>
              <span className="text-blue-700">₹{totalAmount.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <button
            onClick={handleProceedToCheckout}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-500/25 transition-all cursor-pointer"
          >
            <span>Proceed to Checkout</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <p className="text-[11px] text-center text-slate-400 font-medium">
            Pay on Delivery or Store Pickup • No online pre-payment required
          </p>
        </div>
      </div>
    </div>
  );
};
