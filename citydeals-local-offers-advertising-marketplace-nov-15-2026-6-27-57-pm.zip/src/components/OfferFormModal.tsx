import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { trackOfferSubmission } from '../lib/analytics';
import { Offer } from '../types/index';
import {
  X,
  Tag,
  Plus,
  Trash2,
  Calendar,
  MapPin,
  Phone,
  Image,
  AlertCircle,
  Sparkles,
  CheckCircle2,
  Store,
  Clock,
} from 'lucide-react';

interface OfferFormModalProps {
  initialOffer?: Offer | null;
  onClose: () => void;
}

const PRESET_IMAGES = [
  {
    label: 'Assam Silk & Fashion Boutique',
    url: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Artisanal Cafe & Restaurant',
    url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Mobile & Electronics Store',
    url: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Fresh Grocery & Spice Mart',
    url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Salon, Spa & Beauty Studio',
    url: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Auto Care & Workshop',
    url: 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=800&q=80',
  },
  {
    label: 'Cane, Bamboo & Home Crafts',
    url: 'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?auto=format&fit=crop&w=800&q=80',
  },
];

export const OfferFormModal: React.FC<OfferFormModalProps> = ({ initialOffer, onClose }) => {
  const {
    user,
    role,
    business,
    categories,
    selectedCity,
    selectedDistrict,
    getLocalitiesForDistrict,
    districts,
    showToast,
    triggerRefresh,
    isAuthenticated,
    openModal,
  } = useApp();
  const isEditing = Boolean(initialOffer);
  const isAdmin = role === 'admin';

  const initialDist = initialOffer?.district || business?.district || initialOffer?.city || business?.city || selectedDistrict || selectedCity || 'Dibrugarh';
  const [district, setDistrict] = useState<string>(initialDist);
  const [headline, setHeadline] = useState(initialOffer?.headline || '');
  const [category, setCategory] = useState(initialOffer?.category || business?.category || 'fashion');
  const [discountValue, setDiscountValue] = useState(initialOffer?.discountValue || '20% OFF IN-STORE');
  const [description, setDescription] = useState(initialOffer?.description || '');
  
  const initialLoc = initialOffer?.locality || business?.locality || (() => {
    const locs = getLocalitiesForDistrict(initialDist);
    return locs.length > 0 ? locs[0].name : `${initialDist} Central`;
  })();
  const [locality, setLocality] = useState(initialLoc);
  const [address, setAddress] = useState(initialOffer?.fullAddress || initialOffer?.address || business?.fullAddress || business?.address || '');
  const [landmark, setLandmark] = useState(initialOffer?.landmark || business?.landmark || '');
  const [isDistrictWide, setIsDistrictWide] = useState<boolean>(Boolean(initialOffer?.isDistrictWide));
  const [openingHours, setOpeningHours] = useState(initialOffer?.openingHours || business?.openingHours || '10:00 AM – 8:30 PM (Mon–Sat)');
  const [contactPhone, setContactPhone] = useState(initialOffer?.contactPhone || business?.phone || '+91 94350 00000');
  const [contactWhatsapp, setContactWhatsapp] = useState(initialOffer?.contactWhatsapp || business?.whatsapp || '');
  const [imageUrl, setImageUrl] = useState(
    initialOffer?.imageUrl || PRESET_IMAGES[0].url
  );

  // Expiry date (default 30 days from now)
  const defaultExpiry = new Date();
  defaultExpiry.setDate(defaultExpiry.getDate() + 30);
  const [validUntil, setValidUntil] = useState(
    initialOffer?.validUntil ? initialOffer.validUntil.split('T')[0] : defaultExpiry.toISOString().split('T')[0]
  );

  // Terms itemized list
  const [terms, setTerms] = useState<string[]>(
    initialOffer?.terms && initialOffer.terms.length > 0
      ? initialOffer.terms
      : [
          `Visit our physical shop in ${initialDist} to browse products and redeem.`,
          'Show this CityDeals offer screen at the cash counter before billing.',
          'Cannot be combined with other ongoing store discounts or clearance stock.',
        ]
  );

  const [newTermInput, setNewTermInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Authorization Guard: If current user is not authorized to manage offers, display a clear error instead of attempting database operations
  if (!isAuthenticated || (role !== 'merchant' && role !== 'admin')) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
        <div className="relative bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden my-6 p-6 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center mx-auto">
            <AlertCircle className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">Permission Denied</h2>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
              The caller does not have permission to manage offers. Only verified shopkeepers and administrators are authorized to create or edit in-store listings.
            </p>
          </div>
          <div className="pt-2 flex flex-col sm:flex-row gap-2.5 justify-center">
            <button
              onClick={() => {
                onClose();
                openModal('auth', { tab: 'login', defaultRole: 'merchant' });
              }}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm cursor-pointer"
            >
              Sign In to Merchant Account
            </button>
            <button
              onClick={() => {
                onClose();
                openModal('auth', { tab: 'register', defaultRole: 'merchant' });
              }}
              className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs cursor-pointer"
            >
              Register as Shopkeeper
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleDistrictChange = (newDist: string) => {
    setDistrict(newDist);
    const locs = getLocalitiesForDistrict(newDist);
    if (locs.length > 0) {
      setLocality(locs[0].name);
    } else {
      setLocality(`${newDist} Central`);
    }
  };

  const handleAddTerm = () => {
    if (!newTermInput.trim()) return;
    setTerms([...terms, newTermInput.trim()]);
    setNewTermInput('');
  };

  const handleRemoveTerm = (index: number) => {
    setTerms(terms.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!headline.trim()) {
      showToast('Please enter an offer headline', 'error');
      return;
    }
    if (!discountValue.trim()) {
      showToast('Please specify the offer discount badge (e.g. Up to 20% Off, BOGO)', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      const resolvedFullAddress = address.trim() || `${locality}, ${district}`;
      const payload: Partial<Offer> = {
        headline: headline.trim(),
        category,
        discountValue: discountValue.trim(),
        description: description.trim(),
        state: 'Assam',
        district,
        districtId: district.toLowerCase().replace(/[^a-z0-9]/g, '_'),
        city: district, // backwards compatibility
        locality,
        localityId: locality.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        address: resolvedFullAddress,
        fullAddress: resolvedFullAddress,
        landmark: landmark.trim(),
        openingHours: openingHours.trim(),
        contactPhone: contactPhone.trim(),
        contactWhatsapp: contactWhatsapp.trim() || contactPhone.trim(),
        imageUrl: imageUrl.trim(),
        validFrom: new Date().toISOString(),
        validUntil: new Date(`${validUntil}T23:59:59Z`).toISOString(),
        startDate: new Date().toISOString(),
        expiryDate: new Date(`${validUntil}T23:59:59Z`).toISOString(),
        terms: terms.length > 0 ? terms : [`Visit physical shop in ${locality}, ${district} to redeem.`],
        shopName: business?.name || (isAdmin ? 'CityDeals Verified Partner' : `${user.name}'s Shop`),
        isDistrictWide,
      };

      if (isEditing && initialOffer) {
        await api.updateOffer(initialOffer.id, payload);
        showToast(isAdmin ? 'Offer updated and published!' : 'Offer updated! Queued for admin review.', 'success');
      } else {
        const res = await api.createOffer(payload);
        showToast(res.message || 'Offer submitted successfully!', 'success');
      }

      // Track GA4 Offer Submission Event
      trackOfferSubmission({
        headline: payload.headline || '',
        category: payload.category || '',
        discountValue: payload.discountValue || '',
        shopName: payload.shopName,
        isEditing,
      });

      triggerRefresh();
      onClose();
    } catch (err: any) {
      showToast(err.message || 'Failed to submit offer', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-600 text-white">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                {isEditing ? 'Edit In-Store Offer' : 'Submit In-Store Offer for Review'}
              </h2>
              <p className="text-xs text-slate-300">
                CityDeals Dibrugarh • Physical Store Directory
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status notification banner */}
        <div className="bg-amber-50 border-amber-200 text-amber-900 px-6 py-2.5 border-b flex items-center gap-2 text-xs font-medium">
          <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
          <span>
            {isEditing
              ? 'Edits are verified before updating in the live directory.'
              : 'Every offer submitted begins as Pending and is reviewed by the moderation team before publication.'}
          </span>
        </div>

        {/* Form Body: In-Store Shop Offer (No product catalogues) */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Offer Headline <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                placeholder="e.g. Up to 20% off selected items, Buy 1 Get 1 on selected menu items, Festival sale"
                className="w-full text-xs sm:text-sm rounded-xl border border-slate-300 p-2.5 font-medium text-slate-900 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="offer-form-category" className="block text-xs font-bold text-slate-700 mb-1">
                  Shop Category <span className="text-red-500">*</span>
                </label>
                <select
                  id="offer-form-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-medium bg-white text-slate-900"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.slug}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Offer Badge / Discount Label <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={discountValue}
                  onChange={(e) => setDiscountValue(e.target.value)}
                  placeholder="e.g. 20% OFF IN-STORE, BUY 1 GET 1, FESTIVAL SPECIAL"
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-bold text-red-600"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Offer Description & Store Details
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                placeholder="Explain what local shoppers will find when they visit your physical shop to avail of this offer..."
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
              />
            </div>
          </div>

          {/* Photo Picker */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700">
              Shop / Storefront Banner Image
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {PRESET_IMAGES.map((img, i) => (
                <div
                  key={i}
                  onClick={() => setImageUrl(img.url)}
                  className={`relative h-16 rounded-xl overflow-hidden border-2 cursor-pointer transition-all ${
                    imageUrl === img.url ? 'border-blue-600 ring-2 ring-blue-500/30' : 'border-slate-200 opacity-75 hover:opacity-100'
                  }`}
                >
                  <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                  <span className="absolute bottom-0 inset-x-0 bg-slate-950/80 text-[9px] text-white text-center py-0.5 truncate px-1">
                    {img.label}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-1">
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="Or paste custom image URL..."
                className="w-full text-xs rounded-xl border border-slate-300 p-2 text-slate-700"
              />
            </div>
          </div>

          {/* Terms & Conditions Builder */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-800">
                In-Store Redemption Terms & Conditions <span className="text-red-500">*</span>
              </label>
              <span className="text-[11px] text-slate-500">Visible on offer details page</span>
            </div>

            <div className="space-y-2">
              {terms.map((term, index) => (
                <div key={index} className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold text-[11px] flex items-center justify-center shrink-0">
                    {index + 1}
                  </span>
                  <input
                    type="text"
                    value={term}
                    onChange={(e) => {
                      const updated = [...terms];
                      updated[index] = e.target.value;
                      setTerms(updated);
                    }}
                    className="flex-1 text-xs rounded-lg border border-slate-300 p-1.5 bg-white text-slate-800"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveTerm(index)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                value={newTermInput}
                onChange={(e) => setNewTermInput(e.target.value)}
                placeholder="Add condition (e.g. Valid on dine-in only, 1 per bill)..."
                className="flex-1 text-xs rounded-lg border border-slate-300 p-2 bg-white text-slate-800"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTerm();
                  }
                }}
              />
              <button
                type="button"
                onClick={handleAddTerm}
                className="inline-flex items-center gap-1 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-3 py-2 rounded-lg"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </div>

          {/* Dynamic Location Hierarchy: District and Locality */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="offer-form-district" className="block text-xs font-bold text-slate-700 mb-1">
                District <span className="text-red-500">*</span>
              </label>
              <select
                id="offer-form-district"
                value={district}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-bold bg-white text-slate-900"
              >
                {['Dibrugarh', 'Tinsukia'].map((d) => (
                  <option key={d} value={d}>
                    {d} District
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="offer-form-locality" className="block text-xs font-bold text-slate-700 mb-1">
                Town / Locality in {district} <span className="text-red-500">*</span>
              </label>
              <select
                id="offer-form-locality"
                value={locality}
                onChange={(e) => setLocality(e.target.value)}
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-medium bg-white text-slate-900"
              >
                {getLocalitiesForDistrict(district).map((loc) => (
                  <option key={loc.id || loc.name} value={loc.name}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Full Physical Store Address <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder={`e.g. Shop 14, Main Market Road, ${locality}, ${district}`}
                required
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Store Opening Hours
              </label>
              <input
                type="text"
                value={openingHours}
                onChange={(e) => setOpeningHours(e.target.value)}
                placeholder="e.g. 10:00 AM – 8:30 PM (Mon–Sat)"
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
              />
            </div>
          </div>

          {/* District-Wide Reach Toggle */}
          <div className="p-3 bg-indigo-50/60 rounded-2xl border border-indigo-200/80 flex items-start gap-3">
            <input
              type="checkbox"
              id="districtWideCheckbox"
              checked={isDistrictWide}
              onChange={(e) => setIsDistrictWide(e.target.checked)}
              className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
            />
            <label htmlFor="districtWideCheckbox" className="text-xs text-slate-700 cursor-pointer">
              <strong className="text-indigo-950 font-bold block">District-Wide Promotion</strong>
              Display this offer across all localities in {district} District (recommended for flagship stores, city-wide sales, and brand showrooms).
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Shop Landmark in Dibrugarh
              </label>
              <input
                type="text"
                value={landmark}
                onChange={(e) => setLandmark(e.target.value)}
                placeholder="e.g. Near Bata Showroom"
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Offer Expiry Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={validUntil}
                onChange={(e) => setValidUntil(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900 font-bold"
                required
              />
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-xl shadow-md transition-all disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>
                {isSubmitting
                  ? 'Saving...'
                  : isEditing
                  ? 'Update Offer'
                  : 'Submit In-Store Offer'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
