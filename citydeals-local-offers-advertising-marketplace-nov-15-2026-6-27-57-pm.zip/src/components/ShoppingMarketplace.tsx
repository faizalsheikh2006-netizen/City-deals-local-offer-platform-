import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { Product, Business } from '../types/index';
import { useRecentSearches } from '../hooks/useRecentSearches';
import {
  Search,
  Filter,
  ShoppingBag,
  Store,
  MapPin,
  Play,
  CheckCircle,
  AlertCircle,
  ChevronRight,
  Plus,
  Compass,
  ArrowUpDown,
  Phone,
  MessageCircle,
  Truck,
  PackageCheck,
  Sparkles,
  Navigation,
  Clock,
  X,
} from 'lucide-react';

export const ShoppingMarketplace: React.FC = () => {
  const {
    openModal,
    cart,
    cartCount,
    addToCart,
    forceAddToCart,
    selectedShopProfileId,
    setSelectedShopProfileId,
    selectedCity,
    selectedDistrict,
    showToast,
    refreshKey,
  } = useApp();

  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLocality, setSelectedLocality] = useState<string>('all');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [maxDistanceKm, setMaxDistanceKm] = useState<number | undefined>(undefined);

  // Cross-shop conflict modal state
  const [shopConflict, setShopConflict] = useState<{
    pendingProduct: Product;
    currentShopName: string;
  } | null>(null);

  // Recent Searches Hook & State
  const { recentSearches, saveSearch, removeSearch, clearAllSearches } = useRecentSearches();
  const [showRecentDropdown, setShowRecentDropdown] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowRecentDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSelectRecent = (term: string) => {
    setSearchQuery(term);
    saveSearch(term);
    setShowRecentDropdown(false);
  };

  // Shop details if filtering by a single shop
  const [currentShop, setCurrentShop] = useState<Business | null>(null);

  // Categories list
  const CATEGORIES = [
    { id: 'all', label: 'All Products' },
    { id: 'fashion', label: 'Assam Silk & Handloom' },
    { id: 'groceries', label: 'Upper Assam Tea & Food' },
    { id: 'electronics', label: 'Electronics & Mobiles' },
    { id: 'home', label: 'Bell Metal & Handicrafts' },
    { id: 'books', label: 'Stationery & Books' },
  ];

  const LOCALITIES = [
    'All Localities',
    'New Market',
    'Graham Bazar',
    'RKB Path',
    'Mancotta Road',
    'Chowkidinghee',
    'Amolapatty',
    'Paltan Bazar',
    'Thana Chariali',
    'Boiragimoth',
  ];

  // Request user GPS
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      showToast('Geolocation is not supported by your browser', 'error');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setIsLocating(false);
        showToast('Location detected! Showing nearest shop products', 'success');
      },
      (err) => {
        setIsLocating(false);
        showToast('Could not fetch location: ' + err.message, 'error');
      },
      { timeout: 8000 }
    );
  };

  // Fetch products
  const fetchProducts = async () => {
    try {
      setIsLoading(true);
      const params: any = {};
      const activeLoc = selectedDistrict || selectedCity;
      if (activeLoc && activeLoc !== 'all') {
        params.district = activeLoc;
        params.city = activeLoc;
      }
      if (selectedCategory !== 'all') params.category = selectedCategory;
      if (selectedLocality !== 'All Localities' && selectedLocality !== 'all') params.locality = selectedLocality;
      if (selectedShopProfileId) params.shopId = selectedShopProfileId;
      if (searchQuery.trim()) params.search = searchQuery.trim();
      if (inStockOnly) params.inStockOnly = true;
      if (sortBy) params.sort = sortBy;
      if (userCoords) {
        params.userLat = userCoords.lat;
        params.userLng = userCoords.lng;
        if (maxDistanceKm) params.maxDistanceKm = maxDistanceKm;
      }

      const res = await api.getProducts(params);
      setProducts(res.products || []);

      // If filtering by shop, get shop info
      if (selectedShopProfileId) {
        try {
          const shopRes = await api.getShopById(selectedShopProfileId);
          setCurrentShop(shopRes.business || null);
        } catch {
          setCurrentShop(null);
        }
      } else {
        setCurrentShop(null);
      }
    } catch (err: any) {
      console.error('Error fetching products:', err);
      showToast(err.message || 'Failed to load products', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [
    selectedDistrict,
    selectedCity,
    selectedCategory,
    selectedLocality,
    selectedShopProfileId,
    inStockOnly,
    sortBy,
    userCoords,
    maxDistanceKm,
    refreshKey,
  ]);

  // Handle Search debounce / submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim().length >= 2) {
      saveSearch(searchQuery.trim());
    }
    setShowRecentDropdown(false);
    fetchProducts();
  };

  // Handle Add To Cart with single shop verification
  const handleAddToCart = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    const result = addToCart(product, 1);
    if (!result.success && result.conflictShopName) {
      setShopConflict({
        pendingProduct: product,
        currentShopName: result.conflictShopName,
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-28">
      {/* Top Banner / Marketplace Hero */}
      <section className="bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 text-white pt-8 pb-12 px-4 sm:px-6 lg:px-8 border-b border-blue-900/40 relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-bold mb-3 shadow-xs">
                <ShoppingBag className="w-3.5 h-3.5 text-blue-400" />
                <span>Hyperlocal Dibrugarh Commerce</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
                CityDeals <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">Shopping</span>
              </h1>
              <p className="mt-2 text-sm sm:text-base text-slate-300 font-medium">
                Order genuine handcrafted goods, Assamese silk, authentic tea, gadgets & fresh essentials directly from verified Dibrugarh shops. Pay on Delivery or Store Pickup.
              </p>
            </div>

            {/* Quick Actions Header Area */}
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                onClick={() => openModal('order-history')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white text-xs sm:text-sm font-bold backdrop-blur-md transition-all cursor-pointer shadow-sm"
              >
                <PackageCheck className="w-4 h-4 text-emerald-400" />
                <span>Track My Orders</span>
              </button>

              <button
                onClick={() => openModal('cart')}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-extrabold transition-all cursor-pointer shadow-md shadow-blue-500/30"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>View Cart ({cartCount})</span>
              </button>
            </div>
          </div>

          {/* Search Bar with Recent Searches */}
          <div ref={searchContainerRef} className="relative mt-6">
            <form onSubmit={handleSearchSubmit}>
              <div className="relative flex items-center shadow-xl rounded-2xl overflow-hidden bg-white/95 backdrop-blur-md border border-slate-200 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all">
                <div className="pl-4 text-slate-400 shrink-0">
                  <Search className="w-5 h-5 text-blue-600" />
                </div>
                <input
                  type="text"
                  aria-label="Search local products by name, craft, tea, or shop"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    if (!showRecentDropdown && recentSearches.length > 0) {
                      setShowRecentDropdown(true);
                    }
                  }}
                  onFocus={() => {
                    if (recentSearches.length > 0) {
                      setShowRecentDropdown(true);
                    }
                  }}
                  placeholder="Search products by name, craft, tea or shop name in Dibrugarh..."
                  className="w-full py-3.5 pl-3 pr-28 text-sm text-slate-900 placeholder:text-slate-500 focus:outline-none font-medium bg-transparent"
                />
                <div className="absolute right-2 flex items-center gap-1.5">
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setShowRecentDropdown(recentSearches.length > 0);
                      }}
                      className="text-xs text-slate-600 hover:text-slate-900 font-bold px-1.5 py-1 cursor-pointer"
                    >
                      Clear
                    </button>
                  )}
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors cursor-pointer shadow-xs"
                  >
                    Search
                  </button>
                </div>
              </div>
            </form>

            {/* Floating Recent Searches Dropdown */}
            {showRecentDropdown && recentSearches.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-1.5 z-40 bg-white rounded-2xl shadow-2xl border border-slate-200 py-2 overflow-hidden animate-in fade-in-50 duration-150">
                <div className="flex items-center justify-between px-4 py-1.5 border-b border-slate-100 text-[11px] font-semibold text-slate-500">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-blue-600" />
                    Recent Searches
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      clearAllSearches();
                      setShowRecentDropdown(false);
                    }}
                    className="text-[10px] text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                  >
                    Clear all
                  </button>
                </div>
                <div className="max-h-52 overflow-y-auto divide-y divide-slate-50">
                  {recentSearches.map((term) => (
                    <div
                      key={term}
                      className="flex items-center justify-between px-4 py-2.5 hover:bg-blue-50/70 text-xs text-slate-800 cursor-pointer transition-colors group"
                      onClick={() => handleSelectRecent(term)}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 shrink-0" />
                        <span className="truncate font-medium">{term}</span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeSearch(term);
                        }}
                        className="p-1 text-slate-300 hover:text-rose-500 hover:bg-slate-100 rounded-md transition-all shrink-0 cursor-pointer"
                        title={`Remove "${term}"`}
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Recent Chips Row */}
            {recentSearches.length > 0 && (
              <div className="mt-2.5 flex items-center flex-wrap gap-1.5 px-1">
                <span className="text-[11px] font-medium text-slate-300 flex items-center gap-1 shrink-0">
                  <Clock className="w-3 h-3 text-cyan-400" />
                  Recent:
                </span>
                {recentSearches.slice(0, 4).map((term) => (
                  <span
                    key={term}
                    onClick={() => handleSelectRecent(term)}
                    className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-[11px] font-medium border border-white/15 backdrop-blur-xs transition-colors cursor-pointer group"
                  >
                    <span className="truncate max-w-[140px]">{term}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeSearch(term);
                      }}
                      className="text-white/60 hover:text-rose-300 p-0.5 rounded-full transition-colors cursor-pointer"
                      title={`Remove "${term}"`}
                    >
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                ))}
                {recentSearches.length > 4 && (
                  <button
                    type="button"
                    onClick={() => setShowRecentDropdown(true)}
                    className="text-[10px] text-cyan-300 hover:underline font-semibold cursor-pointer ml-1"
                  >
                    +{recentSearches.length - 4} more
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Shop Profile Banner (if filtered to single shop) */}
          {currentShop && (
            <div className="mt-6 p-4 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-md">
                  <Store className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-extrabold text-white">{currentShop.name}</h2>
                    <span className="bg-emerald-500/30 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-400/30">
                      Verified Shop
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>{currentShop.locality}, Dibrugarh • {currentShop.address}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {currentShop.phone && (
                  <a
                    href={`tel:${currentShop.phone}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-blue-300" />
                    <span>Call Shop</span>
                  </a>
                )}
                <button
                  onClick={() => {
                    setSelectedShopProfileId(null);
                    setCurrentShop(null);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white text-xs font-bold transition-colors cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Show All Shops</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Main Content & Catalog */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        {/* Filters and Controls Strip */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/80 mb-6 space-y-4">
          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Secondary Filters: Locality, Stock Toggle, Sort, GPS Nearby */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              {/* Locality Dropdown */}
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-500" />
                <select
                  aria-label="Filter products by locality"
                  value={selectedLocality}
                  onChange={(e) => setSelectedLocality(e.target.value)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-2.5 py-1.5 rounded-xl border border-slate-200 focus:outline-none cursor-pointer"
                >
                  {LOCALITIES.map((loc) => (
                    <option key={loc} value={loc === 'All Localities' ? 'all' : loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>

              {/* In-Stock Toggle */}
              <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700 select-none">
                <input
                  type="checkbox"
                  checked={inStockOnly}
                  onChange={(e) => setInStockOnly(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                />
                <span>In-Stock Only</span>
              </label>

              {/* GPS Nearby discovery */}
              <button
                type="button"
                onClick={handleGetLocation}
                disabled={isLocating}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                  userCoords
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
                title="Filter products by proximity to you"
              >
                <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin text-blue-600' : 'text-blue-600'}`} />
                <span>{userCoords ? 'GPS Active (Dibrugarh)' : 'Nearby Me'}</span>
              </button>

              {userCoords && (
                <select
                  aria-label="Filter products by maximum distance"
                  value={maxDistanceKm || ''}
                  onChange={(e) => setMaxDistanceKm(e.target.value ? Number(e.target.value) : undefined)}
                  className="bg-emerald-50 text-emerald-900 font-bold px-2 py-1 rounded-lg border border-emerald-200 text-xs"
                >
                  <option value="">Within 10 km</option>
                  <option value="1">Within 1 km</option>
                  <option value="2">Within 2 km</option>
                  <option value="5">Within 5 km</option>
                </select>
              )}
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1.5 ml-auto">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
              <select
                aria-label="Sort products by"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-2.5 py-1.5 rounded-xl border border-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="featured">Featured Deals</option>
                <option value="price_low">Price: Low to High</option>
                <option value="price_high">Price: High to Low</option>
                <option value="nearest">Nearest First</option>
                <option value="newest">Newest Arrivals</option>
              </select>
            </div>
          </div>
        </div>

        {/* Products Count Indicator */}
        <div className="flex items-center justify-between mb-4 px-1">
          <h2 className="text-xs font-bold text-slate-600 uppercase tracking-wider">
            Showing <span className="text-slate-900 font-extrabold">{products.length}</span> Dibrugarh Shop Products
          </h2>
          {selectedShopProfileId && (
            <button
              onClick={() => {
                setSelectedShopProfileId(null);
                setCurrentShop(null);
              }}
              className="text-xs text-blue-700 hover:underline font-bold"
            >
              Clear Shop Filter
            </button>
          )}
        </div>

        {/* Products Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200 animate-pulse">
                <div className="w-full aspect-square bg-slate-200 rounded-xl mb-3" />
                <div className="h-4 bg-slate-200 rounded w-3/4 mb-2" />
                <div className="h-3 bg-slate-200 rounded w-1/2 mb-3" />
                <div className="h-6 bg-slate-200 rounded w-full" />
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">No products found</h3>
            <p className="text-xs text-slate-600 mt-1 mb-6">
              Try adjusting your category, locality, or search keyword to discover products in Dibrugarh.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedLocality('all');
                setInStockOnly(false);
                setSelectedShopProfileId(null);
                setUserCoords(null);
              }}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors cursor-pointer shadow-xs"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {products.map((product) => {
              const discountPercent =
                product.originalPrice && product.originalPrice > product.price
                  ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
                  : null;

              return (
                <div
                  key={product.id}
                  onClick={() => openModal('product-details', product)}
                  className="bg-white rounded-2xl overflow-hidden border border-slate-200/90 hover:border-blue-400 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col group cursor-pointer"
                >
                  {/* Product Image Area */}
                  <div className="relative aspect-square w-full bg-slate-100 overflow-hidden">
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      width={400}
                      height={400}
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Discount Badge */}
                    {discountPercent && (
                      <span className="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[10px] font-black px-2 py-0.5 rounded-lg shadow-sm">
                        {discountPercent}% OFF
                      </span>
                    )}

                    {/* Video badge if video exists */}
                    {product.videoUrl && (
                      <span className="absolute bottom-2.5 left-2.5 bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-1 shadow-sm">
                        <Play className="w-2.5 h-2.5 fill-white" />
                        <span>Video</span>
                      </span>
                    )}

                    {/* Stock status indicator */}
                    {!product.inStock && (
                      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center p-2">
                        <span className="bg-rose-500 text-white text-xs font-black px-3 py-1 rounded-xl shadow-lg">
                          Out of Stock
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Product Details Area */}
                  <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Shop Name & Locality */}
                      <div className="flex items-center justify-between text-[11px] text-slate-600 mb-1 gap-1">
                        <span
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedShopProfileId(product.businessId);
                          }}
                          className="font-bold text-blue-700 hover:underline truncate"
                          title={product.shopName}
                        >
                          {product.shopName}
                        </span>
                        <span className="shrink-0 text-[10px] text-slate-600 font-medium truncate max-w-[120px]">
                          {product.locality}, {product.city || selectedDistrict}
                        </span>
                      </div>

                      {/* Title */}
                      <h3
                        className="text-xs sm:text-sm font-extrabold text-slate-900 line-clamp-2 leading-snug group-hover:text-blue-600 transition-colors"
                        title={product.name}
                      >
                        {product.name}
                      </h3>

                      {/* Fulfillment & Availability Badges */}
                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        {product.deliveryAvailable !== false && (
                          <span className="text-[9px] bg-blue-50 text-blue-700 font-bold px-1.5 py-0.5 rounded border border-blue-200">
                            Delivery
                          </span>
                        )}
                        {product.pickupAvailable !== false && (
                          <span className="text-[9px] bg-emerald-50 text-emerald-700 font-bold px-1.5 py-0.5 rounded border border-emerald-200">
                            Pickup
                          </span>
                        )}
                        <span
                          className={`text-[9px] font-bold ${
                            product.inStock ? 'text-emerald-700' : 'text-rose-600'
                          }`}
                        >
                          {product.inStock ? '• In Stock' : '• Out of Stock'}
                        </span>
                      </div>
                    </div>

                    {/* Price and Cart Action */}
                    <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                      <div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-sm sm:text-base font-black text-slate-900">
                            ₹{product.price.toLocaleString('en-IN')}
                          </span>
                          {product.originalPrice && (
                            <span className="text-[11px] text-slate-600 line-through">
                              ₹{product.originalPrice.toLocaleString('en-IN')}
                            </span>
                          )}
                        </div>
                        {product.distanceKm !== undefined && (
                          <span className="text-[10px] text-emerald-600 font-bold block">
                            {product.distanceKm} km away
                          </span>
                        )}
                      </div>

                      <button
                        onClick={(e) => handleAddToCart(product, e)}
                        disabled={!product.inStock}
                        className={`p-2 sm:px-3 sm:py-1.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1 transition-all cursor-pointer shadow-xs ${
                          product.inStock
                            ? 'bg-blue-600 hover:bg-blue-700 text-white active:scale-95'
                            : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                        }`}
                        title="Add to shopping cart"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Add</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Floating Sticky Cart Bar (if cart has items) */}
      {cart && cart.items.length > 0 && (
        <div className="fixed bottom-20 sm:bottom-6 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-40 animate-in slide-in-from-bottom duration-300">
          <div className="bg-slate-950 text-white rounded-2xl p-4 shadow-2xl border border-slate-800 flex items-center justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs text-blue-400 font-bold truncate">
                <Store className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{cart.shopName}</span>
              </div>
              <p className="text-sm font-black text-white mt-0.5">
                {cartCount} {cartCount === 1 ? 'item' : 'items'} • ₹
                {cart.items.reduce((s, i) => s + i.product.price * i.quantity, 0).toLocaleString('en-IN')}
              </p>
            </div>

            <button
              onClick={() => openModal('cart')}
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-extrabold flex items-center gap-1.5 shrink-0 cursor-pointer shadow-md shadow-blue-600/30 transition-all"
            >
              <span>View Cart</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Cross-Shop Conflict Confirmation Dialog */}
      {shopConflict && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
              <Store className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-base font-extrabold text-slate-900">Start new order from a different shop?</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Your cart currently contains items from <strong className="text-slate-900">{shopConflict.currentShopName}</strong>.
                CityDeals supports one shop per order so each local merchant can fulfill directly.
              </p>
              <p className="text-xs font-bold text-amber-700 bg-amber-50 p-2.5 rounded-xl mt-3 border border-amber-200">
                Would you like to clear your existing cart and start an order from <span className="underline">{shopConflict.pendingProduct.shopName}</span>?
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => setShopConflict(null)}
                className="w-full py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 cursor-pointer"
              >
                Keep Current Cart
              </button>
              <button
                onClick={() => {
                  forceAddToCart(shopConflict.pendingProduct, 1);
                  setShopConflict(null);
                }}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs shadow-md shadow-blue-500/25 cursor-pointer"
              >
                Start New Shop Order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
