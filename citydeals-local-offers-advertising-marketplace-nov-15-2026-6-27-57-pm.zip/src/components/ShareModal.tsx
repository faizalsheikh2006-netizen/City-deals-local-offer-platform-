import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Offer } from '../types/index';
import {
  X,
  Share2,
  Copy,
  Check,
  MessageCircle,
  Send,
  ExternalLink,
  Store,
  Sparkles,
  Tag,
  Gift,
  QrCode,
} from 'lucide-react';
import { api } from '../api/client';

interface ShareModalProps {
  data?: {
    type?: 'app' | 'offer';
    title?: string;
    text?: string;
    url?: string;
    offer?: Offer;
    referralCode?: string;
  };
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ data, onClose }) => {
  const { user, showToast } = useApp();
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);

  const isOffer = data?.type === 'offer' && data?.offer;
  const offer = data?.offer;

  // Real, permanent URL generated from window.location.origin
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const shareCode = data?.referralCode || user?.referralCode;

  const shareUrl = isOffer
    ? (data?.url || `${origin}/?offer=${offer?.id}`)
    : (data?.url || (shareCode ? `${origin}/?ref=${shareCode}` : `${origin}/`));

  const shareTitle = isOffer
    ? `${offer?.headline} at ${offer?.shopName}`
    : 'CityDeals - Local Offers & Discounts';

  const shareText = isOffer
    ? `Check out this verified in-store deal at ${offer?.shopName} (${offer?.locality}, ${offer?.city}): "${offer?.headline}" (${offer?.discountValue}) on CityDeals!`
    : 'Discover local offers and discounts near you with CityDeals! Find verified in-store sales across Dibrugarh & Assam:';

  const fullSharePayload = `${shareText} ${shareUrl}`;

  // Native share sheet (Android / iOS / supported desktop browsers)
  const canNativeShare = typeof navigator !== 'undefined' && Boolean(navigator.share);

  const handleNativeShare = async () => {
    if (!canNativeShare) return;
    try {
      if (offer?.id) api.trackShare(offer.id);
      await navigator.share({
        title: shareTitle,
        text: shareText,
        url: shareUrl,
      });
      showToast('Shared successfully!', 'success');
      onClose();
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.warn('Native share error:', err);
      }
    }
  };

  // Copy Link
  const handleCopy = async () => {
    try {
      if (offer?.id) api.trackShare(offer.id);
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(shareUrl);
      } else {
        // Fallback for older browsers
        const input = document.createElement('input');
        input.value = shareUrl;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
      }
      setCopied(true);
      showToast('Link copied to clipboard!', 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      showToast('Could not copy automatically. Please copy the URL manually.', 'info');
    }
  };

  // WhatsApp Share
  const handleWhatsApp = () => {
    if (offer?.id) api.trackShare(offer.id);
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(fullSharePayload)}`;
    window.open(waUrl, '_blank');
  };

  // Telegram Share
  const handleTelegram = () => {
    if (offer?.id) api.trackShare(offer.id);
    const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
    window.open(tgUrl, '_blank');
  };

  // X / Twitter Share
  const handleTwitter = () => {
    if (offer?.id) api.trackShare(offer.id);
    const twUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
    window.open(twUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-900 to-blue-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-600 text-white">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                {isOffer ? 'Share In-Store Offer' : 'Share CityDeals'}
              </h2>
              <p className="text-xs text-slate-300">
                {isOffer ? offer?.shopName : 'Invite Friends & Local Shoppers'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Preview Card */}
          {isOffer && offer ? (
            <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-2xl flex items-center gap-3">
              <img
                src={offer.imageUrl}
                alt={offer.shopName}
                className="w-16 h-16 rounded-xl object-cover shrink-0 border border-blue-200"
              />
              <div className="min-w-0 flex-1">
                <span className="text-[10px] font-extrabold text-blue-700 uppercase tracking-wider block">
                  {offer.category.replace('-', ' ')}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1">{offer.headline}</h4>
                <p className="text-xs text-slate-600 flex items-center gap-1 mt-0.5">
                  <Store className="w-3 h-3 text-slate-400 shrink-0" />
                  <span className="truncate">{offer.shopName} • {offer.locality}</span>
                </p>
              </div>
            </div>
          ) : (
            <div className="p-3.5 bg-gradient-to-br from-blue-50 to-indigo-50/60 border border-blue-200 rounded-2xl">
              <div className="flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-blue-600 text-white shrink-0 mt-0.5">
                  <Store className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-xs text-blue-900">CityDeals Marketplace</span>
                    <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                      Dibrugarh, Assam
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 font-medium leading-relaxed">
                    "Discover local offers and discounts near you with CityDeals!"
                  </p>
                  {shareCode && (
                    <div className="inline-flex items-center gap-1.5 pt-1 text-[11px] font-bold text-blue-700 bg-white/80 px-2 py-0.5 rounded-md border border-blue-200">
                      <Sparkles className="w-3 h-3 text-amber-500" />
                      <span>Includes your personal referral code: </span>
                      <span className="font-mono text-purple-700 font-extrabold">{shareCode}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Native Android / Mobile Share Sheet Button */}
          {canNativeShare && (
            <button
              onClick={handleNativeShare}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>Share via Android Apps (WhatsApp, Telegram, etc.)</span>
            </button>
          )}

          {/* Social Quick Share Grid */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 block">Direct Social Sharing</span>
            <div className="grid grid-cols-3 gap-2.5">
              <button
                onClick={handleWhatsApp}
                className="p-3 rounded-2xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-xs flex flex-col items-center gap-1.5 cursor-pointer transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xs">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <span>WhatsApp</span>
              </button>

              <button
                onClick={handleTelegram}
                className="p-3 rounded-2xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 font-bold text-xs flex flex-col items-center gap-1.5 cursor-pointer transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-sky-500 text-white flex items-center justify-center shadow-xs">
                  <Send className="w-4 h-4" />
                </div>
                <span>Telegram</span>
              </button>

              <button
                onClick={handleTwitter}
                className="p-3 rounded-2xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 font-bold text-xs flex flex-col items-center gap-1.5 cursor-pointer transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center shadow-xs">
                  <span className="text-xs font-black">𝕏</span>
                </div>
                <span>X (Twitter)</span>
              </button>
            </div>
          </div>

          {/* Real Permanent URL Link Box with Copy Button */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <label className="font-bold text-slate-700">Permanent Public URL</label>
              <button
                onClick={() => setShowQr(!showQr)}
                className="text-blue-600 hover:text-blue-800 font-semibold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>{showQr ? 'Hide QR Code' : 'Show QR Code'}</span>
              </button>
            </div>
            <div className="flex items-center gap-2 p-1.5 bg-slate-50 border border-slate-200 rounded-2xl focus-within:border-blue-500 focus-within:bg-white transition-all">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="flex-1 bg-transparent border-none outline-none text-xs text-slate-800 font-mono px-2 select-all"
              />
              <button
                onClick={handleCopy}
                className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0 ${
                  copied
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
                }`}
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Link'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              Works seamlessly on Android, iOS, and desktop browsers without requiring app pre-installation.
            </p>
          </div>

          {/* QR Code view if toggled */}
          {showQr && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-2 animate-in fade-in">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(shareUrl)}`}
                alt="QR Code"
                className="w-36 h-36 mx-auto rounded-xl border border-slate-300 p-1 bg-white shadow-xs"
              />
              <p className="text-[11px] text-slate-600 font-medium">
                Scan with any phone camera to open on CityDeals
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
