import React from 'react';
import { Offer } from '../types/index';
import { Sparkles, MapPin, Clock, ArrowRight, Phone, MessageCircle, Navigation, Store } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { optimizeImageUrl } from '../utils/image';

interface SpotlightSectionProps {
  offers: Offer[];
}

export const SpotlightSection: React.FC<SpotlightSectionProps> = ({ offers }) => {
  const { openModal } = useApp();

  const sponsoredOffers = offers.filter((o) => o.isSponsored && (o.sponsorTier === 'spotlight' || o.sponsorTier === 'featured'));

  if (sponsoredOffers.length === 0) return null;

  const handleTrackAndCall = (offer: Offer, e: React.MouseEvent) => {
    e.stopPropagation();
    api.trackClick(offer.id);
    window.location.href = `tel:${offer.contactPhone}`;
  };

  const handleTrackAndWhatsapp = (offer: Offer, e: React.MouseEvent) => {
    e.stopPropagation();
    api.trackClick(offer.id);
    const wa = offer.contactWhatsapp || offer.contactPhone;
    const cleanWa = wa.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Hello! I saw your offer "${offer.headline}" on CityDeals Dibrugarh. I'd like to visit your shop to avail of it.`
    );
    window.open(`https://wa.me/${cleanWa}?text=${text}`, '_blank');
  };

  const handleDirections = (offer: Offer, e: React.MouseEvent) => {
    e.stopPropagation();
    api.trackClick(offer.id);
    const destination = encodeURIComponent(`${offer.shopName}, ${offer.locality}, ${offer.city}, Assam`);
    window.open(`https://www.google.com/maps/search/?api=1&query=${destination}`, '_blank');
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping motion-reduce:animate-none absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
          </span>
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Featured Local Spotlight</span>
          </h2>
          <span className="text-[10px] bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full border border-amber-300">
            Sponsored Partner Shop
          </span>
        </div>

        <button
          type="button"
          onClick={() => openModal('info-rates')}
          className="text-xs text-blue-700 hover:text-blue-900 font-semibold hidden sm:inline-block"
        >
          Promote your shop here →
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sponsoredOffers.slice(0, 2).map((offer) => {
          const daysLeft = Math.max(
            0,
            Math.ceil((new Date(offer.validUntil).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
          );

          return (
            <div
              key={offer.id}
              onClick={() => openModal('details', offer)}
              className="group relative bg-gradient-to-br from-white to-blue-50/40 rounded-2xl border-2 border-blue-200/80 hover:border-blue-400 shadow-md hover:shadow-xl transition-shadow duration-200 overflow-hidden cursor-pointer flex flex-col sm:flex-row"
            >
              {/* Image Preview */}
              <div className="sm:w-52 h-44 sm:h-auto relative shrink-0 overflow-hidden bg-slate-100">
                <img
                  src={optimizeImageUrl(offer.imageUrl, 480, 75)}
                  alt={offer.shopName}
                  width={208}
                  height={176}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                  decoding="async"
                />
                <div className="absolute top-2.5 left-2.5 flex flex-col gap-1">
                  <span className="bg-red-600 text-white font-extrabold text-[11px] px-2.5 py-0.8 rounded-md shadow-sm">
                    {offer.discountValue}
                  </span>
                  <span className="bg-slate-900/90 backdrop-blur-xs text-amber-300 font-bold text-[9px] px-2 py-0.5 rounded tracking-wide border border-amber-400/30 flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5" />
                    SPONSORED
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
                    <span className="font-semibold text-blue-700 capitalize">
                      {offer.category.replace('-', ' ')}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] font-medium text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded">
                      <Clock className="w-3 h-3" />
                      {daysLeft === 0 ? 'Expires today' : `${daysLeft} days left`}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-slate-700 font-bold mb-1">
                    <Store className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span className="truncate">{offer.shopName}</span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 leading-snug">
                    {offer.headline}
                  </h3>

                  <div className="mt-1.5 flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span className="text-slate-600">{offer.locality}, {offer.city}</span>
                    {offer.landmark && (
                      <span className="text-slate-600 truncate">• {offer.landmark}</span>
                    )}
                  </div>
                </div>

                {/* Quick Action Footer */}
                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => handleTrackAndCall(offer, e)}
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-700 transition-colors"
                      aria-label={`Call ${offer.shopName}`}
                      title="Call Shop"
                    >
                      <Phone className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleTrackAndWhatsapp(offer, e)}
                      className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition-colors"
                      aria-label={`WhatsApp ${offer.shopName}`}
                      title="WhatsApp Shop"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleDirections(offer, e)}
                      className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 transition-colors"
                      aria-label={`Directions to ${offer.shopName}`}
                      title="Directions"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <span className="text-xs font-bold text-blue-700 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                    <span>View Offer & Terms</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
