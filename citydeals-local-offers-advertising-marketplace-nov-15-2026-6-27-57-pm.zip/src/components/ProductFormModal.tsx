import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { Product } from '../types/index';
import { uploadFileToStorage } from '../lib/firebase';
import {
  X,
  ShoppingBag,
  Store,
  DollarSign,
  Image as ImageIcon,
  Video,
  FileText,
  AlertCircle,
  CheckCircle2,
  Upload,
  Trash2,
  Star,
  Plus,
  Loader2,
} from 'lucide-react';

export const ProductFormModal: React.FC = () => {
  const { modalType, modalData, closeModal, showToast, triggerRefresh, business } = useApp();
  const isEditing = modalType === 'edit-product';
  const existingProduct: Product | undefined = modalData;

  const [name, setName] = useState<string>(existingProduct?.name || '');
  const [category, setCategory] = useState<string>(existingProduct?.category || 'fashion');
  const [description, setDescription] = useState<string>(existingProduct?.description || '');
  const [price, setPrice] = useState<string>(existingProduct ? String(existingProduct.price) : '');
  const [originalPrice, setOriginalPrice] = useState<string>(
    existingProduct?.originalPrice ? String(existingProduct.originalPrice) : ''
  );
  const [stockQuantity, setStockQuantity] = useState<string>(
    existingProduct?.stockQuantity !== undefined ? String(existingProduct.stockQuantity) : '10'
  );
  const [inStock, setInStock] = useState<boolean>(existingProduct?.inStock ?? true);
  const [deliveryAvailable, setDeliveryAvailable] = useState<boolean>(
    existingProduct?.deliveryAvailable ?? true
  );
  const [pickupAvailable, setPickupAvailable] = useState<boolean>(
    existingProduct?.pickupAvailable ?? true
  );

  // Multi-image gallery state
  const [images, setImages] = useState<string[]>(() => {
    if (existingProduct) {
      const list: string[] = [];
      if (existingProduct.imageUrl) list.push(existingProduct.imageUrl);
      if (existingProduct.additionalImages && existingProduct.additionalImages.length > 0) {
        for (const img of existingProduct.additionalImages) {
          if (!list.includes(img)) list.push(img);
        }
      }
      return list.length > 0
        ? list
        : ['https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=800&q=80'];
    }
    return [];
  });

  const [customImageUrl, setCustomImageUrl] = useState<string>('');
  const [videoUrl, setVideoUrl] = useState<string>(existingProduct?.videoUrl || '');
  const [isUploadingImages, setIsUploadingImages] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Phone gallery / file picker handler
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const selectedFiles = Array.from(e.target.files);
    setErrorMsg(null);
    setIsUploadingImages(true);

    try {
      const uploadedUrls: string[] = [];
      for (const file of selectedFiles) {
        const storagePath = `products/${business?.id || 'prod'}_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
        const url = await uploadFileToStorage(file, storagePath);
        uploadedUrls.push(url);
      }

      setImages((prev) => [...prev, ...uploadedUrls]);
      showToast(`${uploadedUrls.length} photo(s) selected and uploaded!`, 'success');
    } catch (err: any) {
      console.error('Gallery upload error:', err);
      setErrorMsg('Failed to upload some images. You can also paste an image URL directly.');
    } finally {
      setIsUploadingImages(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleAddCustomUrl = () => {
    if (!customImageUrl.trim()) return;
    const clean = customImageUrl.trim();
    if (!images.includes(clean)) {
      setImages((prev) => [...prev, clean]);
    }
    setCustomImageUrl('');
  };

  const handleRemoveImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSetPrimaryImage = (index: number) => {
    if (index === 0) return;
    setImages((prev) => {
      const target = prev[index];
      const rest = prev.filter((_, i) => i !== index);
      return [target, ...rest];
    });
    showToast('Primary photo updated!', 'info');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!name.trim()) {
      setErrorMsg('Product name is required');
      return;
    }

    const numPrice = Number(price);
    if (isNaN(numPrice) || numPrice <= 0) {
      setErrorMsg('Please enter a valid selling price in ₹');
      return;
    }

    const numStock = Number(stockQuantity);
    if (isNaN(numStock) || numStock < 0) {
      setErrorMsg('Please enter a valid stock quantity');
      return;
    }

    if (!deliveryAvailable && !pickupAvailable) {
      setErrorMsg('Please select at least one fulfillment option: Home Delivery or Store Pickup.');
      return;
    }

    const primaryImage =
      images[0] || 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=800&q=80';
    const additionalImages = images.slice(1);

    const fulfillmentOptions: ('delivery' | 'pickup')[] = [
      ...(deliveryAvailable ? ['delivery' as const] : []),
      ...(pickupAvailable ? ['pickup' as const] : []),
    ];

    const productPayload: Partial<Product> = {
      name: name.trim(),
      category,
      description: description.trim(),
      price: Math.round(numPrice),
      originalPrice: originalPrice ? Math.round(Number(originalPrice)) : undefined,
      stockQuantity: Math.round(numStock),
      inStock: numStock > 0 && inStock,
      imageUrl: primaryImage,
      additionalImages,
      videoUrl: videoUrl.trim() || undefined,
      deliveryAvailable,
      pickupAvailable,
      fulfillmentOptions,
    };

    try {
      setIsSubmitting(true);
      if (isEditing && existingProduct?.id) {
        await api.updateMerchantProduct(existingProduct.id, productPayload);
        showToast(`Product "${name}" updated successfully!`, 'success');
      } else {
        await api.createMerchantProduct(productPayload);
        showToast(`Product submitted! Pending quick admin review before going live.`, 'success');
      }
      closeModal();
      triggerRefresh();
    } catch (err: any) {
      console.error('Error saving product:', err);
      setErrorMsg(err.message || 'Failed to save product. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-slate-900">
                {isEditing ? 'Edit Shop Product' : 'Add New Product to Catalog'}
              </h3>
              <p className="text-xs text-slate-500 font-medium">CityDeals Assam Shopping Catalogue</p>
            </div>
          </div>

          <button
            type="button"
            onClick={closeModal}
            aria-label="Close product form"
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Shop Name & Selected Location Association Banner */}
          <div className="p-3 rounded-2xl bg-blue-50/60 border border-blue-200/80 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                <Store className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <p className="font-extrabold text-slate-900 truncate">{business?.name || 'Your Registered Shop'}</p>
                <p className="text-[11px] text-slate-600 font-medium truncate">
                  {business?.locality || 'Assam'}, {business?.district || business?.city || 'Dibrugarh'}
                </p>
              </div>
            </div>
            <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full shrink-0">
              Associated Shop
            </span>
          </div>

          {/* Product Name */}
          <div>
            <label className="block text-xs font-extrabold text-slate-700 mb-1">
              Product Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Pure Muga Silk Sador Gamusa Set"
              className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
            />
          </div>

          {/* Category */}
          <div>
            <label htmlFor="product-form-category" className="block text-xs font-extrabold text-slate-700 mb-1">
              Category <span className="text-rose-500">*</span>
            </label>
            <select
              id="product-form-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
            >
              <option value="fashion">Assam Silk & Handloom</option>
              <option value="grocery">Upper Assam Tea & Food</option>
              <option value="electronics">Electronics & Mobiles</option>
              <option value="home-lifestyle">Bell Metal & Handicrafts</option>
              <option value="beauty-salons">Beauty & Wellness</option>
              <option value="other-shops">General Merchandise & Other</option>
            </select>
          </div>

          {/* Pricing Row */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-extrabold text-slate-700 mb-1">
                Selling Price (₹) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                required
                min="1"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="e.g. 1499"
                className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
              />
            </div>
            <div>
              <label className="block text-xs font-extrabold text-slate-700 mb-1">
                Original MRP (₹) (Optional)
              </label>
              <input
                type="number"
                min="1"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
                placeholder="e.g. 1999"
                className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
              />
            </div>
          </div>

          {/* Stock row */}
          <div className="grid grid-cols-2 gap-3 items-center">
            <div>
              <label className="block text-xs font-extrabold text-slate-700 mb-1">
                Stock Quantity
              </label>
              <input
                type="number"
                min="0"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(e.target.value)}
                placeholder="10"
                className="w-full px-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
              />
            </div>

            <div className="pt-5">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={inStock}
                  onChange={(e) => setInStock(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                />
                <span className="text-xs font-extrabold text-slate-800">Available In Stock</span>
              </label>
            </div>
          </div>

          {/* Delivery & Pickup Options */}
          <div className="space-y-2 p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
            <div>
              <label className="block text-xs font-extrabold text-slate-700">
                Delivery & Pickup Options <span className="text-rose-500">*</span>
              </label>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Select how customers can receive this product
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              <label
                className={`p-2.5 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                  deliveryAvailable
                    ? 'bg-blue-50/70 border-blue-400 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-500'
                }`}
              >
                <input
                  type="checkbox"
                  checked={deliveryAvailable}
                  onChange={(e) => setDeliveryAvailable(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                />
                <div className="min-w-0">
                  <span className="text-xs font-bold text-slate-900 block">Home Delivery Available</span>
                  <span className="text-[10px] text-slate-500">Local delivery in your district</span>
                </div>
              </label>

              <label
                className={`p-2.5 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                  pickupAvailable
                    ? 'bg-blue-50/70 border-blue-400 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-500'
                }`}
              >
                <input
                  type="checkbox"
                  checked={pickupAvailable}
                  onChange={(e) => setPickupAvailable(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                />
                <div className="min-w-0">
                  <span className="text-xs font-bold text-slate-900 block">Store Pickup Available</span>
                  <span className="text-[10px] text-slate-500">Customers pick up at your shop</span>
                </div>
              </label>
            </div>
          </div>

          {/* Product Gallery: Photos from Phone Gallery or Files */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-extrabold text-slate-700">
                Product Photos (Phone Gallery / Files) <span className="text-rose-500">*</span>
              </label>
              <span className="text-[10px] text-slate-500 font-medium">
                {images.length} photo(s) selected
              </span>
            </div>

            {/* Gallery Upload Box */}
            <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-2xl p-4 text-center bg-slate-50 hover:bg-blue-50/30 transition-all">
              <input
                type="file"
                ref={fileInputRef}
                multiple
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
                id="product-gallery-input"
              />
              <label
                htmlFor="product-gallery-input"
                className="cursor-pointer flex flex-col items-center justify-center gap-1.5"
              >
                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shadow-xs">
                  {isUploadingImages ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Upload className="w-5 h-5" />
                  )}
                </div>
                <span className="text-xs font-bold text-blue-600 hover:underline">
                  {isUploadingImages ? 'Uploading photos to Firebase Storage...' : 'Select Photos from Phone Gallery'}
                </span>
                <p className="text-[10px] text-slate-500">
                  Select one or multiple product angles (JPG, PNG, WebP)
                </p>
              </label>
            </div>

            {/* Gallery Thumbnail Carousel / Grid */}
            {images.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                  <span>First photo is the Primary Cover. Click star to make primary.</span>
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
                  {images.map((imgUrl, idx) => (
                    <div
                      key={idx}
                      className={`relative group rounded-xl overflow-hidden border-2 bg-slate-100 aspect-square ${
                        idx === 0 ? 'border-blue-600 ring-2 ring-blue-500/20 shadow-xs' : 'border-slate-200'
                      }`}
                    >
                      <img
                        src={imgUrl}
                        alt={`Photo ${idx + 1}`}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as any).src =
                            'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=400&q=80';
                        }}
                      />

                      {/* Primary Badge */}
                      {idx === 0 && (
                        <div className="absolute top-1 left-1 bg-blue-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-xs">
                          Primary
                        </div>
                      )}

                      {/* Overlay Controls */}
                      <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        {idx !== 0 && (
                          <button
                            type="button"
                            onClick={() => handleSetPrimaryImage(idx)}
                            title="Set as Primary Cover"
                            className="w-7 h-7 rounded-lg bg-amber-500 text-white flex items-center justify-center shadow-xs hover:bg-amber-600 cursor-pointer"
                          >
                            <Star className="w-3.5 h-3.5 fill-current" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(idx)}
                          title="Delete photo"
                          className="w-7 h-7 rounded-lg bg-rose-600 text-white flex items-center justify-center shadow-xs hover:bg-rose-700 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Direct URL Input fallback */}
            <div className="pt-2">
              <label className="block text-[11px] font-bold text-slate-500 mb-1">
                Or Add Photo by Web URL
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={customImageUrl}
                  onChange={(e) => setCustomImageUrl(e.target.value)}
                  placeholder="https://..."
                  className="flex-1 px-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
                />
                <button
                  type="button"
                  onClick={handleAddCustomUrl}
                  className="px-3 py-2 rounded-xl bg-slate-800 text-white font-bold text-xs hover:bg-slate-900 cursor-pointer"
                >
                  Add
                </button>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-extrabold text-slate-700 mb-1">
              Description & Specifications <span className="text-rose-500">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Highlight authentic materials, handloom weaving, size dimensions, or product warranty..."
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
            />
          </div>

          {/* Video Reel URL */}
          <div>
            <label className="block text-xs font-extrabold text-slate-700 mb-1">
              Short Showcase Video URL (Optional)
            </label>
            <div className="relative">
              <Video className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="url"
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                placeholder="https://example.com/reel.mp4"
                className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 font-medium"
              />
            </div>
          </div>

          {/* Moderation notice */}
          <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <p>
              New products undergo quick admin review before appearing publicly on CityDeals Shopping.
            </p>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting || isUploadingImages}
              className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm shadow-md shadow-blue-500/25 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSubmitting
                ? 'Saving Product...'
                : isEditing
                ? 'Update Product'
                : 'Submit Product for Review'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
