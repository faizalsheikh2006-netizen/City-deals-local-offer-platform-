import React, { useState, useMemo } from 'react';
import { Offer } from '../types/index';
import {
  MapPin,
  Clock,
  Sparkles,
  Bookmark,
  BookmarkCheck,
  Store,
  Navigation,
  ArrowRight,
  ShieldCheck,
  Share2,
  Flag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { formatDistance } from '../utils/geo';
import { optimizeImageUrl } from '../utils/image';

interface OfferCardProps {
  offer: Offer;
  priority?: boolean;
}

export const OfferCard: React.FC<OfferCardProps> = React.memo(({ offer, priority = false }) => {
  const { openModal, isOfferSaved, toggleSaveOffer, shareOffer } = useApp();
  const saved = isOfferSaved(offer.id);

  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  const optimizedUrl = useMemo(() => optimizeImageUrl(offer.imageUrl, 600, 75), [offer.imageUrl]);

  const isExpired = new Date(offer.validUntil).getTime() < Date.now();
  const daysLeft = Math.max(
    0,
    Math.ceil((new Date(offer.validUntil).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
  );

  const handleCardClick = () => {
    openModal('details', offer);
  };

  const handleDirections = (e: React.MouseEvent) => {
    e.stopPropagation();
    api.trackClick(offer.id);
    const destination = encodeURIComponent(`${offer.shopName}, ${offer.locality}, ${offer.city}, Assam`);
    window.open(`https://www.google.com/maps/search/?api=1&query=${destination}`, '_blank');
  };

  const handleToggleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleSaveOffer(offer.id, offer);
  };

  const handleReport = (e: React.MouseEvent) => {
    e.stopPropagation();
    openModal('report', offer);
  };

  return (
    <div
      onClick={handleCardClick}
      className={`group relative bg-white rounded-2xl border transition-shadow duration-200 overflow-hidden cursor-pointer flex flex-col justify-between ${
        offer.isSponsored
          ? 'border-blue-400/80 shadow-md hover:shadow-xl ring-2 ring-blue-500/20'
          : 'border-slate-200 hover:border-blue-300 shadow-xs hover:shadow-lg'
      }`}
    >
      <div>
        {/* Card Shop / Storefront Image Header */}
        <div className="relative h-48 w-full bg-slate-200 overflow-hidden">
          {!hasError ? (
            <img
              src={optimizedUrl}
              alt={`${offer.shopName} - ${offer.headline}`}
              width={600}
              height={192}
              loading={priority ? 'eager' : 'lazy'}
              fetchPriority={priority ? 'high' : 'auto'}
              decoding="async"
              onLoad={() => setIsLoaded(true)}
              onError={() => setHasError(true)}
              className={`relative z-10 w-full h-full object-cover group-hover:scale-105 transition-[opacity,transform] duration-300 ease-out will-change-transform ${
                isLoaded ? 'opacity-100' : 'opacity-0'
              }`}
            />
          ) : (
            <div className="relative z-10 w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 text-slate-600 p-4">
              <Store className="w-8 h-8 mb-1 text-slate-500" />
              <span className="text-xs font-semibold text-slate-600">{offer.shopName}</span>
            </div>
          )}

          {/* Offer Discount Badge, Sponsored Pill, and GPS Distance Badge */}
          <div className="absolute top-3 left-3 z-20 flex flex-col gap-1.5 items-start">
            <span className="bg-gradient-to-r from-red-600 to-rose-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-lg shadow-md tracking-tight">
              {offer.discountValue}
            </span>

            {offer.isSponsored && (
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-sm ${
                offer.sponsorTier === 'homepage_featured' || offer.sponsorTier === 'spotlight'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 border border-amber-300 ring-2 ring-amber-400/40'
                  : 'bg-slate-900/95 text-amber-300 border border-amber-400/30'
              }`}>
                <Sparkles className="w-2.5 h-2.5 text-amber-400" />
                <span>
                  {offer.sponsorBadge || (offer.sponsorTier === 'homepage_featured' ? 'FEATURED SPONSOR' : 'PROMOTED')}
                </span>
              </span>
            )}

            {offer.distanceKm !== undefined && (
              <span className="bg-blue-600/95 text-white font-bold text-[10px] px-2 py-0.5 rounded-md shadow-sm flex items-center gap-1 backdrop-blur-xs">
                <Navigation className="w-2.5 h-2.5" />
                <span>{formatDistance(offer.distanceKm)}</span>
              </span>
            )}
          </div>

          {/* Top Actions: Share & Bookmark */}
          <div className="absolute top-3 right-3 z-20 flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                shareOffer(offer);
              }}
              className="p-2 rounded-xl backdrop-blur-md bg-white/85 hover:bg-white text-slate-700 hover:text-blue-600 shadow-sm transition-transform hover:scale-105 cursor-pointer"
              aria-label={`Share offer from ${offer.shopName}`}
              title="Share this offer"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleToggleSave}
              className={`p-2 rounded-xl backdrop-blur-md transition-colors cursor-pointer ${
                saved
                  ? 'bg-amber-500 text-white shadow-md'
                  : 'bg-white/85 hover:bg-white text-slate-700 shadow-sm'
              }`}
              aria-label={saved ? `Remove ${offer.headline} from saved` : `Save ${offer.headline} for store visit`}
              title={saved ? 'Remove from saved' : 'Save deal for store visit'}
            >
              {saved ? <BookmarkCheck className="w-4 h-4 fill-white" /> : <Bookmark className="w-4 h-4" />}
            </button>
          </div>

          {/* Expiry Pill */}
          <div
            className={`absolute bottom-3 left-3 z-20 backdrop-blur-xs text-[11px] font-semibold px-2.5 py-0.5 rounded-md flex items-center gap-1 shadow-sm ${
              isExpired
                ? 'bg-rose-950/90 text-rose-200 border border-rose-500/40'
                : daysLeft <= 1
                ? 'bg-amber-950/90 text-amber-200 border border-amber-500/30 animate-pulse motion-reduce:animate-none'
                : 'bg-slate-900/85 text-white'
            }`}
          >
            <Clock className={`w-3 h-3 ${isExpired ? 'text-rose-400' : 'text-amber-400'}`} />
            <span>{isExpired ? 'Offer Expired' : daysLeft === 0 ? 'Expires today' : `Valid for ${daysLeft} more days`}</span>
          </div>
        </div>

        {/* Content Body: Shop-first & In-Store Offer */}
        <div className="p-4 space-y-2.5">
          {/* Shop Name, Category & Verified Status */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-blue-700 uppercase text-[10px] tracking-wider">
                {offer.category.replace('-', ' ')}
              </span>
              {Boolean(offer.lastVerifiedAt || offer.verifiedBy) && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200/50">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  <span>
                    {offer.lastVerifiedAt
                      ? `Verified ${new Date(offer.lastVerifiedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}`
                      : 'Verified Shop'}
                  </span>
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <Store className="w-4 h-4 text-slate-500 shrink-0" />
              <p className="font-extrabold text-slate-900 text-sm group-hover:text-blue-600 transition-colors line-clamp-1">
                {offer.shopName}
              </p>
            </div>
          </div>

          {/* Offer Headline */}
          <h3 className="font-bold text-slate-800 text-sm sm:text-base leading-snug line-clamp-2">
            {offer.headline}
          </h3>

          {/* Physical Location in Assam & Landmark */}
          <div className="flex items-start gap-1.5 text-xs text-slate-600 pt-0.5">
            <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-1">
                <p className="font-bold text-slate-900 truncate">
                  {offer.locality}, <span className="font-medium text-slate-600">{offer.district || offer.city}</span>
                </p>
                {offer.isDistrictWide && (
                  <span className="text-[10px] font-extrabold bg-indigo-50 text-indigo-700 px-1.5 py-0.2 rounded border border-indigo-200 shrink-0">
                    District-Wide
                  </span>
                )}
                {offer.distanceKm !== undefined && (
                  <span className="text-[11px] font-bold text-blue-700 shrink-0">
                    {formatDistance(offer.distanceKm)}
                  </span>
                )}
              </div>
              {offer.landmark && (
                <p className="text-[11px] text-slate-600 truncate">Landmark: {offer.landmark}</p>
              )}
            </div>
          </div>

          {/* Terms snippet */}
          {offer.terms && offer.terms.length > 0 && (
            <p className="text-[11px] text-slate-600 line-clamp-1 bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
              <strong className="text-slate-800 font-semibold">Terms:</strong> {offer.terms[0]}
            </p>
          )}
        </div>
      </div>

      {/* Footer Actions: Directions, View Details & Report Link */}
      <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 flex flex-col gap-1.5">
        <div className="flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={handleDirections}
            className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-white border border-slate-200 hover:border-blue-500 text-slate-700 hover:text-blue-600 text-xs font-semibold shadow-2xs transition-colors"
            title="Locate physical shop"
          >
            <Navigation className="w-3.5 h-3.5 text-blue-600" />
            <span className="truncate">Directions</span>
          </button>

          <button
            type="button"
            onClick={handleCardClick}
            className="flex-1 inline-flex items-center justify-center gap-1 py-2 px-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors"
          >
            <span>View Offer</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center justify-between text-[10px] text-slate-600 px-1 pt-1">
          <span>In-store redemption</span>
          <button
            type="button"
            onClick={handleReport}
            className="hover:text-rose-700 flex items-center gap-0.5 transition-colors cursor-pointer font-medium"
            title="Report expired or incorrect offer"
          >
            <Flag className="w-2.5 h-2.5" />
            <span>Report Issue</span>
          </button>
        </div>
      </div>
    </div>
  );
});
OfferCard.displayName = 'OfferCard';
