import React, { useState, useEffect, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { Offer, Business, AuditLog, PromotionRequest, VerificationRequest, PromotionPackage, Product, ShoppingOrder } from '../types';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Search,
  Filter,
  RefreshCw,
  Store,
  MapPin,
  Calendar,
  Tag,
  Phone,
  MessageCircle,
  ExternalLink,
  Lock,
  Mail,
  UserCheck,
  Eye,
  LogOut,
  ArrowLeft,
  ChevronRight,
  Clock,
  FileText,
  BadgeAlert,
  Sparkles,
  Award,
  FileCheck,
  CalendarX,
  Compass,
  Users,
  User,
  Navigation,
  ShoppingBag,
  PackageCheck,
  Truck,
} from 'lucide-react';

export const AdminPortal: React.FC = () => {
  const {
    role,
    user,
    isAuthenticated,
    adminPreviewMode,
    setAdminPreviewMode,
    login,
    loginWithGoogle,
    logout,
    showToast,
    setActiveView,
    openModal,
    districts,
    selectedDistrict,
  } = useApp();

  // Admin authentication state for unauthenticated / non-admin users
  const [authEmail, setAuthEmail] = useState('citydeals.discoverlocal@gmail.com');
  const [authPassword, setAuthPassword] = useState('');
  const [isAuthSubmitting, setIsAuthSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Admin data state
  const [stats, setStats] = useState<any>(null);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [shops, setShops] = useState<Business[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<ShoppingOrder[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [promotionRequests, setPromotionRequests] = useState<PromotionRequest[]>([]);
  const [verificationRequests, setVerificationRequests] = useState<VerificationRequest[]>([]);
  const [promotionPackages, setPromotionPackages] = useState<PromotionPackage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Navigation & Filtering
  const [activeTab, setActiveTab] = useState<
    'pending' | 'approved' | 'rejected' | 'expired' | 'all' | 'shops' | 'promotions' | 'verifications' | 'products' | 'orders' | 'audit'
  >('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [districtFilter, setDistrictFilter] = useState<string>('all');
  const [promotionFilter, setPromotionFilter] = useState<'all' | 'pending' | 'approved' | 'active' | 'rejected'>('all');
  const [verificationFilter, setVerificationFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  // Action states
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // Rejection Modal State
  const [rejectingOffer, setRejectingOffer] = useState<Offer | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [rejectionNotes, setRejectionNotes] = useState('');
  const [isSubmittingReject, setIsSubmittingReject] = useState(false);

  const isSuperAdmin = isAuthenticated && role === 'admin' && (user.email === 'citydeals.discoverlocal@gmail.com' || (user as any).role === 'admin');

  // Load Admin Data from Existing Backend & Firestore
  const loadAdminData = useCallback(async () => {
    if (!isSuperAdmin) return;
    try {
      setIsRefreshing(true);
      const [statsRes, offersRes, shopsRes, logsRes, promoRes, verifRes, pkgsRes, prodsRes, ordsRes] = await Promise.all([
        api.getAdminStats().catch(() => ({ stats: null })),
        api.getAdminOffers('all').catch(() => ({ offers: [] })),
        api.getAdminShops().catch(() => ({ shops: [] })),
        api.getAuditLogs().catch(() => ({ auditLogs: [] })),
        api.getAdminPromotionRequests().catch(() => ({ promotionRequests: [] })),
        api.getAdminVerificationRequests().catch(() => ({ requests: [] })),
        api.getPromotionPackages().catch(() => ({ packages: [] })),
        api.getAdminProducts().catch(() => ({ products: [] })),
        api.getAdminOrders().catch(() => ({ count: 0, orders: [] })),
      ]);

      setStats(statsRes.stats);
      setOffers(offersRes.offers || []);
      setShops(shopsRes.shops || []);
      setAuditLogs(logsRes.auditLogs || []);
      setPromotionRequests(promoRes.promotionRequests || []);
      setVerificationRequests(verifRes.requests || []);
      setPromotionPackages(pkgsRes.packages || []);
      setProducts(prodsRes.products || []);
      setOrders(ordsRes.orders || []);
    } catch (err: any) {
      console.error('Failed to load admin data:', err);
      showToast(err.message || 'Failed to load moderation data', 'error');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [isSuperAdmin, showToast]);

  const handlePromotionAction = async (
    id: string,
    action: 'approve' | 'reject' | 'activate' | 'deactivate',
    adminNotes?: string,
    extra?: { startDate?: string; expiresAt?: string; durationDays?: number }
  ) => {
    try {
      setActionLoadingId(id);
      await api.handlePromotionAction(id, action, adminNotes, extra);
      showToast(`Promotion ${action} action applied successfully`, 'success');
      loadAdminData();
    } catch (err: any) {
      showToast(err.message || `Failed to ${action} promotion`, 'error');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleVerificationAction = async (
    id: string,
    action: 'approve' | 'reject' | 'revoke',
    adminNotes?: string
  ) => {
    try {
      setActionLoadingId(id);
      const res = await api.handleVerificationAction(id, action, adminNotes);
      showToast(res.message || `Verification ${action} applied`, 'success');
      loadAdminData();
    } catch (err: any) {
      showToast(err.message || `Failed to ${action} verification`, 'error');
    } finally {
      setActionLoadingId(null);
    }
  };

  useEffect(() => {
    if (isSuperAdmin) {
      loadAdminData();
    } else {
      setIsLoading(false);
    }
  }, [isSuperAdmin, loadAdminData]);

  // Handle Admin Password Login
  const handleAdminPasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail.trim() || !authPassword) {
      setAuthError('Please provide both administrator email and password.');
      return;
    }
    setIsAuthSubmitting(true);
    setAuthError(null);
    try {
      const loggedUser = await login(authEmail.trim(), authPassword);
      if (loggedUser.role !== 'admin') {
        setAuthError(`Access restricted: ${loggedUser.email} is not authorized for administrative access.`);
      } else {
        showToast(`Welcome Founder & Administrator ${loggedUser.name}!`, 'success');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Administrative login failed. Verify your credentials.');
    } finally {
      setIsAuthSubmitting(false);
    }
  };

  // Handle Admin Google Login
  const handleAdminGoogleLogin = async () => {
    setIsAuthSubmitting(true);
    setAuthError(null);
    try {
      const loggedUser = await loginWithGoogle();
      if (loggedUser.role !== 'admin' && loggedUser.email !== 'citydeals.discoverlocal@gmail.com') {
        setAuthError(`Access restricted: ${loggedUser.email} is not authorized for administrative access.`);
      } else {
        showToast(`Authenticated as Administrator ${loggedUser.name}!`, 'success');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Google sign-in failed.');
    } finally {
      setIsAuthSubmitting(false);
    }
  };

  // Handle Approve Offer Action
  const handleApproveOffer = async (offer: Offer) => {
    setActionLoadingId(offer.id);
    try {
      const res = await api.approveOffer(offer.id);
      showToast(`Offer "${offer.headline}" approved and live in the directory!`, 'success');

      // Update local state immediately
      setOffers((prev) =>
        prev.map((o) => (o.id === offer.id ? { ...o, status: 'approved', isActive: true, rejectionReason: null } : o))
      );

      // Refresh stats
      api.getAdminStats().then((res) => res.stats && setStats(res.stats));
    } catch (err: any) {
      showToast(err.message || 'Failed to approve offer', 'error');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Open Rejection Modal
  const openRejectionModal = (offer: Offer) => {
    setRejectingOffer(offer);
    setRejectionReason('');
    setRejectionNotes('');
  };

  // Handle Confirm Rejection Action
  const handleConfirmRejection = async () => {
    if (!rejectingOffer) return;
    if (!rejectionReason.trim()) {
      showToast('Please specify a rejection reason for the shopkeeper.', 'error');
      return;
    }

    setIsSubmittingReject(true);
    try {
      await api.rejectOffer(rejectingOffer.id, rejectionReason.trim());
      showToast(`Offer rejected and notification saved for merchant.`, 'success');

      // Update local state immediately
      setOffers((prev) =>
        prev.map((o) =>
          o.id === rejectingOffer.id
            ? { ...o, status: 'rejected', isActive: false, rejectionReason: rejectionReason.trim() }
            : o
        )
      );

      setRejectingOffer(null);
      api.getAdminStats().then((res) => res.stats && setStats(res.stats));
    } catch (err: any) {
      showToast(err.message || 'Failed to reject offer', 'error');
    } finally {
      setIsSubmittingReject(false);
    }
  };

  // Product moderation handlers
  const handleApproveProduct = async (productId: string) => {
    try {
      setActionLoadingId(productId);
      await api.approveProduct(productId);
      showToast('Product approved! It is now live in CityDeals Shopping.', 'success');
      setProducts((prev) =>
        prev.map((p) => (p.id === productId ? { ...p, status: 'approved' } : p))
      );
    } catch (err: any) {
      showToast(err.message || 'Failed to approve product', 'error');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleRejectProduct = async (productId: string) => {
    const reason = window.prompt('Specify reason for rejecting this product:');
    if (!reason || !reason.trim()) return;

    try {
      setActionLoadingId(productId);
      await api.rejectProduct(productId, reason.trim());
      showToast('Product marked as rejected.', 'info');
      setProducts((prev) =>
        prev.map((p) =>
          p.id === productId ? { ...p, status: 'rejected', rejectionReason: reason.trim() } : p
        )
      );
    } catch (err: any) {
      showToast(err.message || 'Failed to reject product', 'error');
    } finally {
      setActionLoadingId(null);
    }
  };

  const pendingProductsCount = products.filter((p) => p.status === 'pending').length;

  // Filter offers based on activeTab, search, and district
  const filteredOffers = offers.filter((offer) => {
    if (activeTab === 'pending' && offer.status !== 'pending') return false;
    if (activeTab === 'approved' && offer.status !== 'approved') return false;
    if (activeTab === 'rejected' && offer.status !== 'rejected') return false;
    if (activeTab === 'expired' && offer.status !== 'expired') return false;

    if (districtFilter !== 'all') {
      const offerDist = offer.district || offer.city;
      if (offerDist && offerDist.toLowerCase() !== districtFilter.toLowerCase()) {
        return false;
      }
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchHeadline = offer.headline?.toLowerCase().includes(q);
      const matchShop = offer.shopName?.toLowerCase().includes(q);
      const matchLocality = offer.locality?.toLowerCase().includes(q);
      const matchCategory = offer.category?.toLowerCase().includes(q);
      if (!matchHeadline && !matchShop && !matchLocality && !matchCategory) {
        return false;
      }
    }

    return true;
  });

  const pendingCount = offers.filter((o) => o.status === 'pending').length;
  const approvedCount = offers.filter((o) => o.status === 'approved').length;
  const rejectedCount = offers.filter((o) => o.status === 'rejected').length;
  const expiredCount = offers.filter((o) => o.status === 'expired').length;
  const pendingPromotionCount = promotionRequests.filter((p) => p.status === 'pending' || p.status === 'pending_verification' || p.paymentStatus === 'pending').length;
  const activePromotionCount = promotionRequests.filter((p) => p.status === 'active' || p.status === 'approved').length;
  const pendingVerificationCount = verificationRequests.filter((v) => v.status === 'pending' || v.status === 'pending_review').length;
  const verifiedShopCount = shops.filter((s) => s.isVerified || s.verifiedBadge || (s as any).verified).length;

  // ==================== 1. UNAUTHENTICATED OR NON-ADMIN GATEWAY ====================
  if (!isAuthenticated || !isSuperAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950 text-white flex flex-col justify-center items-center px-4 py-12">
        <div className="w-full max-w-md bg-slate-900/90 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative">
          <div className="text-center space-y-3 mb-6">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-orange-500/20 border border-amber-300/30">
              <ShieldCheck className="w-7 h-7 text-white" />
            </div>
            <div>
              <span className="text-[11px] font-bold tracking-widest text-amber-400 uppercase">
                Restricted Administration
              </span>
              <h1 className="text-2xl font-black text-white mt-1">Founder Control Centre</h1>
              <p className="text-xs text-slate-400 mt-1">
                Authorized Personnel Only • CityDeals Platform Management
              </p>
            </div>
          </div>

          {/* Access Warning if user is logged in as non-admin */}
          {isAuthenticated && role !== 'admin' && (
            <div className="mb-6 p-4 rounded-2xl bg-rose-950/70 border border-rose-600/50 text-rose-200 text-xs flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-white">Access Denied (Role: {role})</p>
                <p className="mt-0.5 text-rose-300">
                  Your signed-in account ({user.email}) is not recognized as an authorized administrator. Only{' '}
                  <strong className="text-white">citydeals.discoverlocal@gmail.com</strong> has platform founder privileges.
                </p>
                <button
                  onClick={() => logout()}
                  className="mt-3 px-3 py-1 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-lg text-[11px] transition-colors"
                >
                  Sign Out & Switch Account
                </button>
              </div>
            </div>
          )}

          {authError && (
            <div className="mb-4 p-3 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {/* Google Sign-In with Authorized Admin Email */}
          <div className="space-y-4">
            <button
              onClick={handleAdminGoogleLogin}
              disabled={isAuthSubmitting}
              className="w-full py-3 px-4 rounded-xl border border-slate-700 bg-slate-800/90 hover:bg-slate-700/90 text-white font-bold text-sm shadow-md flex items-center justify-center gap-3 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{isAuthSubmitting ? 'Verifying...' : 'Sign In with Authorized Google Account'}</span>
            </button>

            <div className="relative flex items-center justify-center my-3">
              <div className="border-t border-slate-700 w-full" />
              <span className="bg-slate-900 px-3 text-[11px] uppercase tracking-wider text-slate-500 font-semibold absolute">
                or admin credentials
              </span>
            </div>

            <form onSubmit={handleAdminPasswordLogin} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Administrator Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    required
                    placeholder="citydeals.discoverlocal@gmail.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Security Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    required
                    placeholder="••••••••••••"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isAuthSubmitting}
                className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold text-sm rounded-xl shadow-lg shadow-orange-500/20 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2 mt-2"
              >
                <UserCheck className="w-4 h-4" />
                <span>{isAuthSubmitting ? 'Authenticating...' : 'Access Founder Console'}</span>
              </button>
            </form>
          </div>

          <div className="mt-6 pt-5 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <button
              onClick={() => setActiveView('browse')}
              className="hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Public Storefront</span>
            </button>
            <span className="text-[10px] text-slate-500 font-mono">CityDeals v2.4 • Admin Portal</span>
          </div>
        </div>
      </div>
    );
  }

  // ==================== 2. AUTHENTICATED PRIVATE ADMIN DASHBOARD ====================
  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 pb-20">
      {/* Top Admin Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-900 text-white shadow-lg border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-md border border-amber-300/30">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-white text-base tracking-tight">Founder Control Centre</span>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase tracking-wider">
                  Super Admin
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                CityDeals Assam • Authenticated as <strong className="text-slate-200">{user.email}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={loadAdminData}
              disabled={isRefreshing}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
              title="Refresh queue"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">Refresh Queue</span>
            </button>

            <button
              onClick={() => setActiveView('browse')}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-bold text-white flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Public Directory</span>
            </button>

            <button
              onClick={logout}
              className="px-3 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 text-xs font-semibold text-rose-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">
        {/* Preview Application As Section (Requirement 5) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center shrink-0 shadow-2xs">
              <Eye className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base text-slate-900">Preview Application As</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 uppercase tracking-wider">
                  Admin Safe Preview
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 max-w-2xl leading-relaxed">
                Inspect how merchants and public citizens experience CityDeals in real time without creating separate test accounts, signing out, or modifying your actual admin role.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 bg-slate-50 p-1.5 rounded-2xl border border-slate-200/80">
            <button
              onClick={() => {
                setAdminPreviewMode('admin');
                setActiveView('admin');
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                adminPreviewMode === 'admin'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Admin View</span>
            </button>

            <button
              onClick={() => {
                setAdminPreviewMode('merchant');
                setActiveView('merchant');
                showToast('Switched to Merchant Preview View', 'info');
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                adminPreviewMode === 'merchant'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-blue-50 hover:text-blue-700 border border-slate-200'
              }`}
            >
              <Store className="w-3.5 h-3.5 text-blue-600" />
              <span>Merchant View</span>
            </button>

            <button
              onClick={() => {
                setAdminPreviewMode('public');
                setActiveView('browse');
                showToast('Switched to Public Citizen Preview View', 'info');
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                adminPreviewMode === 'public'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-emerald-600" />
              <span>Public View</span>
            </button>
          </div>
        </div>

        {/* Live Database-Backed Statistics Section */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-800">
                Live Database Statistics (CityDeals Platform Overview)
              </h2>
            </div>
            <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
              Real-time unique accounts & listings
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {/* 1. Total Registered Users */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center justify-between text-slate-500 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">Registered Users</span>
                <Users className="w-4 h-4 text-slate-600" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-slate-900">
                {stats?.totalRegisteredUsers ?? '...'}
              </p>
              <p className="text-[10px] text-slate-500 mt-0.5">Unique citizens & merchants</p>
            </div>

            {/* 2. Total Customers */}
            <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200/70">
              <div className="flex items-center justify-between text-emerald-700 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">Customers</span>
                <Compass className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-emerald-950">
                {stats?.totalCustomers ?? '...'}
              </p>
              <p className="text-[10px] text-emerald-700 mt-0.5">Public shoppers</p>
            </div>

            {/* 3. Total Merchants */}
            <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200/70">
              <div className="flex items-center justify-between text-blue-700 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">Merchants</span>
                <Store className="w-4 h-4 text-blue-600" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-blue-950">
                {stats?.totalMerchants ?? '...'}
              </p>
              <p className="text-[10px] text-blue-700 mt-0.5">Shopkeeper accounts</p>
            </div>

            {/* 4. Total Offers */}
            <div className="p-3.5 rounded-xl bg-indigo-50/70 border border-indigo-200/70">
              <div className="flex items-center justify-between text-indigo-700 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">Total Offers</span>
                <Tag className="w-4 h-4 text-indigo-600" />
              </div>
              <p className="text-xl sm:text-2xl font-black text-indigo-950">
                {stats?.totalOffers ?? offers.length}
              </p>
              <p className="text-[10px] text-indigo-700 mt-0.5">All submitted deals</p>
            </div>

            {/* 5. Pending Offers */}
            <div
              onClick={() => setActiveTab('pending')}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                activeTab === 'pending'
                  ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                  : 'bg-amber-50/80 border-amber-200/80 text-amber-950 hover:bg-amber-100/70'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] font-bold uppercase tracking-wider ${activeTab === 'pending' ? 'text-white' : 'text-amber-800'}`}>
                  Pending Offers
                </span>
                <Clock className={`w-4 h-4 ${activeTab === 'pending' ? 'text-white' : 'text-amber-600'}`} />
              </div>
              <p className="text-xl sm:text-2xl font-black">
                {stats?.pendingOffers ?? pendingCount}
              </p>
              <p className={`text-[10px] mt-0.5 ${activeTab === 'pending' ? 'text-amber-100' : 'text-amber-700'}`}>
                Awaiting approval
              </p>
            </div>

            {/* 6. Approved Offers */}
            <div
              onClick={() => setActiveTab('approved')}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                activeTab === 'approved'
                  ? 'bg-blue-600 text-white border-blue-700 shadow-sm'
                  : 'bg-sky-50/80 border-sky-200/80 text-sky-950 hover:bg-sky-100/70'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] font-bold uppercase tracking-wider ${activeTab === 'approved' ? 'text-white' : 'text-sky-800'}`}>
                  Approved Offers
                </span>
                <CheckCircle2 className={`w-4 h-4 ${activeTab === 'approved' ? 'text-white' : 'text-sky-600'}`} />
              </div>
              <p className="text-xl sm:text-2xl font-black">
                {stats?.approvedOffers ?? approvedCount}
              </p>
              <p className={`text-[10px] mt-0.5 ${activeTab === 'approved' ? 'text-sky-100' : 'text-sky-700'}`}>
                Live in directory
              </p>
            </div>

            {/* 7. Rejected Offers */}
            <div
              onClick={() => setActiveTab('rejected')}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                activeTab === 'rejected'
                  ? 'bg-rose-600 text-white border-rose-700 shadow-sm'
                  : 'bg-rose-50/80 border-rose-200/80 text-rose-950 hover:bg-rose-100/70'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] font-bold uppercase tracking-wider ${activeTab === 'rejected' ? 'text-white' : 'text-rose-800'}`}>
                  Rejected Offers
                </span>
                <XCircle className={`w-4 h-4 ${activeTab === 'rejected' ? 'text-white' : 'text-rose-600'}`} />
              </div>
              <p className="text-xl sm:text-2xl font-black">
                {stats?.rejectedOffers ?? rejectedCount}
              </p>
              <p className={`text-[10px] mt-0.5 ${activeTab === 'rejected' ? 'text-rose-100' : 'text-rose-700'}`}>
                Declined listings
              </p>
            </div>
          </div>
        </div>

        {/* Metric Overview Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3 sm:gap-4">
          <div
            onClick={() => setActiveTab('pending')}
            className={`cursor-pointer p-4 rounded-2xl border transition-all ${
              activeTab === 'pending'
                ? 'bg-amber-500 text-white border-amber-600 shadow-lg scale-[1.02]'
                : 'bg-white hover:bg-amber-50/50 text-slate-800 border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-bold uppercase tracking-wider ${activeTab === 'pending' ? 'text-amber-100' : 'text-amber-700'}`}>
                Pending Offers
              </span>
              {pendingCount > 0 && (
                <span className={`w-2.5 h-2.5 rounded-full animate-ping ${activeTab === 'pending' ? 'bg-white' : 'bg-amber-500'}`} />
              )}
            </div>
            <p className="text-2xl sm:text-3xl font-black mt-1">{pendingCount}</p>
            <p className={`text-[10px] sm:text-[11px] mt-0.5 ${activeTab === 'pending' ? 'text-amber-100' : 'text-slate-500'}`}>
              Moderation queue
            </p>
          </div>

          <div
            onClick={() => setActiveTab('promotions')}
            className={`cursor-pointer p-4 rounded-2xl border transition-all ${
              activeTab === 'promotions'
                ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white border-orange-600 shadow-lg scale-[1.02]'
                : 'bg-white hover:bg-amber-50/50 text-slate-800 border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-bold uppercase tracking-wider ${activeTab === 'promotions' ? 'text-amber-100' : 'text-amber-700'}`}>
                Promotions
              </span>
              {pendingPromotionCount > 0 && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${activeTab === 'promotions' ? 'bg-white text-orange-700' : 'bg-orange-500 text-white'}`}>
                  {pendingPromotionCount}
                </span>
              )}
            </div>
            <p className="text-2xl sm:text-3xl font-black mt-1">{promotionRequests.length}</p>
            <p className={`text-[10px] sm:text-[11px] mt-0.5 ${activeTab === 'promotions' ? 'text-amber-100' : 'text-slate-500'}`}>
              {activePromotionCount} active campaigns
            </p>
          </div>

          <div
            onClick={() => setActiveTab('verifications')}
            className={`cursor-pointer p-4 rounded-2xl border transition-all ${
              activeTab === 'verifications'
                ? 'bg-emerald-600 text-white border-emerald-700 shadow-lg scale-[1.02]'
                : 'bg-white hover:bg-emerald-50/50 text-slate-800 border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-bold uppercase tracking-wider ${activeTab === 'verifications' ? 'text-emerald-100' : 'text-emerald-700'}`}>
                Verifications
              </span>
              {pendingVerificationCount > 0 && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${activeTab === 'verifications' ? 'bg-white text-emerald-800' : 'bg-emerald-600 text-white'}`}>
                  {pendingVerificationCount}
                </span>
              )}
            </div>
            <p className="text-2xl sm:text-3xl font-black mt-1">{verificationRequests.length}</p>
            <p className={`text-[10px] sm:text-[11px] mt-0.5 ${activeTab === 'verifications' ? 'text-emerald-100' : 'text-slate-500'}`}>
              {verifiedShopCount} verified shops
            </p>
          </div>

          <div
            onClick={() => setActiveTab('approved')}
            className={`cursor-pointer p-4 rounded-2xl border transition-all ${
              activeTab === 'approved'
                ? 'bg-blue-600 text-white border-blue-700 shadow-lg scale-[1.02]'
                : 'bg-white hover:bg-blue-50/50 text-slate-800 border-slate-200 shadow-xs'
            }`}
          >
            <span className={`text-[11px] font-bold uppercase tracking-wider ${activeTab === 'approved' ? 'text-blue-100' : 'text-blue-700'}`}>
              Live Offers
            </span>
            <p className="text-2xl sm:text-3xl font-black mt-1">{approvedCount}</p>
            <p className={`text-[10px] sm:text-[11px] mt-0.5 ${activeTab === 'approved' ? 'text-blue-100' : 'text-slate-500'}`}>
              Active in directory
            </p>
          </div>

          <div
            onClick={() => setActiveTab('expired')}
            className={`cursor-pointer p-4 rounded-2xl border transition-all ${
              activeTab === 'expired'
                ? 'bg-slate-700 text-white border-slate-800 shadow-lg scale-[1.02]'
                : 'bg-white hover:bg-slate-100/70 text-slate-800 border-slate-200 shadow-xs'
            }`}
          >
            <span className={`text-[11px] font-bold uppercase tracking-wider ${activeTab === 'expired' ? 'text-slate-200' : 'text-slate-600'}`}>
              Expired Offers
            </span>
            <p className="text-2xl sm:text-3xl font-black mt-1">{expiredCount}</p>
            <p className={`text-[10px] sm:text-[11px] mt-0.5 ${activeTab === 'expired' ? 'text-slate-200' : 'text-slate-500'}`}>
              Hidden from public
            </p>
          </div>

          <div
            onClick={() => setActiveTab('shops')}
            className={`cursor-pointer p-4 rounded-2xl border transition-all ${
              activeTab === 'shops'
                ? 'bg-slate-900 text-white border-slate-950 shadow-lg scale-[1.02]'
                : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-200 shadow-xs'
            }`}
          >
            <span className={`text-[11px] font-bold uppercase tracking-wider ${activeTab === 'shops' ? 'text-slate-300' : 'text-slate-600'}`}>
              Local Shops
            </span>
            <p className="text-2xl sm:text-3xl font-black mt-1">{shops.length}</p>
            <p className={`text-[10px] sm:text-[11px] mt-0.5 ${activeTab === 'shops' ? 'text-slate-300' : 'text-slate-500'}`}>
              Merchants registered
            </p>
          </div>

          <div
            onClick={() => setActiveTab('rejected')}
            className={`cursor-pointer p-4 rounded-2xl border transition-all ${
              activeTab === 'rejected'
                ? 'bg-rose-600 text-white border-rose-700 shadow-lg scale-[1.02]'
                : 'bg-white hover:bg-rose-50/50 text-slate-800 border-slate-200 shadow-xs'
            }`}
          >
            <span className={`text-[11px] font-bold uppercase tracking-wider ${activeTab === 'rejected' ? 'text-rose-100' : 'text-rose-700'}`}>
              Rejected Deals
            </span>
            <p className="text-2xl sm:text-3xl font-black mt-1">{rejectedCount}</p>
            <p className={`text-[10px] sm:text-[11px] mt-0.5 ${activeTab === 'rejected' ? 'text-rose-100' : 'text-slate-500'}`}>
              Needs merchant edit
            </p>
          </div>
        </div>

        {/* Tab Selector & Filter Bar */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Navigation Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
            <button
              onClick={() => setActiveTab('pending')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'pending'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Pending Review</span>
              {pendingCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-900 text-amber-200 text-[10px]">
                  {pendingCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('promotions')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'promotions'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Promotions</span>
              {pendingPromotionCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-orange-600 text-white text-[10px]">
                  {pendingPromotionCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('verifications')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'verifications'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Shop Verifications</span>
              {pendingVerificationCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-800 text-emerald-100 text-[10px]">
                  {pendingVerificationCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('approved')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'approved'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Approved Deals</span>
            </button>

            <button
              onClick={() => setActiveTab('rejected')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'rejected'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>Rejected</span>
            </button>

            <button
              onClick={() => setActiveTab('expired')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'expired'
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <CalendarX className="w-3.5 h-3.5 text-slate-400" />
              <span>Expired Offers</span>
              {expiredCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-slate-900 text-slate-200 text-[10px]">
                  {expiredCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Tag className="w-3.5 h-3.5" />
              <span>All Offers ({offers.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('shops')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'shops'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              <span>Shops ({shops.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('products')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Products ({products.length})</span>
              {pendingProductsCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[10px]">
                  {pendingProductsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'orders'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <PackageCheck className="w-3.5 h-3.5" />
              <span>Orders ({orders.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('audit')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                activeTab === 'audit'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Audit Logs</span>
            </button>
          </div>

          {/* Search & District Filter Controls */}
          {activeTab !== 'audit' && (
            <div className="flex items-center gap-2 w-full md:w-auto">
              {/* District Filter */}
              <div className="relative">
                <select
                  aria-label="Filter moderation queue by district"
                  value={districtFilter}
                  onChange={(e) => setDistrictFilter(e.target.value)}
                  className="pl-3 pr-8 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                >
                  <option value="all">All Districts</option>
                  <option value="Dibrugarh">Dibrugarh District</option>
                  <option value="Tinsukia">Tinsukia District</option>
                </select>
              </div>

              {/* Search Query */}
              <div className="relative flex-1 md:w-56">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  aria-label="Search deals, shops, or towns"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search deals, shop, town..."
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* Tab 1-5: Offers Moderation Queue & Expired Offers */}
        {(activeTab === 'pending' || activeTab === 'approved' || activeTab === 'rejected' || activeTab === 'expired' || activeTab === 'all') && (
          <div className="space-y-4">
            {isLoading ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
                <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-3" />
                <p className="text-sm font-semibold text-slate-600">Loading moderation records from Firestore...</p>
              </div>
            ) : filteredOffers.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                </div>
                <h3 className="text-lg font-bold text-slate-800">
                  {activeTab === 'pending'
                    ? 'No Pending Offers in Queue'
                    : activeTab === 'expired'
                    ? 'No Expired Offers in Database'
                    : `No ${activeTab} offers found`}
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {activeTab === 'pending'
                    ? 'All merchant offer submissions have been moderated. New submissions from shops across Dibrugarh & Tinsukia will appear here in real-time.'
                    : activeTab === 'expired'
                    ? 'No merchant offers have reached their expiry date yet. Expired offers remain in Firestore and accessible to administrators and merchants.'
                    : 'Try selecting a different district filter or clearing the search query.'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {filteredOffers.map((offer) => {
                  const isPending = offer.status === 'pending';
                  const isApproved = offer.status === 'approved';
                  const isRejected = offer.status === 'rejected';
                  const isExpired = offer.status === 'expired';

                  return (
                    <div
                      key={offer.id}
                      className={`bg-white rounded-2xl p-5 border shadow-sm transition-all hover:shadow-md ${
                        isPending
                          ? 'border-amber-300 ring-1 ring-amber-400/30'
                          : isApproved
                          ? 'border-emerald-200'
                          : isExpired
                          ? 'border-slate-300 bg-slate-50/50'
                          : 'border-slate-200'
                      }`}
                    >
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                        {/* Offer Core Information */}
                        <div className="space-y-3 flex-1">
                          {/* Badges & Meta Row */}
                          <div className="flex flex-wrap items-center gap-2">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1 ${
                                isPending
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300 animate-pulse'
                                  : isApproved
                                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                  : isExpired
                                  ? 'bg-slate-200 text-slate-800 border border-slate-300'
                                  : 'bg-rose-100 text-rose-900 border border-rose-300'
                              }`}
                            >
                              {isPending ? '⏳ Awaiting Review' : isApproved ? '✓ Live & Approved' : isExpired ? '⏱ Expired Deal' : '✕ Rejected'}
                            </span>

                            <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 font-bold text-[10px] uppercase">
                              {offer.category?.replace('-', ' ')}
                            </span>

                            {offer.isDistrictWide && (
                              <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-bold text-[10px] uppercase">
                                📢 District-Wide
                              </span>
                            )}

                            <span className="text-[11px] text-slate-400 ml-auto">
                              ID: <span className="font-mono text-slate-600">{offer.id}</span> • Submitted: {new Date(offer.createdAt).toLocaleDateString()}
                            </span>
                          </div>

                          {/* Offer Headline & Discount Value */}
                          <div>
                            <div className="flex items-baseline gap-2">
                              <h3 className="text-lg font-black text-slate-900 leading-snug">
                                {offer.headline}
                              </h3>
                              <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 font-extrabold text-xs shrink-0">
                                {offer.discountValue}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                              {offer.description}
                            </p>
                          </div>

                          {/* Shop, Merchant & Detailed Location Verification Hierarchy */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2.5 border-t border-slate-100 text-xs text-slate-700 bg-slate-50/70 p-3 rounded-xl border">
                            {/* 1. Shop Name */}
                            <div className="flex items-center gap-1.5 font-bold text-slate-900">
                              <Store className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                              <span className="truncate">Shop: <strong>{offer.shopName}</strong></span>
                            </div>

                            {/* 2. Merchant Name / Account */}
                            <div className="flex items-center gap-1.5 text-slate-800">
                              <User className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                              <span className="truncate">Merchant: <strong>{offer.merchantEmail || offer.merchantId || 'Registered Shopkeeper'}</strong></span>
                            </div>

                            {/* 3. City / District & 4. Area / Locality */}
                            <div className="flex items-center gap-1.5 text-slate-800 sm:col-span-2">
                              <MapPin className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                              <span>
                                City/District: <strong>{offer.district || offer.city || 'Assam'}</strong> • Area/Locality: <strong>{offer.locality}</strong>
                              </span>
                            </div>

                            {/* 5. Full Shop Address & Landmark */}
                            <div className="sm:col-span-2 text-[11px] text-slate-600 flex items-start gap-1.5">
                              <span className="font-semibold text-slate-700 shrink-0">Full Shop Address:</span>
                              <span className="font-medium text-slate-900">
                                {offer.fullAddress || offer.address || `${offer.locality}, ${offer.district || offer.city}`}
                                {offer.landmark ? ` (Landmark: ${offer.landmark})` : ''}
                              </span>
                            </div>

                            {/* 6. Submission Date & Validity */}
                            <div className="flex items-center gap-1.5 text-slate-600">
                              <Calendar className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                              <span>
                                Submitted: <strong>{new Date(offer.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</strong>
                              </span>
                            </div>

                            {/* 7. Contact Phone */}
                            <div className="flex items-center gap-1.5 text-slate-600">
                              <Phone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <span>{offer.contactPhone}</span>
                              {offer.contactWhatsapp && (
                                <span className="text-[10px] text-emerald-700 font-medium">
                                  (WA: {offer.contactWhatsapp})
                                </span>
                              )}
                            </div>

                            {/* 8. Map Coordinates & Map Link Verification */}
                            <div className="sm:col-span-2 pt-1 border-t border-slate-200/60 flex flex-wrap items-center justify-between gap-2">
                              <div className="flex items-center gap-2 text-[11px] text-slate-600 font-mono">
                                <Navigation className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                                <span>
                                  Coordinates: {offer.latitude ? `${offer.latitude.toFixed(4)}, ${offer.longitude?.toFixed(4)}` : 'Auto-geocoded from locality'}
                                </span>
                              </div>

                              {(offer.locationUrl || (offer.latitude && offer.longitude)) && (
                                <a
                                  href={offer.locationUrl || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${offer.shopName}, ${offer.locality}, ${offer.district || offer.city}, Assam`)}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 text-[11px] text-blue-700 hover:text-blue-900 font-bold bg-blue-100/70 hover:bg-blue-100 px-2 py-0.5 rounded-lg border border-blue-200 transition-colors"
                                  title="Verify physical shop location on Google Maps"
                                >
                                  <span>Verify Shop on Google Maps</span>
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                          </div>

                          {/* Terms & Conditions preview */}
                          {offer.terms && offer.terms.length > 0 && (
                            <div className="pt-2 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="font-semibold text-slate-700 block mb-1">Customer Redemption Terms:</span>
                              <ul className="list-disc pl-4 space-y-0.5">
                                {offer.terms.map((t, idx) => (
                                  <li key={idx}>{t}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Rejection reason display if previously rejected */}
                          {offer.rejectionReason && (
                            <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs">
                              <strong className="block font-bold">Recorded Rejection Reason:</strong>
                              <span className="text-rose-700">{offer.rejectionReason}</span>
                            </div>
                          )}
                        </div>

                        {/* Action Panel */}
                        <div className="flex md:flex-col items-center justify-end gap-2 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 md:border-l border-slate-100 md:pl-5">
                          <button
                            onClick={() => openModal('details', offer)}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer w-full justify-center"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Preview</span>
                          </button>

                          {/* Approve Action */}
                          {offer.status !== 'approved' && (
                            <button
                              onClick={() => handleApproveOffer(offer)}
                              disabled={actionLoadingId === offer.id}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 cursor-pointer w-full justify-center"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>{actionLoadingId === offer.id ? 'Approving...' : 'Approve Offer'}</span>
                            </button>
                          )}

                          {/* Reject Action */}
                          {offer.status !== 'rejected' && (
                            <button
                              onClick={() => openRejectionModal(offer)}
                              disabled={actionLoadingId === offer.id}
                              className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer w-full justify-center"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Reject Offer</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 5: Registered Shops Management */}
        {activeTab === 'shops' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200">
              <h3 className="font-extrabold text-slate-900 text-base mb-1">Registered Physical Merchant Directory</h3>
              <p className="text-xs text-slate-500">
                All physical stores registered across Dibrugarh & Tinsukia. Verified shops display official green trust seals.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {shops.map((shop) => (
                <div key={shop.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                        <Store className="w-4 h-4 text-blue-600" />
                        <span>{shop.name}</span>
                        {(shop.isVerified || shop.verified) && (
                          <span title="Verified Shop">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          </span>
                        )}
                      </h4>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {shop.locality}, {shop.district || shop.city}
                      </p>
                    </div>
                    <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 font-bold text-[10px] uppercase">
                      {shop.category}
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1">
                    <p>📍 {shop.fullAddress || shop.address}</p>
                    <p>📞 Phone: {shop.phone}</p>
                    <p className="text-slate-400 font-mono text-[11px]">Merchant ID: {shop.merchantId}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab: Merchant Promotion & Sponsorship Management */}
        {activeTab === 'promotions' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base mb-1 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-500" />
                  <span>Promotion & Sponsorship Management</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Verify UPI/Bank payment references, approve advertising tiers, and schedule active home banner sponsorships.
                </p>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setPromotionFilter(st)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold capitalize transition-colors cursor-pointer ${
                      promotionFilter === st
                        ? 'bg-amber-500 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {promotionRequests.filter((pr) => promotionFilter === 'all' || pr.status === promotionFilter).length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-amber-50 flex items-center justify-center mx-auto text-amber-500">
                  <Sparkles className="w-7 h-7" />
                </div>
                <h4 className="font-bold text-slate-900 text-base">No Promotion Requests</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  No merchant promotion applications currently match the "{promotionFilter}" filter.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {promotionRequests
                  .filter((pr) => promotionFilter === 'all' || pr.status === promotionFilter)
                  .map((pr) => {
                    const pkg = promotionPackages.find((p) => p.id === pr.packageId);
                    const offer = offers.find((o) => o.id === pr.offerId);
                    const isPending = pr.status === 'pending' || pr.status === 'pending_verification';
                    const isApproved = pr.status === 'approved' || pr.status === 'active';
                    const isRejected = pr.status === 'rejected';

                    return (
                      <div
                        key={pr.id}
                        className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row gap-5 justify-between"
                      >
                        <div className="space-y-3 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase ${
                                isApproved
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : isPending
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              Status: {pr.status}
                            </span>

                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                                pr.paymentStatus === 'verified'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              Payment: {pr.paymentStatus === 'verified' ? 'Verified ✓' : 'Pending Verification'}
                            </span>

                            <span className="text-xs text-slate-400 font-mono">
                              Request #{pr.id.slice(-6).toUpperCase()}
                            </span>
                          </div>

                          <div>
                            <h4 className="text-base font-extrabold text-slate-900">
                              {offer?.headline || pr.offerHeadline || 'Shop Storefront Promotion'}
                            </h4>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Shop: <strong className="text-slate-800">{offer?.shopName || pr.shopName || 'Local Merchant'}</strong> • Package: <strong className="text-blue-700">{pkg?.name || pr.packageName || pr.packageId}</strong> ({pr.durationDays || pkg?.durationDays || 7} Days)
                            </p>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-xs">
                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">Package Fee</span>
                              <span className="font-extrabold text-slate-900 mt-0.5 block">
                                ₹{pr.feeAmount || pr.priceInr || pkg?.priceInr || 199}
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">Payment Reference</span>
                              <span className="font-mono font-bold text-blue-700 mt-0.5 block truncate">
                                {pr.paymentReference || pr.transactionReference || 'Not provided'}
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">Submitted</span>
                              <span className="font-medium text-slate-700 mt-0.5 block">
                                {new Date(pr.createdAt || pr.requestedAt).toLocaleDateString()}
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">Schedule</span>
                              <span className="font-medium text-slate-700 mt-0.5 block">
                                {pr.expiresAt ? `Until ${new Date(pr.expiresAt).toLocaleDateString()}` : 'Not activated'}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex md:flex-col justify-end gap-2 border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-5 shrink-0">
                          {isPending && (
                            <>
                              <button
                                onClick={() => handlePromotionAction(pr.id, 'approve', 'Payment UTR verified by administrator')}
                                disabled={actionLoadingId === pr.id}
                                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                                <span>Verify & Approve</span>
                              </button>

                              <button
                                onClick={() => {
                                  const reason = window.prompt('Enter rejection reason for this promotion request:');
                                  if (reason) handlePromotionAction(pr.id, 'reject', reason);
                                }}
                                disabled={actionLoadingId === pr.id}
                                className="px-4 py-2 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <XCircle className="w-4 h-4" />
                                <span>Reject</span>
                              </button>
                            </>
                          )}

                          {isApproved && (
                            <>
                              <button
                                onClick={() => handlePromotionAction(pr.id, 'activate', undefined, { durationDays: pr.durationDays || 7 })}
                                disabled={actionLoadingId === pr.id}
                                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <Sparkles className="w-4 h-4" />
                                <span>{pr.status === 'active' ? 'Re-activate Campaign' : 'Activate Campaign'}</span>
                              </button>

                              <button
                                onClick={() => handlePromotionAction(pr.id, 'deactivate', 'Deactivated by admin moderation')}
                                disabled={actionLoadingId === pr.id}
                                className="px-4 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <span>Deactivate</span>
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {/* Tab: Paid Shop Verification Management */}
        {activeTab === 'verifications' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base mb-1 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <span>Paid Verified Shop Management (Get Verified)</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Review submitted Trade Licenses, GST credentials, and annual verification fees before granting official badges.
                </p>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setVerificationFilter(st)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold capitalize transition-colors cursor-pointer ${
                      verificationFilter === st
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {verificationRequests.filter((vr) => verificationFilter === 'all' || vr.status === verificationFilter).length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 flex items-center justify-center mx-auto text-emerald-600">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <h4 className="font-bold text-slate-900 text-base">No Verification Requests</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  No shopkeeper verification applications currently match the "{verificationFilter}" filter.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {verificationRequests
                  .filter((vr) => verificationFilter === 'all' || vr.status === verificationFilter)
                  .map((vr) => {
                    const shop = shops.find((s) => s.id === vr.businessId);
                    const isPending = vr.status === 'pending' || vr.status === 'pending_review';
                    const isApproved = vr.status === 'approved' || vr.status === 'verified';
                    const isRejected = vr.status === 'rejected';

                    return (
                      <div
                        key={vr.id}
                        className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row gap-5 justify-between"
                      >
                        <div className="space-y-3 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase ${
                                isApproved
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : isPending
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              Verification: {vr.status}
                            </span>

                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                                vr.paymentStatus === 'verified'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              Payment UTR: {vr.paymentStatus === 'verified' ? 'Verified ✓' : 'Pending Verification'}
                            </span>

                            <span className="text-xs text-slate-400 font-mono">
                              App #{vr.id.slice(-6).toUpperCase()}
                            </span>
                          </div>

                          <div>
                            <h4 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                              <span>{vr.businessName || vr.shopName || shop?.name || 'Local Shop'}</span>
                              {shop?.isVerified && (
                                <span title="Active Verified Merchant">
                                  <Award className="w-4 h-4 text-emerald-600" />
                                </span>
                              )}
                            </h4>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Address: <strong className="text-slate-800">{shop?.fullAddress || shop?.address || 'Dibrugarh'}</strong> • Category: <span className="capitalize">{shop?.category || 'Retail'}</span>
                            </p>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-xs">
                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">Trade License #</span>
                              <span className="font-mono font-bold text-slate-800 mt-0.5 block truncate">
                                {vr.tradeLicenseNumber || 'Not submitted'}
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">GST Number</span>
                              <span className="font-mono font-bold text-slate-800 mt-0.5 block truncate">
                                {vr.gstNumber || 'Not provided'}
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">Payment Ref (UTR)</span>
                              <span className="font-mono font-bold text-blue-700 mt-0.5 block truncate">
                                {vr.paymentReference || 'None'}
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <span className="text-[10px] text-slate-400 uppercase font-bold block">Submitted Date</span>
                              <span className="font-medium text-slate-700 mt-0.5 block">
                                {new Date(vr.createdAt || vr.requestedAt).toLocaleDateString()}
                              </span>
                            </div>
                          </div>

                          {/* Uploaded Document Viewer */}
                          {vr.documentUrl && (
                            <div className="flex items-center gap-2 pt-1 text-xs">
                              <span className="text-slate-500 font-semibold">Supporting Document:</span>
                              <a
                                href={vr.documentUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center gap-1 px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-lg border border-blue-200 transition-colors"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                                <span>View Document Attachment</span>
                              </a>
                            </div>
                          )}

                          {vr.adminNotes && (
                            <p className="text-xs text-slate-600 bg-amber-50/70 p-2.5 rounded-xl border border-amber-200/60">
                              <strong className="text-amber-900 font-bold">Admin Moderation Note:</strong> {vr.adminNotes}
                            </p>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex md:flex-col justify-end gap-2 border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-5 shrink-0">
                          {isPending && (
                            <>
                              <button
                                onClick={() => handleVerificationAction(vr.id, 'approve', 'Official physical store and license verified by CityDeals')}
                                disabled={actionLoadingId === vr.id}
                                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                                <span>Approve & Grant Badge</span>
                              </button>

                              <button
                                onClick={() => {
                                  const reason = window.prompt('Enter reason for rejecting verification application:');
                                  if (reason) handleVerificationAction(vr.id, 'reject', reason);
                                }}
                                disabled={actionLoadingId === vr.id}
                                className="px-4 py-2 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <XCircle className="w-4 h-4" />
                                <span>Reject Application</span>
                              </button>
                            </>
                          )}

                          {isApproved && (
                            <button
                              onClick={() => {
                                if (window.confirm('Are you sure you want to revoke the Verified Badge for this shop?')) {
                                  handleVerificationAction(vr.id, 'revoke', 'Revoked by platform administrator');
                                }
                              }}
                              disabled={actionLoadingId === vr.id}
                              className="px-4 py-2 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                            >
                              <span>Revoke Verification</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}

        {/* Tab: Products Catalog Moderation */}
        {activeTab === 'products' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base mb-0.5">
                  Merchant Products Catalog Moderation
                </h3>
                <p className="text-xs text-slate-500">
                  Review and moderate products submitted by registered merchants across Upper Assam before they appear in CityDeals Shopping.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200 px-3 py-1.5 rounded-xl">
                  {pendingProductsCount} Pending Review
                </span>
                <span className="text-xs font-bold bg-slate-100 text-slate-700 px-3 py-1.5 rounded-xl">
                  {products.length} Total Products
                </span>
              </div>
            </div>

            {products.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500">
                <ShoppingBag className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                <p className="font-bold text-sm text-slate-700">No products uploaded yet</p>
                <p className="text-xs text-slate-400 mt-1">Merchant catalog items will appear here for verification.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {products.map((prod) => (
                  <div
                    key={prod.id}
                    className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs flex flex-col justify-between"
                  >
                    <div className="p-4 space-y-3">
                      <div className="flex gap-3">
                        <img
                          src={prod.imageUrl}
                          alt={prod.name}
                          className="w-20 h-20 rounded-xl object-cover bg-slate-100 shrink-0 border border-slate-200"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded capitalize ${
                                prod.status === 'approved'
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                  : prod.status === 'pending'
                                  ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                  : 'bg-rose-100 text-rose-800 border border-rose-200'
                              }`}
                            >
                              {prod.status}
                            </span>
                            <span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-1.5 py-0.5 rounded capitalize">
                              {prod.category}
                            </span>
                          </div>

                          <h4 className="font-extrabold text-sm text-slate-900 mt-1 truncate" title={prod.name}>
                            {prod.name}
                          </h4>

                          <p className="text-[11px] font-bold text-blue-700 mt-0.5 truncate">
                            {prod.shopName}
                          </p>

                          <p className="text-[10px] text-slate-500 truncate">
                            📍 {prod.locality}, {prod.city}
                          </p>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {prod.description}
                      </p>

                      <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100">
                        <div>
                          <span className="font-black text-sm text-slate-900">
                            ₹{prod.price.toLocaleString('en-IN')}
                          </span>
                          {prod.originalPrice && (
                            <span className="text-[11px] text-slate-400 line-through ml-1.5">
                              ₹{prod.originalPrice.toLocaleString('en-IN')}
                            </span>
                          )}
                        </div>

                        <span className="text-[11px] font-bold text-slate-600">
                          Stock: {prod.stockQuantity} ({prod.inStock ? 'In Stock' : 'Out of Stock'})
                        </span>
                      </div>

                      {/* Fulfillment Badges */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {prod.deliveryAvailable !== false && (
                          <span className="inline-flex items-center gap-1 text-[10px] bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded border border-blue-200">
                            <Truck className="w-3 h-3" /> Delivery
                          </span>
                        )}
                        {prod.pickupAvailable !== false && (
                          <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded border border-emerald-200">
                            <Store className="w-3 h-3" /> Store Pickup
                          </span>
                        )}
                      </div>

                      {prod.rejectionReason && (
                        <p className="text-[11px] text-rose-700 bg-rose-50 p-2 rounded-lg border border-rose-200">
                          <strong>Rejection Note:</strong> {prod.rejectionReason}
                        </p>
                      )}
                    </div>

                    {/* Admin Action Buttons */}
                    <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
                      {prod.status !== 'approved' && (
                        <button
                          onClick={() => handleApproveProduct(prod.id)}
                          disabled={actionLoadingId === prod.id}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer inline-flex items-center gap-1 disabled:opacity-50"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approve</span>
                        </button>
                      )}

                      {prod.status !== 'rejected' && (
                        <button
                          onClick={() => handleRejectProduct(prod.id)}
                          disabled={actionLoadingId === prod.id}
                          className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs shadow-xs cursor-pointer inline-flex items-center gap-1 disabled:opacity-50"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab: Shopping Orders Monitoring */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base mb-0.5">
                  Shopping Orders Monitoring System
                </h3>
                <p className="text-xs text-slate-500">
                  Real-time monitor of all customer shopping orders, merchant fulfillment, and deliveries.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-black bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-xl">
                  {orders.length} Total Orders
                </span>
                <span className="text-xs font-black bg-slate-900 text-white px-3 py-1.5 rounded-xl">
                  ₹{orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0).toLocaleString('en-IN')} GMV
                </span>
              </div>
            </div>

            {orders.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500">
                <PackageCheck className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                <p className="font-bold text-sm text-slate-700">No shopping orders placed yet</p>
                <p className="text-xs text-slate-400 mt-1">Orders placed by customers will be visible here in real time.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {orders.map((ord) => (
                  <div
                    key={ord.id}
                    className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-sm text-slate-900">{ord.orderNumber}</span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded capitalize ${
                              ord.status === 'delivered'
                                ? 'bg-emerald-100 text-emerald-800'
                                : ord.status === 'cancelled' || ord.status === 'rejected'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {ord.status.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Placed on {new Date(ord.createdAt).toLocaleString()}
                        </p>
                      </div>

                      <div className="text-left sm:text-right">
                        <span className="font-black text-base text-slate-900">
                          ₹{ord.totalAmount.toLocaleString('en-IN')}
                        </span>
                        <p className="text-[11px] text-slate-500 capitalize">
                          {ord.paymentMethod.replace(/_/g, ' ')} • {ord.fulfillmentType === 'delivery' ? 'Home Delivery' : 'Store Pickup'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                      <div>
                        <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px] block mb-1">
                          Customer
                        </span>
                        <p className="font-extrabold text-slate-900">{ord.customerName}</p>
                        <p className="text-slate-600">📞 {ord.customerPhone}</p>
                        {ord.customerEmail && <p className="text-slate-500">✉️ {ord.customerEmail}</p>}
                      </div>

                      <div>
                        <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px] block mb-1">
                          Merchant Shop
                        </span>
                        <p className="font-extrabold text-slate-900">{ord.shopName}</p>
                        <p className="text-slate-600">📞 {ord.shopPhone}</p>
                        <p className="text-slate-500 truncate">{ord.shopAddress}</p>
                      </div>

                      <div>
                        <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px] block mb-1">
                          Fulfillment Address
                        </span>
                        <p className="text-slate-700">
                          {ord.fulfillmentType === 'delivery'
                            ? ord.deliveryAddress || 'Delivery Address Provided'
                            : 'Store Pickup by Customer'}
                        </p>
                      </div>
                    </div>

                    {/* Items List */}
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1.5 text-xs">
                      <span className="font-bold text-slate-700 text-[11px] block">
                        Ordered Items ({ord.items.length})
                      </span>
                      {ord.items.map((it, idx) => (
                        <div key={idx} className="flex items-center justify-between text-slate-600">
                          <span>
                            {it.quantity}x {it.productName}
                          </span>
                          <span className="font-bold text-slate-900">
                            ₹{(it.price * it.quantity).toLocaleString('en-IN')}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 6: System Audit Logs */}
        {activeTab === 'audit' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200">
              <h3 className="font-extrabold text-slate-900 text-base mb-1">Administrative Action Audit Trail</h3>
              <p className="text-xs text-slate-500">
                Immutable record of all offer approvals, rejections, and administrative actions stored in Firestore.
              </p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden shadow-xs">
              {auditLogs.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  No moderation actions logged yet.
                </div>
              ) : (
                auditLogs.slice(0, 50).map((log) => (
                  <div key={log.id} className="p-4 flex items-start justify-between gap-3 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 capitalize">
                          {log.action.replace(/_/g, ' ')}
                        </span>
                        <span className="px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-mono text-[10px]">
                          {log.targetType}: {log.targetId}
                        </span>
                      </div>
                      <p className="text-slate-600 mt-1">{log.details}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        By {log.actorEmail} ({log.actorRole})
                      </p>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </main>

      {/* ==================== REJECTION REASON MODAL ==================== */}
      {rejectingOffer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center">
                  <XCircle className="w-5 h-5" />
                </div>
                <h3 className="font-extrabold text-slate-900 text-base">Reject Offer Submission</h3>
              </div>
              <button
                onClick={() => setRejectingOffer(null)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
              <span className="font-bold text-slate-900 block">{rejectingOffer.headline}</span>
              <span className="text-slate-500">
                {rejectingOffer.shopName} • {rejectingOffer.locality}, {rejectingOffer.district || rejectingOffer.city}
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Quick Rejection Presets (Click to insert):
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Discount terms or exclusions are unclear.',
                  'Physical store address cannot be verified.',
                  'Original or discounted pricing is inconsistent.',
                  'Duplicate promotion already active.',
                  'Promotion validity dates are in the past.',
                  'Terms require clarification for walk-in shoppers.',
                ].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setRejectionReason(preset)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-800 hover:border-rose-300 border border-slate-200 rounded-lg text-[11px] font-medium text-slate-700 transition-colors text-left cursor-pointer"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mandatory Rejection Reason (Visible to Merchant):
              </label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={3}
                placeholder="Explain what the shopkeeper needs to correct before re-submitting..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setRejectingOffer(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRejection}
                disabled={isSubmittingReject || !rejectionReason.trim()}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-md transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 cursor-pointer"
              >
                {isSubmittingReject ? 'Saving...' : 'Confirm Rejection'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
