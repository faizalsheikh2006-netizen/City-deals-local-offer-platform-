import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Tag, ShoppingBag, User } from 'lucide-react';

interface BottomNavProps {
  currentTab?: 'home' | 'offers' | 'shopping' | 'profile';
  onNavigateHome: () => void;
  onNavigateOffers: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onNavigateHome,
  onNavigateOffers,
}) => {
  const {
    activeView,
    setActiveView,
    effectiveRole,
    user,
    isAuthenticated,
    openModal,
    cartCount,
  } = useApp();

  // Determine active tab
  let active: 'home' | 'offers' | 'shopping' | 'profile' = 'home';
  if (activeView === 'shopping') {
    active = 'shopping';
  } else if (activeView === 'merchant' || activeView === 'admin') {
    active = 'profile';
  } else if (currentTab === 'offers') {
    active = 'offers';
  } else {
    active = 'home';
  }

  const handleProfileClick = () => {
    if (effectiveRole === 'merchant') {
      setActiveView('merchant');
    } else if (effectiveRole === 'admin') {
      setActiveView('admin');
    } else if (isAuthenticated && user?.email && !user.email.includes('visitor@citydeals.in')) {
      // Authenticated public shopper - open order history and account overview
      openModal('order-history');
    } else {
      // Unauthenticated visitor - open login
      openModal('auth', { tab: 'login' });
    }
  };

  const getProfileLabel = () => {
    if (activeView === 'merchant') return 'Portal';
    if (activeView === 'admin') return 'Admin';
    if (effectiveRole === 'merchant') return 'Merchant';
    if (effectiveRole === 'admin') return 'Admin';
    if (isAuthenticated && user?.name && user.name !== 'Dibrugarh Visitor') {
      return user.name.split(' ')[0];
    }
    return 'Profile';
  };

  return (
    <nav
      aria-label="Bottom Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] transition-all select-none print:hidden"
    >
      <div className="max-w-lg sm:max-w-xl md:max-w-2xl mx-auto px-2 py-1 flex items-center justify-around">
        {/* TAB 1: HOME */}
        <button
          type="button"
          onClick={onNavigateHome}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer relative ${
            active === 'home'
              ? 'text-blue-600 font-extrabold'
              : 'text-slate-600 hover:text-slate-900 font-semibold'
          }`}
        >
          <div className="relative">
            <Home className={`w-5 h-5 transition-transform ${active === 'home' ? 'scale-110 text-blue-600 stroke-[2.4]' : 'stroke-[1.8]'}`} />
            {active === 'home' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-blue-600 rounded-full" />
            )}
          </div>
          <span className="text-[11px] mt-1 tracking-tight">Home</span>
        </button>

        {/* TAB 2: OFFERS */}
        <button
          type="button"
          onClick={onNavigateOffers}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer relative ${
            active === 'offers'
              ? 'text-blue-600 font-extrabold'
              : 'text-slate-600 hover:text-slate-900 font-semibold'
          }`}
        >
          <div className="relative">
            <Tag className={`w-5 h-5 -rotate-45 transition-transform ${active === 'offers' ? 'scale-110 text-blue-600 stroke-[2.4]' : 'stroke-[1.8]'}`} />
            {active === 'offers' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-blue-600 rounded-full" />
            )}
          </div>
          <span className="text-[11px] mt-1 tracking-tight">Offers</span>
        </button>

        {/* TAB 3: SHOPPING */}
        <button
          type="button"
          onClick={() => {
            setActiveView('shopping');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer relative ${
            active === 'shopping'
              ? 'text-blue-600 font-extrabold'
              : 'text-slate-600 hover:text-slate-900 font-semibold'
          }`}
        >
          <div className="relative">
            <ShoppingBag className={`w-5 h-5 transition-transform ${active === 'shopping' ? 'scale-110 text-blue-600 stroke-[2.4]' : 'stroke-[1.8]'}`} />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-rose-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-xs animate-in zoom-in">
                {cartCount > 9 ? '9+' : cartCount}
              </span>
            )}
            {active === 'shopping' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-blue-600 rounded-full" />
            )}
          </div>
          <span className="text-[11px] mt-1 tracking-tight flex items-center gap-1">
            Shopping
          </span>
        </button>

        {/* TAB 4: PROFILE */}
        <button
          type="button"
          onClick={handleProfileClick}
          className={`flex-1 flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer relative ${
            active === 'profile'
              ? 'text-blue-600 font-extrabold'
              : 'text-slate-600 hover:text-slate-900 font-semibold'
          }`}
        >
          <div className="relative">
            <User className={`w-5 h-5 transition-transform ${active === 'profile' ? 'scale-110 text-blue-600 stroke-[2.4]' : 'stroke-[1.8]'}`} />
            {isAuthenticated && user?.email && !user.email.includes('visitor@citydeals.in') && (
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-500 border-2 border-white rounded-full" />
            )}
            {active === 'profile' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-blue-600 rounded-full" />
            )}
          </div>
          <span className="text-[11px] mt-1 tracking-tight truncate max-w-[70px]">
            {getProfileLabel()}
          </span>
        </button>
      </div>
    </nav>
  );
};
