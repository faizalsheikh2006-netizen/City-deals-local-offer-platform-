import React, { useState } from 'react';
import { Offer, ReportReason } from '../types/index';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { AlertTriangle, X, CheckCircle2, ShieldAlert } from 'lucide-react';

interface ReportModalProps {
  offer: Offer;
  onClose: () => void;
}

const REPORT_REASONS: { id: ReportReason; label: string; desc: string }[] = [
  {
    id: 'misleading',
    label: 'Misleading discount or price claim',
    desc: 'The advertised discount differs from what is actually offered at the shop.',
  },
  {
    id: 'incorrect_terms',
    label: 'Incorrect or hidden terms',
    desc: 'Unannounced restrictions or undisclosed conditions were imposed.',
  },
  {
    id: 'shop_refused_deal',
    label: 'Shop refused to honor offer',
    desc: 'Staff refused to accept the active CityDeals voucher/screen.',
  },
  {
    id: 'expired',
    label: 'Deal already expired or out of stock',
    desc: 'Merchant confirmed the deal has ended or stock is permanently unavailable.',
  },
  {
    id: 'closed_shop',
    label: 'Shop is permanently closed or address is wrong',
    desc: 'Cannot locate shop at the given Dibrugarh address or phone is unreachable.',
  },
  {
    id: 'offensive',
    label: 'Inappropriate or offensive content',
    desc: 'Violates community guidelines or truth in advertising.',
  },
  {
    id: 'other',
    label: 'Other problem',
    desc: 'Any other issue not listed above.',
  },
];

export const ReportModal: React.FC<ReportModalProps> = ({ offer, onClose }) => {
  const { showToast, triggerRefresh } = useApp();
  const [reason, setReason] = useState<ReportReason>('misleading');
  const [details, setDetails] = useState('');
  const [reporterName, setReporterName] = useState('');
  const [reporterContact, setReporterContact] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details.trim()) {
      showToast('Please provide details explaining the issue', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.reportOffer(offer.id, {
        reason,
        details: details.trim(),
        reporterName: reporterName.trim() || 'Dibrugarh Shopper',
        reporterContact: reporterContact.trim() || '',
      });

      setSubmitted(true);
      triggerRefresh();
      showToast('Report submitted to moderation queue', 'success');
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err: any) {
      showToast(err.message || 'Failed to submit report', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-red-100 text-red-700">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Report an Offer</h3>
              <p className="text-xs text-slate-500">
                Help keep CityDeals Dibrugarh trustworthy & verified
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close report modal"
            className="p-1 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900">Report Successfully Logged</h4>
            <p className="text-xs text-slate-600 max-w-sm mx-auto">
              Our Dibrugarh moderation team will review this listing. If the offer is found to be
              misleading or invalid, appropriate corrective action will be taken.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {/* Offer Preview */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Reporting Listing
              </span>
              <p className="font-bold text-slate-800 line-clamp-1">{offer.headline}</p>
              <p className="text-slate-500 text-[11px] mt-0.5">
                {offer.shopName} • {offer.locality}, {offer.city}
              </p>
            </div>

            {/* Reason selector */}
            <div className="space-y-1.5">
              <label htmlFor="report-reason-select" className="block text-xs font-bold text-slate-700">
                Primary Reason for Report <span className="text-red-500">*</span>
              </label>
              <select
                id="report-reason-select"
                value={reason}
                onChange={(e) => setReason(e.target.value as ReportReason)}
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 bg-white text-slate-800 font-medium focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
              >
                {REPORT_REASONS.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Explanation Details */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">
                Describe What Happened <span className="text-red-500">*</span>
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                rows={3}
                placeholder="E.g., Visited the shop on HS Road yesterday. The shopkeeper said this discount is no longer available, or charged full price..."
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-800 focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
                required
              />
            </div>

            {/* Reporter Contact (Optional) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Your Name (Optional)
                </label>
                <input
                  type="text"
                  value={reporterName}
                  onChange={(e) => setReporterName(e.target.value)}
                  placeholder="e.g. Rahul B."
                  className="w-full text-xs rounded-lg border border-slate-300 p-2 text-slate-800"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Contact / Phone (Optional)
                </label>
                <input
                  type="text"
                  value={reporterContact}
                  onChange={(e) => setReporterContact(e.target.value)}
                  placeholder="For follow-up if needed"
                  className="w-full text-xs rounded-lg border border-slate-300 p-2 text-slate-800"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-700 text-white shadow-xs transition-colors disabled:opacity-50"
              >
                {isSubmitting ? 'Submitting...' : 'Submit Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
