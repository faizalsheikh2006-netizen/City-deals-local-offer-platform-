import React, { useState, useEffect } from 'react';
import { Offer, Business } from '../types/index';
import { useApp } from '../context/AppContext';
import {
  X,
  MapPin,
  Clock,
  Phone,
  MessageCircle,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  AlertTriangle,
  Bookmark,
  BookmarkCheck,
  Store,
  Info,
  Calendar,
  Share2,
  Navigation,
  ChevronRight,
  CheckCircle2,
} from 'lucide-react';
import { api } from '../api/client';
import { trackOfferView } from '../lib/analytics';

interface OfferDetailsModalProps {
  offer: Offer;
  onClose: () => void;
}

export const OfferDetailsModal: React.FC<OfferDetailsModalProps> = ({ offer: initialOffer, onClose }) => {
  const { openModal, isOfferSaved, toggleSaveOffer, showToast, shareOffer } = useApp();
  const [currentOffer, setCurrentOffer] = useState<Offer>(initialOffer);
  const [shop, setShop] = useState<Business | null>(null);
  const [otherOffers, setOtherOffers] = useState<Offer[]>([]);
  const saved = isOfferSaved(currentOffer.id);

  // Fetch full details with shop profile and other active offers at this shop
  useEffect(() => {
    // Track Offer View in GA4 (internally deduplicated by ID)
    trackOfferView(currentOffer);

    async function fetchDetails() {
      try {
        const res = await api.getOfferById(currentOffer.id);
        if (res.shop) setShop(res.shop);
        if (res.otherOffers) setOtherOffers(res.otherOffers);
      } catch (err) {
        console.error('Error fetching offer details:', err);
      }
    }
    fetchDetails();
  }, [currentOffer.id]);

  const isExpired = new Date(currentOffer.validUntil).getTime() < Date.now();
  const daysLeft = Math.max(
    0,
    Math.ceil((new Date(currentOffer.validUntil).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
  );

  const handleCall = () => {
    api.trackClick(currentOffer.id);
    window.location.href = `tel:${currentOffer.contactPhone}`;
  };

  const handleWhatsapp = () => {
    api.trackClick(currentOffer.id);
    const wa = currentOffer.contactWhatsapp || currentOffer.contactPhone;
    const cleanWa = wa.replace(/[^0-9]/g, '');
    const msg = encodeURIComponent(
      `Hello! I saw your offer "${currentOffer.headline}" on CityDeals Dibrugarh and would like to visit your shop to redeem it.`
    );
    window.open(`https://wa.me/${cleanWa}?text=${msg}`, '_blank');
  };

  const handleDirections = () => {
    api.trackClick(currentOffer.id);
    const destination = encodeURIComponent(
      `${currentOffer.shopName}, ${currentOffer.locality}, ${currentOffer.city}, Assam`
    );
    window.open(`https://www.google.com/maps/search/?api=1&query=${destination}`, '_blank');
  };

  const handleShare = () => {
    shareOffer(currentOffer);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-2xl sm:rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Modal Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 p-2 rounded-full bg-slate-900/70 hover:bg-slate-900 text-white transition-colors"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Image (Storefront or in-store visual) */}
        <div className="relative h-56 sm:h-64 w-full bg-slate-100 overflow-hidden">
          <img src={currentOffer.imageUrl} alt={currentOffer.shopName} className="w-full h-full object-cover" />

          {/* Badge Overlays */}
          <div className="absolute top-4 left-4 flex flex-col gap-1.5 items-start">
            <span className="bg-red-600 text-white font-extrabold text-sm sm:text-base px-3 py-1.5 rounded-xl shadow-lg">
              {currentOffer.discountValue}
            </span>
            {currentOffer.isSponsored && (
              <span className="bg-slate-900/95 text-amber-300 font-bold text-xs px-2.5 py-1 rounded-lg border border-amber-400/40 flex items-center gap-1 shadow-md">
                <Sparkles className="w-3.5 h-3.5" />
                <span>SPONSORED PARTNER SHOP</span>
              </span>
            )}
          </div>

          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white">
            <span
              className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 backdrop-blur-xs ${
                isExpired
                  ? 'bg-rose-950/90 text-rose-300 border border-rose-500/40'
                  : 'bg-slate-900/85 text-white'
              }`}
            >
              <Clock className={`w-3.5 h-3.5 ${isExpired ? 'text-rose-400' : 'text-amber-400'}`} />
              <span>
                {isExpired
                  ? `Expired on ${new Date(currentOffer.validUntil).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}`
                  : `Valid till ${new Date(currentOffer.validUntil).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })} (${daysLeft} days left)`}
              </span>
            </span>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => toggleSaveOffer(currentOffer.id, currentOffer)}
                className={`p-2 rounded-lg backdrop-blur-md transition-all ${
                  saved ? 'bg-amber-500 text-white' : 'bg-slate-900/80 hover:bg-slate-900 text-white'
                }`}
                title={saved ? 'Saved for shop visit' : 'Save for shop visit'}
              >
                {saved ? <BookmarkCheck className="w-4 h-4 fill-white" /> : <Bookmark className="w-4 h-4" />}
              </button>
              <button
                onClick={handleShare}
                className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-900 text-white backdrop-blur-md transition-colors"
                title="Share"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Modal Body Content */}
        <div className="p-5 sm:p-6 space-y-6 max-h-[65vh] overflow-y-auto">
          {/* Expired Callout if passed validity */}
          {isExpired && (
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="text-xs text-rose-950">
                <p className="font-extrabold text-sm text-rose-900">Offer Validity Expired</p>
                <p className="mt-0.5 leading-relaxed text-rose-800">
                  This promotional deal expired on <strong>{new Date(currentOffer.validUntil).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</strong>. It is no longer valid for in-store redemption. Contact the shopkeeper directly to inquire about current offers.
                </p>
              </div>
            </div>
          )}

          {/* Physical In-Store Redemption Notice (Mandatory Requirement) */}
          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3">
            <Store className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div className="text-xs text-blue-950">
              <p className="font-extrabold text-sm text-blue-900">In-Store Local Discovery</p>
              <p className="mt-0.5 leading-relaxed text-blue-800">
                This is a physical shop offer. Visit the local store in Dibrugarh to browse products and redeem this
                offer at checkout. <em>No online cart or delivery fees.</em>
              </p>
            </div>
          </div>

          {/* Shop Header & Physical Location */}
          <div className="border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-3 bg-slate-50/50">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider block">
                  {currentOffer.category.replace('-', ' ')}
                </span>
                <h3 className="text-lg font-extrabold text-slate-900">{currentOffer.shopName}</h3>
              </div>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verified Local Shop</span>
              </span>
            </div>

            {/* Address & Landmark in Dibrugarh */}
            <div className="flex items-start gap-2 text-xs text-slate-600">
              <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-semibold text-slate-800">
                    {currentOffer.address || `${currentOffer.locality}, ${currentOffer.city}`}
                  </p>
                  {currentOffer.distanceKm !== undefined && (
                    <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                      📍 {currentOffer.distanceKm < 1 ? `${Math.round(currentOffer.distanceKm * 1000)}m away` : `${currentOffer.distanceKm.toFixed(1)} km away`}
                    </span>
                  )}
                </div>
                {currentOffer.landmark && (
                  <p className="text-slate-500 text-[11px] mt-0.5">Landmark: {currentOffer.landmark}</p>
                )}
              </div>
            </div>

            {/* Verification Seal */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-center justify-between text-xs text-emerald-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="font-medium">
                  <strong>Last Verified:</strong> {currentOffer.lastVerifiedAt ? new Date(currentOffer.lastVerifiedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Recently'}
                </span>
              </div>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded">
                Verified Physical Shop
              </span>
            </div>

            {/* Store Opening Hours */}
            {(currentOffer.openingHours || shop?.openingHours) && (
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                <span>
                  <strong>Store Hours:</strong> {currentOffer.openingHours || shop?.openingHours}
                </span>
              </div>
            )}

            {/* Action buttons: Directions & Contact */}
            <div className="pt-2 flex flex-wrap items-center gap-2">
              <button
                onClick={handleDirections}
                className="flex-1 min-w-[140px] flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2.5 px-3 rounded-xl shadow-xs transition-colors"
              >
                <Navigation className="w-4 h-4" />
                <span>View Shop / Directions</span>
              </button>

              <button
                onClick={handleCall}
                className="flex items-center justify-center gap-2 bg-white border border-slate-200 hover:border-blue-500 text-slate-800 font-bold text-xs py-2.5 px-3 rounded-xl transition-colors"
              >
                <Phone className="w-4 h-4 text-blue-600" />
                <span>Call Shop</span>
              </button>

              <button
                onClick={handleWhatsapp}
                className="flex items-center justify-center gap-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs py-2.5 px-3 rounded-xl transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>

          {/* Offer Headline & Description */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
              Offer Headline:
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
              {currentOffer.headline}
            </h2>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed pt-1">
              {currentOffer.description}
            </p>
          </div>

          {/* Terms & Conditions */}
          <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200">
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-900">
                Offer Terms & Redemption Conditions
              </h3>
            </div>

            <ul className="space-y-2 text-xs sm:text-sm text-slate-700">
              {currentOffer.terms && currentOffer.terms.length > 0 ? (
                currentOffer.terms.map((term, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                      {index + 1}
                    </span>
                    <span className="leading-snug">{term}</span>
                  </li>
                ))
              ) : (
                <li className="text-slate-500 italic">Standard in-store policies apply upon redemption.</li>
              )}
            </ul>
          </div>

          {/* Other Active Offers at this same Shop */}
          {otherOffers.length > 0 && (
            <div className="space-y-3 pt-1">
              <div className="flex items-center gap-1.5">
                <Store className="w-4 h-4 text-blue-600" />
                <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                  More Active Offers at {currentOffer.shopName}
                </h4>
              </div>

              <div className="space-y-2">
                {otherOffers.map((other) => (
                  <div
                    key={other.id}
                    onClick={() => setCurrentOffer(other)}
                    className="p-3 rounded-xl border border-slate-200 hover:border-blue-400 bg-white hover:bg-blue-50/40 cursor-pointer transition-colors flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <span className="text-[10px] font-extrabold text-red-600 uppercase block">
                        {other.discountValue}
                      </span>
                      <p className="font-bold text-slate-800 line-clamp-1">{other.headline}</p>
                    </div>
                    <span className="text-blue-600 font-bold flex items-center gap-1 shrink-0 text-[11px]">
                      <span>Switch</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Report offer trigger */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="text-[11px]">Encountered an issue with this shop or offer?</span>
            <button
              onClick={() => {
                onClose();
                openModal('report', currentOffer);
              }}
              className="text-red-600 hover:text-red-800 font-bold inline-flex items-center gap-1"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Report Offer</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
