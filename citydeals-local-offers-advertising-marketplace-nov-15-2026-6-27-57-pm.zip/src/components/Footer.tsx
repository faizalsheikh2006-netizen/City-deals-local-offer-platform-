import React from 'react';
import { useApp } from '../context/AppContext';
import { Tag, MapPin, Heart, Sparkles, Store, Compass } from 'lucide-react';

export const Footer: React.FC = () => {
  const { switchRole, setActiveView, openModal } = useApp();

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand & Launch statement */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white">
                <Tag className="w-4 h-4 -rotate-45" />
              </div>
              <span className="text-lg font-extrabold text-white">
                City<span className="text-blue-400">Deals</span>
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed text-xs">
              The local offers and advertising marketplace for every resident and every business.
              Initial launch market: <strong>Dibrugarh, Assam</strong>.
            </p>
            <div className="inline-flex items-center gap-1.5 text-[11px] text-emerald-300 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded-md">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span>100% Free Public Browsing</span>
            </div>
          </div>

          {/* Col 2: For Shoppers */}
          <div className="space-y-2.5">
            <h2 className="font-bold text-white text-xs uppercase tracking-wider">For Citizens</h2>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => setActiveView('browse')}
                  className="hover:text-white transition-colors"
                >
                  Browse Dibrugarh Deals
                </button>
              </li>
              <li>
                <button
                  onClick={() => openModal('city-selector')}
                  className="hover:text-white transition-colors flex items-center gap-1"
                >
                  <MapPin className="w-3 h-3 text-blue-400" />
                  <span>Assam City Selector</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => openModal('info-about')}
                  className="hover:text-white transition-colors"
                >
                  How Verification Works
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: For Local Businesses */}
          <div className="space-y-2.5">
            <h2 className="font-bold text-white text-xs uppercase tracking-wider">For Shopkeepers</h2>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => {
                    switchRole('merchant');
                    setActiveView('merchant');
                    openModal('post-offer');
                  }}
                  className="hover:text-white transition-colors text-blue-400 font-semibold"
                >
                  + Post a Shop Deal
                </button>
              </li>
              <li>
                <button
                  onClick={() => openModal('info-rates')}
                  className="hover:text-white transition-colors"
                >
                  Sponsored Ads Rate Card
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    switchRole('merchant');
                    setActiveView('merchant');
                  }}
                  className="hover:text-white transition-colors"
                >
                  Merchant Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Expansion & Legal */}
          <div className="space-y-2.5">
            <h2 className="font-bold text-white text-xs uppercase tracking-wider">Roadmap & Governance</h2>
            <p className="text-[11px] text-slate-300 leading-normal">
              Expanding across Assam: Guwahati, Jorhat, Tinsukia, Tezpur, and Silchar.
            </p>
            <ul className="space-y-2 text-xs pt-1">
              <li>
                <button
                  onClick={() => openModal('info-privacy')}
                  className="hover:text-white transition-colors"
                >
                  Consumer Terms & Privacy
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar & Disclaimer */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-300">
          <p>
            © {new Date().getFullYear()} CityDeals. Built for local discovery and economic empowerment in Dibrugarh, Assam.
          </p>
          <div className="flex items-center gap-2">
            <span className="bg-slate-900 px-2.5 py-1 rounded-md border border-slate-800 text-slate-300">
              Dibrugarh, Upper Assam • Physical Shop Directory
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
