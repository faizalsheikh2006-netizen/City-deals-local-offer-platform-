import React, { useState } from 'react';
import { api } from '../api/client';
import { City, Category } from '../types';
import { X, Sparkles, Store, MapPin, Tag, CheckCircle2, AlertCircle, Send } from 'lucide-react';

interface SuggestDealModalProps {
  isOpen: boolean;
  onClose: () => void;
  cities: City[];
  categories: Category[];
}

export const SuggestDealModal: React.FC<SuggestDealModalProps> = ({
  isOpen,
  onClose,
  cities,
  categories,
}) => {
  const [shopName, setShopName] = useState('');
  const [locality, setLocality] = useState('Thana Chariali');
  const [category, setCategory] = useState(categories[0]?.id || 'other-shops');
  const [offerHeadline, setOfferHeadline] = useState('');
  const [estimatedDiscount, setEstimatedDiscount] = useState('');
  const [details, setDetails] = useState('');
  const [submitterName, setSubmitterName] = useState('');
  const [submitterContact, setSubmitterContact] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const dibrugarhCity = cities.find((c) => c.name.toLowerCase() === 'dibrugarh') || cities[0];
  const localities = dibrugarhCity?.localities || [
    'Thana Chariali',
    'Graham Bazar',
    'HS Road',
    'Chowkidinghee',
    'Boiragimoth',
    'Mancotta Road',
    'Phoolbagan',
    'Amolapatty',
    'Naliapool',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!shopName.trim()) {
      setError('Please provide the physical shop name in Dibrugarh.');
      return;
    }
    if (!offerHeadline.trim()) {
      setError('Please enter what deal or discount is being offered.');
      return;
    }

    try {
      setLoading(true);
      await api.suggestDeal({
        shopName: shopName.trim(),
        locality,
        category,
        offerHeadline: offerHeadline.trim(),
        estimatedDiscount: estimatedDiscount.trim() || undefined,
        details: details.trim() || undefined,
        submitterName: submitterName.trim() || undefined,
        submitterContact: submitterContact.trim() || undefined,
      });
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message || 'Failed to submit deal suggestion.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setShopName('');
    setOfferHeadline('');
    setEstimatedDiscount('');
    setDetails('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-800 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <Sparkles className="w-5 h-5 text-blue-200" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-snug">Suggest a Local Deal</h3>
              <p className="text-xs text-blue-100">Help Dibrugarh shoppers discover genuine in-store savings</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="p-6 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h4 className="text-lg font-bold text-slate-900">Thank You, Community Contributor!</h4>
            <p className="text-sm text-slate-600 mt-2 max-w-sm mx-auto">
              Your deal suggestion for <span className="font-semibold text-slate-900">{shopName}</span> has been sent to our Dibrugarh moderation team. Once verified with the shop, it will be published live!
            </p>
            <button
              onClick={handleReset}
              className="mt-6 w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-sm transition-colors shadow-md"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Shop or Outlet Name <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <Store className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  placeholder="e.g. Sharma Sweets, New Market"
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="suggest-deal-locality" className="block text-xs font-semibold text-slate-700 mb-1">
                  Locality / Market Area <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <select
                    id="suggest-deal-locality"
                    value={locality}
                    onChange={(e) => setLocality(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white"
                  >
                    {localities.map((loc) => (
                      <option key={loc} value={loc}>
                        {loc}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="suggest-deal-category" className="block text-xs font-semibold text-slate-700 mb-1">
                  Category
                </label>
                <div className="relative">
                  <Tag className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <select
                    id="suggest-deal-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white"
                  >
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Deal / Offer Headline <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={offerHeadline}
                onChange={(e) => setOfferHeadline(e.target.value)}
                placeholder="e.g. Flat 30% off on all winter wear & jackets"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Discount Tag (Optional)
              </label>
              <input
                type="text"
                value={estimatedDiscount}
                onChange={(e) => setEstimatedDiscount(e.target.value)}
                placeholder="e.g. 30% OFF, BUY 1 GET 1, FLAT ₹500"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Additional Details or Terms (Optional)
              </label>
              <textarea
                rows={2}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="e.g. Offer valid on bills over ₹1,000 until this Sunday."
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-100">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Your Name (Optional)
                </label>
                <input
                  type="text"
                  value={submitterName}
                  onChange={(e) => setSubmitterName(e.target.value)}
                  placeholder="Citizen Contributor"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Phone / WhatsApp (Optional)
                </label>
                <input
                  type="text"
                  value={submitterContact}
                  onChange={(e) => setSubmitterContact(e.target.value)}
                  placeholder="+91 98xxx xxxxx"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl font-semibold text-sm transition-all shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <span>Submitting...</span>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Submit Deal for Verification</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
