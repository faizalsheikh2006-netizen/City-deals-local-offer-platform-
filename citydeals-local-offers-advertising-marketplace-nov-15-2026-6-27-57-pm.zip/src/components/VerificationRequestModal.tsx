import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { uploadFileToStorage } from '../lib/firebase';
import {
  ShieldCheck,
  X,
  Upload,
  FileCheck,
  AlertCircle,
  QrCode,
  CheckCircle2,
  Building,
  FileText,
  CreditCard,
  Lock,
} from 'lucide-react';

interface VerificationRequestModalProps {
  onClose: () => void;
  onSuccess?: () => void;
}

export const VerificationRequestModal: React.FC<VerificationRequestModalProps> = ({
  onClose,
  onSuccess,
}) => {
  const { business, user, showToast, triggerRefresh } = useApp();

  const [tradeLicense, setTradeLicense] = useState('');
  const [gstNumber, setGstNumber] = useState('');
  const [documentType, setDocumentType] = useState<
    'trade_license' | 'gst_certificate' | 'utility_bill' | 'shop_establishment' | 'other'
  >('trade_license');
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [documentPreviewUrl, setDocumentPreviewUrl] = useState<string>('');
  const [documentName, setDocumentName] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('UPI Transfer (GPay / PhonePe / Paytm)');
  const [txnRef, setTxnRef] = useState<string>('');
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    setDocumentFile(file);
    setDocumentName(file.name);
    setErrorMessage(null);

    // If image, create local preview
    if (file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      setDocumentPreviewUrl(url);
    } else {
      setDocumentPreviewUrl('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!documentFile && !documentPreviewUrl) {
      setErrorMessage('Please upload a business registration document (Trade license, GST, or Utility bill).');
      return;
    }

    if (!txnRef.trim()) {
      setErrorMessage('Please enter your transaction reference or UTR number.');
      return;
    }

    try {
      setIsSubmitting(true);
      let uploadedDocUrl = documentPreviewUrl;

      if (documentFile) {
        setIsUploading(true);
        const storagePath = `verifications/${business?.id || 'biz'}_${Date.now()}_${documentFile.name}`;
        uploadedDocUrl = await uploadFileToStorage(documentFile, storagePath);
        setIsUploading(false);
      }

      await api.submitMerchantVerification({
        tradeLicenseNumber: tradeLicense.trim() || undefined,
        gstNumber: gstNumber.trim() || undefined,
        documentType,
        documentUrl: uploadedDocUrl,
        documentName: documentName || 'verification_document',
        paymentMethod,
        paymentReference: txnRef.trim(),
      });

      showToast('Verification application submitted! Awaiting administrator document verification.', 'success');
      triggerRefresh();
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Verification submit error:', err);
      setErrorMessage(err.message || 'Failed to submit verification request. Please try again.');
    } finally {
      setIsSubmitting(false);
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 text-white shadow-xs">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight">Apply for Verified Shop Badge</h2>
                <span className="text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Official Seal
                </span>
              </div>
              <p className="text-xs text-blue-100 font-medium">Build shopper trust across Tinsukia & Dibrugarh</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Info Banner */}
        <div className="bg-blue-50 px-6 py-3 border-b border-blue-100 text-xs text-blue-900 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <p className="font-bold">Verified Shop Benefits:</p>
            <p className="text-blue-800 text-[11px] mt-0.5">
              Verified merchants receive an official non-clickable green trust seal on shop profiles and deal cards,
              priority visibility in customer feeds, and protection against unauthorized impersonation.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {errorMessage && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Shop Context */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider">Shop Profile</span>
              <span className="text-slate-900 font-extrabold">{business?.name || 'Your Registered Shop'}</span>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span>Location:</span>
              <span className="font-medium text-slate-800">
                {business?.locality || 'Assam'}, {business?.district || business?.city || 'Dibrugarh'}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-600">
              <span>Verification Annual Fee:</span>
              <span className="font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-xs">
                ₹499 / 1 Year
              </span>
            </div>
          </div>

          {/* Registration Identifiers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Trade License Number (Optional)
              </label>
              <input
                type="text"
                value={tradeLicense}
                onChange={(e) => setTradeLicense(e.target.value)}
                placeholder="e.g. DMB/TL/2026/0491"
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-medium bg-white text-slate-900 focus:outline-none focus:border-blue-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                GSTIN Number (Optional)
              </label>
              <input
                type="text"
                value={gstNumber}
                onChange={(e) => setGstNumber(e.target.value)}
                placeholder="e.g. 18AAAAA0000A1Z5"
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-medium bg-white text-slate-900 focus:outline-none focus:border-blue-600 font-mono uppercase"
              />
            </div>
          </div>

          {/* Document Upload Type */}
          <div>
            <label htmlFor="verification-doc-type" className="block text-xs font-bold text-slate-700 mb-1">
              Document Type to Upload <span className="text-rose-500">*</span>
            </label>
            <select
              id="verification-doc-type"
              value={documentType}
              onChange={(e) => setDocumentType(e.target.value as any)}
              className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-medium bg-white text-slate-900 focus:outline-none focus:border-blue-600"
            >
              <option value="trade_license">Municipal Trade License (Dibrugarh / Tinsukia / Makum / Digboi)</option>
              <option value="gst_certificate">GST Registration Certificate</option>
              <option value="shop_establishment">Assam Shops & Establishments Act Certificate</option>
              <option value="utility_bill">Commercial Electricity Bill (APDCL) in Shop Name</option>
              <option value="other">Other Official Government Commercial Registration</option>
            </select>
          </div>

          {/* Document File Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Upload Document Photo or PDF <span className="text-rose-500">*</span>
            </label>
            <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-2xl p-4 text-center bg-slate-50 hover:bg-blue-50/40 transition-colors">
              <input
                type="file"
                id="verification-doc-input"
                accept="image/*,application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />
              <label
                htmlFor="verification-doc-input"
                className="cursor-pointer flex flex-col items-center justify-center gap-2"
              >
                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shadow-xs">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-bold text-blue-600 hover:underline">
                    {documentName ? 'Replace Document File' : 'Click to select from phone gallery or files'}
                  </span>
                  <p className="text-[10px] text-slate-500 mt-0.5">JPG, PNG, WebP or PDF (Max 10MB)</p>
                </div>
              </label>

              {documentName && (
                <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold">
                  <FileCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="truncate max-w-[240px]">{documentName}</span>
                </div>
              )}
            </div>

            {documentPreviewUrl && (
              <div className="mt-2 flex items-center gap-2 p-2 bg-slate-100 rounded-xl">
                <img
                  src={documentPreviewUrl}
                  alt="Document preview"
                  className="w-14 h-14 rounded-lg object-cover bg-white border border-slate-200"
                />
                <div className="text-[11px] text-slate-600">
                  <span className="font-bold text-slate-800 block">Preview Ready</span>
                  <span>Will be uploaded securely to Firebase Storage on submission.</span>
                </div>
              </div>
            )}
          </div>

          {/* Payment Section */}
          <div className="pt-2 border-t border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-xs text-slate-900 flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-blue-600" />
                <span>Verification Fee Payment (₹499)</span>
              </h4>
              <span className="text-[10px] text-slate-500 font-medium">Valid for 365 Days</span>
            </div>

            <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 text-xs text-amber-950 space-y-2">
              <div className="flex items-start gap-2">
                <QrCode className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Pay ₹499 via UPI:</p>
                  <p className="font-mono font-black text-slate-900 text-xs mt-0.5 bg-white/70 px-2 py-0.5 rounded inline-block">
                    citydeals@upi <span className="text-[10px] text-slate-500 font-sans font-normal">(or Scan in Merchant Portal)</span>
                  </p>
                </div>
              </div>
              <p className="text-[11px] text-amber-900 leading-relaxed">
                After completing the ₹499 payment from your UPI app (GPay, PhonePe, Paytm, BHIM), copy the 12-digit UTR
                or transaction reference number below for administrative authentication.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="verification-payment-method" className="block text-xs font-bold text-slate-700 mb-1">Payment Method</label>
                <select
                  id="verification-payment-method"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-medium bg-white text-slate-900 focus:outline-none focus:border-blue-600"
                >
                  <option value="UPI Transfer (GPay / PhonePe / Paytm)">UPI (GPay / PhonePe / Paytm / BHIM)</option>
                  <option value="Direct Bank Transfer (NEFT / IMPS)">Direct Bank Transfer (NEFT / IMPS)</option>
                  <option value="Debit / Credit Card">Debit / Credit Card</option>
                  <option value="Cash / Field Representative">Assam Field Representative</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Transaction Reference / UTR Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={txnRef}
                  onChange={(e) => setTxnRef(e.target.value)}
                  placeholder="e.g. 419283749201"
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 font-mono font-bold bg-white text-slate-900 focus:outline-none focus:border-blue-600"
                />
              </div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-start gap-2">
            <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
            <p>
              Platform integrity policy: Payment alone does not grant verified status. An authorized CityDeals administrator
              verifies your registration document and payment reference before activating your verified badge.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || isUploading}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-md shadow-blue-500/20 transition-all cursor-pointer disabled:opacity-50"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
              <span>{isSubmitting || isUploading ? 'Submitting Application...' : 'Submit Verification Request (₹499)'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
