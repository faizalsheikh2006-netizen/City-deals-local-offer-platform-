import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { ShoppingOrder, OrderStatus } from '../types/index';
import {
  X,
  Store,
  MapPin,
  Phone,
  MessageCircle,
  Truck,
  CheckCircle2,
  Clock,
  AlertCircle,
  Package,
  Calendar,
  ShieldCheck,
  Ban,
} from 'lucide-react';

export const OrderDetailsModal: React.FC = () => {
  const { modalData, closeModal, showToast } = useApp();
  const [order, setOrder] = useState<ShoppingOrder>(modalData);
  const [isCancelling, setIsCancelling] = useState<boolean>(false);
  const [showCancelPrompt, setShowCancelPrompt] = useState<boolean>(false);
  const [cancelReason, setCancelReason] = useState<string>('');

  if (!order) return null;

  const STATUS_CONFIG: Record<
    OrderStatus,
    { label: string; color: string; bg: string; border: string; desc: string }
  > = {
    pending: {
      label: 'Order Placed',
      color: 'text-amber-700',
      bg: 'bg-amber-50',
      border: 'border-amber-200',
      desc: 'Waiting for merchant confirmation.',
    },
    accepted: {
      label: 'Order Accepted',
      color: 'text-blue-700',
      bg: 'bg-blue-50',
      border: 'border-blue-200',
      desc: 'Merchant has verified and accepted your order.',
    },
    preparing: {
      label: 'Preparing Items',
      color: 'text-indigo-700',
      bg: 'bg-indigo-50',
      border: 'border-indigo-200',
      desc: 'Shopkeeper is packing your items.',
    },
    ready_for_pickup: {
      label: 'Ready for Pickup',
      color: 'text-purple-700',
      bg: 'bg-purple-50',
      border: 'border-purple-200',
      desc: 'Ready at shop counter. You can pick it up anytime!',
    },
    out_for_delivery: {
      label: 'Out for Delivery',
      color: 'text-cyan-700',
      bg: 'bg-cyan-50',
      border: 'border-cyan-200',
      desc: 'On its way to your Dibrugarh address.',
    },
    delivered: {
      label: 'Delivered / Completed',
      color: 'text-emerald-700',
      bg: 'bg-emerald-50',
      border: 'border-emerald-200',
      desc: 'Order successfully fulfilled and received.',
    },
    rejected: {
      label: 'Merchant Declined',
      color: 'text-rose-700',
      bg: 'bg-rose-50',
      border: 'border-rose-200',
      desc: 'Item out of stock or shop closed.',
    },
    cancelled: {
      label: 'Cancelled',
      color: 'text-slate-600',
      bg: 'bg-slate-100',
      border: 'border-slate-200',
      desc: 'Order was cancelled.',
    },
  };

  const statusInfo = STATUS_CONFIG[order.status] || STATUS_CONFIG.pending;

  const handleWhatsAppMerchant = () => {
    const phone = order.shopWhatsapp || order.shopPhone || '919435000000';
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const message = encodeURIComponent(
      `Hello ${order.shopName}, I am inquiring about my CityDeals order #${order.orderNumber} for ₹${order.totalAmount}.`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  const handleCancelOrder = async () => {
    try {
      setIsCancelling(true);
      const res = await api.cancelOrder(order.id, cancelReason || 'Cancelled by customer');
      setOrder(res.order);
      setShowCancelPrompt(false);
      showToast('Order cancelled successfully', 'info');
    } catch (err: any) {
      showToast(err.message || 'Could not cancel order', 'error');
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-black text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                #{order.orderNumber}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {new Date(order.createdAt).toLocaleDateString('en-IN', {
                  day: 'numeric',
                  month: 'short',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>
            <h3 className="font-black text-base text-slate-900 mt-1">Order Details</h3>
          </div>

          <button
            onClick={closeModal}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Status Alert Card */}
          <div className={`p-4 rounded-2xl ${statusInfo.bg} ${statusInfo.border} border`}>
            <div className="flex items-center justify-between">
              <span className={`text-xs font-black uppercase tracking-wider ${statusInfo.color}`}>
                Status: {statusInfo.label}
              </span>
              <span className="text-[11px] font-bold text-slate-500 capitalize">
                {order.fulfillmentType === 'delivery' ? 'Home Delivery' : 'Store Pickup'}
              </span>
            </div>
            <p className="text-xs text-slate-700 mt-1 font-medium">{statusInfo.desc}</p>
            {order.merchantNotes && (
              <p className="text-xs text-blue-900 bg-white/70 p-2 rounded-lg mt-2 border border-blue-100">
                <strong>Shop Note:</strong> {order.merchantNotes}
              </p>
            )}
          </div>

          {/* Shop Card */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-blue-600" />
                <h4 className="font-extrabold text-sm text-slate-900">{order.shopName}</h4>
              </div>
              <span className="text-[11px] text-slate-500 font-medium">Dibrugarh Shop</span>
            </div>
            <p className="text-xs text-slate-600 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>{order.shopAddress}</span>
            </p>

            <div className="flex items-center gap-2 mt-3 pt-2.5 border-t border-slate-200">
              <button
                onClick={handleWhatsAppMerchant}
                className="flex-1 py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Contact via WhatsApp</span>
              </button>
              {order.shopPhone && (
                <a
                  href={`tel:${order.shopPhone}`}
                  className="py-1.5 px-3 rounded-xl border border-slate-300 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center justify-center gap-1 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-blue-600" />
                  <span>Call</span>
                </a>
              )}
            </div>
          </div>

          {/* Customer & Delivery Information */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
            <h5 className="font-extrabold text-slate-400 uppercase tracking-wider text-[10px]">
              Customer & Delivery Information
            </h5>
            <p className="text-slate-900 font-bold">
              {order.customerName} • <span className="font-mono">{order.customerPhone}</span>
            </p>
            {order.fulfillmentType === 'delivery' ? (
              <p className="text-slate-600">
                <strong className="text-slate-800">Delivery Address:</strong> {order.deliveryAddress || 'Address not specified'}
              </p>
            ) : (
              <p className="text-slate-600">
                <strong className="text-slate-800">Fulfillment:</strong> Store Pickup at {order.shopAddress}
              </p>
            )}
            {order.customerNotes && (
              <p className="text-slate-500 italic">“{order.customerNotes}”</p>
            )}
          </div>

          {/* Items List */}
          <div className="space-y-2">
            <h5 className="font-extrabold text-slate-400 uppercase tracking-wider text-[10px]">
              Items Ordered ({order.items.length})
            </h5>
            <div className="space-y-2">
              {order.items.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 bg-white text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {item.imageUrl && (
                      <img
                        src={item.imageUrl}
                        alt={item.productName}
                        className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                      />
                    )}
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 truncate">{item.productName}</p>
                      <p className="text-slate-500 text-[11px]">
                        Qty: {item.quantity} × ₹{item.price.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>
                  <span className="font-black text-slate-900 shrink-0 ml-2">
                    ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Pricing Breakdown */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
            <div className="flex justify-between text-slate-600">
              <span>Items Subtotal</span>
              <span className="font-bold text-slate-900">₹{order.subtotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Delivery Fee</span>
              <span className="font-bold text-slate-900">
                {order.deliveryFee === 0 ? 'FREE' : `₹${order.deliveryFee}`}
              </span>
            </div>
            <div className="flex justify-between text-sm font-black text-slate-900 pt-1.5 border-t border-slate-200">
              <span>Total Amount</span>
              <span className="text-blue-700">₹{order.totalAmount.toLocaleString('en-IN')}</span>
            </div>
            <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1 pt-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>
                Payment: {order.fulfillmentType === 'delivery' ? 'Cash/UPI on Delivery' : 'Pay at Shop'}
              </span>
            </div>
          </div>

          {/* Cancel Order Action (if still pending/accepted) */}
          {(order.status === 'pending' || order.status === 'accepted') && !showCancelPrompt && (
            <button
              onClick={() => setShowCancelPrompt(true)}
              className="w-full py-2.5 text-xs text-rose-600 hover:text-rose-800 hover:bg-rose-50 font-bold rounded-xl border border-rose-200 transition-colors cursor-pointer"
            >
              Cancel Order
            </button>
          )}

          {showCancelPrompt && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 space-y-2 text-xs">
              <p className="font-extrabold text-rose-900">Are you sure you want to cancel this order?</p>
              <input
                type="text"
                placeholder="Reason for cancellation (optional)"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-rose-300 bg-white text-xs"
              />
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => setShowCancelPrompt(false)}
                  className="flex-1 py-1.5 rounded-lg border border-slate-300 bg-white font-bold text-slate-700 cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={handleCancelOrder}
                  disabled={isCancelling}
                  className="flex-1 py-1.5 rounded-lg bg-rose-600 text-white font-bold hover:bg-rose-700 cursor-pointer disabled:opacity-50"
                >
                  {isCancelling ? 'Cancelling...' : 'Confirm Cancel'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
