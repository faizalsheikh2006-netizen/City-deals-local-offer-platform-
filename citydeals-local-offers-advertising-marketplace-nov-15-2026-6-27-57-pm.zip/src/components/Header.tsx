import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../context/AppContext';
import {
  MapPin,
  Tag,
  Store,
  ShieldCheck,
  ChevronDown,
  Sparkles,
  Compass,
  Menu,
  MoreVertical,
  X,
  LogIn,
  LogOut,
  UserPlus,
  Share2,
  Gift,
  Download,
  ChevronRight,
  ExternalLink,
  ShoppingBag,
  Bookmark,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallPrompt';

export const Header: React.FC = () => {
  const {
    role,
    effectiveRole,
    adminPreviewMode,
    setAdminPreviewMode,
    user,
    isAuthenticated,
    logout,
    switchRole,
    selectedCity,
    selectedDistrict,
    selectedLocality,
    openModal,
    activeView,
    setActiveView,
    shareCityDeals,
    isInstallable,
    promptInstall,
    cart,
    cartCount,
    savedOfferIds,
    isOffline,
  } = useApp();

  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Prevent background scrolling and handle Escape key when mobile side menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          setIsMobileMenuOpen(false);
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    } else {
      document.body.style.overflow = '';
    }
  }, [isMobileMenuOpen]);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 backdrop-blur-md bg-white/95 shadow-xs">
      {/* Top Context Announcement Micro-Bar */}
      <div className="bg-slate-950 text-white text-[11px] px-3 sm:px-6 py-1.5 flex items-center justify-between border-b border-slate-800/80">
        <div className="flex items-center gap-2 truncate">
          <span className="inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded text-[10px] border border-emerald-400/30 shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            ACTIVE MARKETPLACE
          </span>
          <span className="text-slate-300 truncate">
            Launch markets: <strong className="text-white">Dibrugarh & Tinsukia, Assam</strong>
            <span className="hidden sm:inline"> • In-store local offer discovery</span>
          </span>
        </div>

        {/* Quick links on desktop micro-bar */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <button
            onClick={() => openModal('info-rates')}
            className="text-slate-300 hover:text-white transition-colors underline decoration-dotted cursor-pointer"
          >
            Advertising Rates
          </button>
          <span className="text-slate-700">|</span>
          <button
            onClick={() => openModal('info-about')}
            className="text-slate-300 hover:text-white transition-colors underline decoration-dotted cursor-pointer"
          >
            About Marketplace
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-2 sm:gap-4">
          {/* LEFT: Brand Logo & City Selector */}
          <div className="flex items-center gap-2 sm:gap-4 min-w-0">
            <button
              onClick={() => {
                setActiveView('browse');
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-2 group text-left cursor-pointer shrink-0"
            >
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-blue-700 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-blue-500/25 group-hover:scale-105 transition-transform shrink-0">
                <Tag className="w-4 h-4 sm:w-5 sm:h-5 -rotate-45" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-base sm:text-xl font-extrabold tracking-tight text-slate-900 leading-tight">
                    City<span className="text-blue-600">Deals</span>
                  </span>
                  <span className="hidden md:inline-flex items-center text-[10px] font-bold bg-amber-100 text-amber-900 px-1.5 py-0.2 rounded border border-amber-200 uppercase">
                    {selectedDistrict || selectedCity}
                  </span>
                </div>
                <p className="text-[11px] text-blue-600 font-semibold -mt-0.5 hidden sm:block">
                  Discover Local. Save Smart.
                </p>
              </div>
            </button>

            {/* Location Selector Button (shown on tablet/desktop, in drawer on mobile) */}
            <button
              onClick={() => openModal('city-selector')}
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold transition-colors cursor-pointer shrink-0"
              title="Change District or Locality"
            >
              <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span className="truncate max-w-[120px] lg:max-w-none">
                {selectedLocality && selectedLocality !== 'all' ? `${selectedLocality}, ${selectedDistrict}` : selectedDistrict}
              </span>
              <span className="hidden lg:inline-block text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded font-semibold">Assam</span>
              <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
            </button>
          </div>

          {/* DESKTOP CENTER: Primary Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-1.5">
            <button
              onClick={() => setActiveView('browse')}
              className={`px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                activeView === 'browse'
                  ? 'bg-blue-50 text-blue-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              Browse Shop Offers
            </button>

            <button
              onClick={() => setActiveView('shopping')}
              className={`px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 cursor-pointer relative ${
                activeView === 'shopping'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Shopping</span>
              <span
                className={`text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase tracking-wider ${
                  activeView === 'shopping' ? 'bg-white text-blue-900' : 'bg-amber-400 text-slate-950'
                }`}
              >
                New
              </span>
            </button>

            {(effectiveRole === 'merchant' || effectiveRole === 'admin') && (
              <button
                onClick={() => setActiveView('merchant')}
                className={`px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  activeView === 'merchant'
                    ? 'bg-blue-50 text-blue-700 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
                }`}
              >
                <Store className="w-4 h-4 text-blue-600" />
                <span>Merchant Portal</span>
              </button>
            )}
          </nav>

          {/* DESKTOP RIGHT: Organized Action Group */}
          <div className="hidden md:flex items-center gap-2 shrink-0">
            {/* Install PWA Button for Android & iPhone */}
            <PWAInstallButton />

            {/* Single Desktop Suggest Deal Button */}
            <button
              onClick={() => openModal('suggest-deal')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200/80 text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title="Suggest an in-store deal or discount found in Dibrugarh"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>+ Suggest Deal</span>
            </button>

            {/* SINGLE Desktop Share Button (Strictly only one across visible nav) */}
            <button
              onClick={() => shareCityDeals()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-blue-200 bg-blue-50/70 hover:bg-blue-100 text-blue-700 text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title="Share CityDeals with friends and shoppers"
            >
              <Share2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Share</span>
            </button>

            {/* Offline Status Badge */}
            {isOffline && (
              <span
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-900 text-amber-300 text-[11px] font-bold border border-slate-700 shadow-2xs"
                title="Working in offline mode. Bookmarked deals loaded from IndexedDB."
              >
                <WifiOff className="w-3 h-3 text-amber-400" />
                <span>Offline</span>
              </span>
            )}

            {/* Desktop Saved Deals Shortcut */}
            <button
              onClick={() => {
                setActiveView('browse');
                // Scroll to deals or trigger saved view
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title="View bookmarked deals (stored in IndexedDB & synced with Firestore)"
            >
              <Bookmark className={`w-3.5 h-3.5 ${savedOfferIds.length > 0 ? 'text-amber-500 fill-amber-500' : 'text-slate-400'}`} />
              <span className="hidden xl:inline">Saved</span>
              {savedOfferIds.length > 0 && (
                <span className="bg-amber-100 text-amber-900 border border-amber-200 text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                  {savedOfferIds.length}
                </span>
              )}
            </button>

            {/* Desktop Cart Button */}
            <button
              onClick={() => openModal('cart')}
              className="relative inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title="Shopping Cart"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-blue-600" />
              <span>Cart</span>
              {cartCount > 0 && (
                <span className="bg-blue-600 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Desktop Auth Section */}
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 shadow-2xs transition-all cursor-pointer"
                  title="View account session details"
                >
                  <div
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      effectiveRole === 'admin'
                        ? 'bg-purple-600'
                        : effectiveRole === 'merchant'
                        ? 'bg-blue-600'
                        : 'bg-emerald-500'
                    }`}
                  />
                  <span className="font-bold text-slate-900 max-w-[110px] truncate">{user.name}</span>
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase shrink-0 ${
                      effectiveRole === 'admin'
                        ? 'bg-purple-100 text-purple-800'
                        : effectiveRole === 'merchant'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {user.role === 'admin' && adminPreviewMode !== 'admin'
                      ? `${adminPreviewMode === 'merchant' ? 'Merchant' : 'Public'} (Preview)`
                      : role}
                  </span>
                  <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
                </button>

                {isRoleDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white shadow-xl border border-slate-200 p-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="px-2 py-2 border-b border-slate-100 mb-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600">Authenticated Session</span>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded capitalize ${
                            effectiveRole === 'admin'
                              ? 'bg-purple-100 text-purple-800'
                              : effectiveRole === 'merchant'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {user.role === 'admin' && adminPreviewMode !== 'admin'
                            ? `${adminPreviewMode === 'merchant' ? 'Merchant' : 'Public'} (Preview)`
                            : role}
                        </span>
                      </div>
                      <p className="text-sm font-bold text-slate-900 mt-1 truncate">{user.name}</p>
                      <p className="text-xs text-slate-500 font-mono truncate">{user.email}</p>
                      {user.referralCode && (
                        <div className="mt-1.5 flex items-center justify-between bg-blue-50/70 px-2 py-1 rounded border border-blue-100">
                          <span className="text-[10px] text-blue-700 font-semibold">Your Referral Code:</span>
                          <span className="text-[11px] font-mono font-bold text-blue-900 tracking-wider">{user.referralCode}</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1">
                      <button
                        onClick={() => {
                          openModal('referrals');
                          setIsRoleDropdownOpen(false);
                        }}
                        className="w-full text-left p-2 rounded-lg hover:bg-blue-50 text-blue-950 flex items-center justify-between text-xs font-bold cursor-pointer transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <Gift className="w-4 h-4 text-blue-600" />
                          <span>Referrals & Rewards</span>
                        </div>
                        {user.referralCount !== undefined && (
                          <span className="bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                            {user.referralCount}
                          </span>
                        )}
                      </button>

                      {(effectiveRole === 'merchant') && (
                        <>
                          <button
                            onClick={() => {
                              setActiveView('merchant');
                              setIsRoleDropdownOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-slate-50 flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer"
                          >
                            <Store className="w-4 h-4 text-blue-600" />
                            <span>Merchant Dashboard</span>
                          </button>
                          <button
                            onClick={() => {
                              openModal('post-offer');
                              setIsRoleDropdownOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-slate-50 flex items-center gap-2 text-xs font-semibold text-slate-800 cursor-pointer"
                          >
                            <Tag className="w-4 h-4 text-blue-600" />
                            <span>Submit New In-Store Offer</span>
                          </button>
                        </>
                      )}

                      {effectiveRole === 'admin' && (
                        <button
                          onClick={() => {
                            setActiveView('admin');
                            setIsRoleDropdownOpen(false);
                          }}
                          className="w-full text-left p-2 rounded-lg bg-amber-50 hover:bg-amber-100 flex items-center gap-2 text-xs font-bold text-amber-900 border border-amber-200 cursor-pointer transition-colors"
                        >
                          <ShieldCheck className="w-4 h-4 text-amber-600" />
                          <span>Admin Control Centre</span>
                        </button>
                      )}

                      {user.role === 'admin' && adminPreviewMode !== 'admin' && (
                        <button
                          onClick={() => {
                            setAdminPreviewMode('admin');
                            setActiveView('admin');
                            setIsRoleDropdownOpen(false);
                          }}
                          className="w-full text-left p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white flex items-center gap-2 text-xs font-bold cursor-pointer transition-colors"
                        >
                          <ShieldCheck className="w-4 h-4 text-amber-400" />
                          <span>Exit Preview & Return to Admin</span>
                        </button>
                      )}
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-end px-1">
                      <button
                        onClick={async () => {
                          setIsRoleDropdownOpen(false);
                          await logout();
                        }}
                        className="text-xs text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1 cursor-pointer py-1"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => openModal('auth', { tab: 'login' })}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5 text-blue-600" />
                  <span>Sign In</span>
                </button>
                <button
                  onClick={() => openModal('auth', { tab: 'register' })}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-white shadow-2xs transition-colors cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5 text-amber-400" />
                  <span>Register</span>
                </button>
              </div>
            )}
          </div>

          {/* MOBILE RIGHT: CART + 3-DOT (⋮) SIDE MENU BUTTON */}
          <div className="md:hidden flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => openModal('cart')}
              className="relative w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 flex items-center justify-center transition-colors cursor-pointer shadow-2xs"
              aria-label="Shopping Cart"
              title="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5 text-blue-600" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-[9px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center border-2 border-white">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 flex items-center justify-center transition-colors cursor-pointer shadow-2xs"
              aria-label="3-dot side menu"
              aria-expanded={isMobileMenuOpen}
              title="Menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 text-slate-900" />
              ) : (
                <MoreVertical className="w-5 h-5 text-slate-900" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 3-DOT (⋮) MOBILE SLIDE-OUT DRAWER PORTALED DIRECTLY TO BODY (Escapes sticky header clipping & backdrop-filter) */}
      {isMobileMenuOpen && typeof document !== 'undefined' &&
        createPortal(
          <div className="md:hidden fixed inset-0 z-[9999] isolate overflow-hidden">
            {/* Backdrop Blur Overlay */}
            <div
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
              onClick={() => setIsMobileMenuOpen(false)}
              aria-hidden="true"
            />

            {/* Slide-out Drawer Panel */}
            <aside
              className="fixed top-0 right-0 bottom-0 w-[86vw] sm:w-80 max-w-sm h-full h-[100dvh] max-h-[100dvh] bg-white shadow-2xl flex flex-col z-[10000] border-l border-slate-200 animate-in slide-in-from-right duration-300 focus:outline-none"
              role="dialog"
              aria-modal="true"
              aria-label="CityDeals Side Menu"
            >
              {/* Pinned Top Header (shrink-0) */}
              <div className="shrink-0 p-4 bg-gradient-to-r from-slate-950 to-blue-950 text-white flex items-center justify-between shadow-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shrink-0">
                    <Tag className="w-4 h-4 -rotate-45" />
                  </div>
                  <div>
                    <p className="font-extrabold text-base tracking-tight leading-tight">
                      City<span className="text-blue-400">Deals</span>
                    </p>
                    <p className="text-[10px] text-blue-200 font-medium">Discover Local. Save Smart.</p>
                  </div>
                </div>

                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-colors"
                  aria-label="Close menu"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Scrollable Drawer Body (flex-1 min-h-0 overflow-y-auto overscroll-contain) */}
              <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain">
                {/* User Profile / Authentication Section inside Drawer */}
                <div className="p-4 border-b border-slate-100 bg-slate-50/70">
                  {isAuthenticated ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 min-w-0">
                          <div
                            className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                              effectiveRole === 'admin' ? 'bg-purple-600' : effectiveRole === 'merchant' ? 'bg-blue-600' : 'bg-emerald-500'
                            }`}
                          />
                          <span className="font-bold text-slate-900 text-sm truncate">{user.name}</span>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                            effectiveRole === 'admin'
                              ? 'bg-purple-100 text-purple-800'
                              : effectiveRole === 'merchant'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {user.role === 'admin' && adminPreviewMode !== 'admin'
                            ? `${adminPreviewMode === 'merchant' ? 'Merchant' : 'Public'} (Preview)`
                            : role}
                        </span>
                      </div>

                      <p className="text-xs text-slate-500 font-mono truncate">{user.email}</p>

                      {user.referralCode && (
                        <div className="flex items-center justify-between bg-white px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs">
                          <span className="text-slate-500 font-medium">Referral Code:</span>
                          <span className="font-mono font-bold text-blue-700">{user.referralCode}</span>
                        </div>
                      )}

                      <div className="pt-1 flex items-center justify-between">
                        <button
                          onClick={() => {
                            openModal('referrals');
                            setIsMobileMenuOpen(false);
                          }}
                          className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                        >
                          <Gift className="w-3.5 h-3.5" />
                          <span>Referrals ({user.referralCount || 0})</span>
                        </button>

                        <button
                          onClick={async () => {
                            setIsMobileMenuOpen(false);
                            await logout();
                          }}
                          className="text-xs font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1 cursor-pointer"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-xs text-slate-600 mb-2 font-medium">
                        Sign in to submit shop offers, bookmark deals, and unlock referral rewards.
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => {
                            openModal('auth', { tab: 'login' });
                            setIsMobileMenuOpen(false);
                          }}
                          className="w-full py-2 px-3 rounded-xl border border-blue-600 text-blue-700 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-blue-50 transition-colors cursor-pointer"
                        >
                          <LogIn className="w-3.5 h-3.5 text-blue-600" />
                          <span>Sign In</span>
                        </button>
                        <button
                          onClick={() => {
                            openModal('auth', { tab: 'register' });
                            setIsMobileMenuOpen(false);
                          }}
                          className="w-full py-2 px-3 rounded-xl bg-slate-900 text-white font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-slate-800 transition-colors shadow-xs cursor-pointer"
                        >
                          <UserPlus className="w-3.5 h-3.5 text-amber-400" />
                          <span>Register</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Primary Mobile Action Buttons */}
                <div className="p-4 space-y-2 border-b border-slate-100">
                  <button
                    onClick={() => {
                      openModal('suggest-deal');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm hover:from-blue-700 hover:to-indigo-700 transition-all cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>+ Suggest a Local Deal</span>
                  </button>

                  {/* SINGLE Share Button in Mobile Navigation */}
                  <button
                    onClick={() => {
                      shareCityDeals();
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 px-3 rounded-xl border border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-blue-600" />
                    <span>Share CityDeals</span>
                  </button>

                  <div onClick={() => setIsMobileMenuOpen(false)}>
                    <PWAInstallButton variant="full" />
                  </div>
                </div>

                {/* Marketplace Sections Navigation */}
                <div className="p-4 space-y-1 border-b border-slate-100">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600 block px-2 mb-1">
                    Marketplace Directory
                  </span>

                  <button
                    onClick={() => {
                      setActiveView('browse');
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      activeView === 'browse' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Compass className="w-4 h-4 text-blue-600" />
                      <span>Browse Shop Offers</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => {
                      setActiveView('shopping');
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      activeView === 'shopping' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <ShoppingBag className={`w-4 h-4 ${activeView === 'shopping' ? 'text-white' : 'text-blue-600'}`} />
                      <span>Shopping Marketplace</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase ${
                          activeView === 'shopping' ? 'bg-white text-blue-900' : 'bg-amber-400 text-slate-950'
                        }`}
                      >
                        New
                      </span>
                      <ChevronRight className={`w-3.5 h-3.5 ${activeView === 'shopping' ? 'text-blue-200' : 'text-slate-400'}`} />
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setActiveView('browse');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <Bookmark className={`w-4 h-4 ${savedOfferIds.length > 0 ? 'text-amber-500 fill-amber-500' : 'text-slate-400'}`} />
                      <span>Saved Bookmarked Offers</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {isOffline && (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-900 text-amber-300">
                          Offline
                        </span>
                      )}
                      <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-1.5 py-0.2 rounded-full">
                        {savedOfferIds.length}
                      </span>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      openModal('cart');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <ShoppingBag className="w-4 h-4 text-emerald-600" />
                      <span>My Cart</span>
                    </div>
                    {cartCount > 0 ? (
                      <span className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {cartCount} {cartCount === 1 ? 'item' : 'items'}
                      </span>
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </button>

                  {(effectiveRole === 'merchant' || effectiveRole === 'admin') && (
                    <button
                      onClick={() => {
                        setActiveView('merchant');
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                        activeView === 'merchant' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Store className="w-4 h-4 text-blue-600" />
                        <span>Merchant Portal (Post Deals)</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>
                  )}

                  {effectiveRole === 'admin' && (
                    <button
                      onClick={() => {
                        setActiveView('admin');
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <ShieldCheck className="w-4 h-4 text-amber-600" />
                        <span>Admin Control Centre</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-amber-600" />
                    </button>
                  )}

                  {user.role === 'admin' && adminPreviewMode !== 'admin' && (
                    <button
                      onClick={() => {
                        setAdminPreviewMode('admin');
                        setActiveView('admin');
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold bg-slate-900 text-white transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <ShieldCheck className="w-4 h-4 text-amber-400" />
                        <span>Return to Admin Dashboard</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>
                  )}

                  <button
                    onClick={() => {
                      openModal('city-selector');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <MapPin className="w-4 h-4 text-blue-600" />
                      <span>Location: {selectedLocality && selectedLocality !== 'all' ? `${selectedLocality}, ${selectedDistrict}` : selectedDistrict}</span>
                    </div>
                    <span className="text-[11px] text-blue-600 font-semibold">Change</span>
                  </button>
                </div>

                {/* Additional Information Links */}
                <div className="p-4 space-y-1 bg-slate-50/50">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600 block px-2 mb-1">
                    Information & Policies
                  </span>

                  <button
                    onClick={() => {
                      openModal('info-rates');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full text-left font-semibold text-xs text-slate-700 hover:text-blue-600 flex items-center justify-between py-2 px-2 rounded-lg hover:bg-white transition-colors cursor-pointer"
                  >
                    <span>Advertising Rate Card</span>
                    <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold">Boost ₹199</span>
                  </button>

                  <button
                    onClick={() => {
                      openModal('info-about');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full text-left font-semibold text-xs text-slate-700 hover:text-blue-600 py-2 px-2 rounded-lg hover:bg-white transition-colors cursor-pointer"
                  >
                    About CityDeals Marketplace
                  </button>

                  <button
                    onClick={() => {
                      openModal('info-privacy');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full text-left font-semibold text-xs text-slate-700 hover:text-blue-600 py-2 px-2 rounded-lg hover:bg-white transition-colors cursor-pointer"
                  >
                    Privacy & Truth in Advertising
                  </button>
                </div>
              </div>

              {/* Pinned Bottom Information (shrink-0) */}
              <div className="shrink-0 p-3.5 border-t border-slate-200 bg-slate-50 text-[10px] text-slate-600 flex items-center justify-between">
                <span className="font-medium text-slate-700">CityDeals v2.4 • Dibrugarh</span>
                <span className="text-slate-600">Hyperlocal Commerce</span>
              </div>
            </aside>
          </div>,
          document.body
        )}
    </header>
  );
};
