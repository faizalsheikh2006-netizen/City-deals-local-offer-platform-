import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { ReferralCampaignConfig } from '../types/index';
import {
  X,
  Gift,
  Share2,
  Copy,
  Check,
  MessageCircle,
  Users,
  ShieldCheck,
  AlertCircle,
  Sparkles,
  Award,
  ChevronRight,
  Send,
  Info,
} from 'lucide-react';

interface ReferralModalProps {
  onClose: () => void;
}

export const ReferralModal: React.FC<ReferralModalProps> = ({ onClose }) => {
  const { user, isAuthenticated, openModal, showToast } = useApp();
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [referralData, setReferralData] = useState<{
    referralCode: string;
    referralCount: number;
    pendingCount: number;
    campaignConfig: ReferralCampaignConfig;
    referrals: Array<{
      id: string;
      referredUserName: string;
      referredUserRole: string;
      status: string;
      createdAt: string;
    }>;
  } | null>(null);

  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const refCode = referralData?.referralCode || user?.referralCode || '';
  const referralLink = `${origin}/?ref=${encodeURIComponent(refCode)}`;
  const shareMessage = `Discover local offers and discounts near you with CityDeals! Use my invitation code "${refCode}" or join here: ${referralLink}`;

  useEffect(() => {
    async function loadReferrals() {
      if (!isAuthenticated) {
        setIsLoading(false);
        return;
      }
      try {
        setIsLoading(true);
        const data = await api.getMyReferrals();
        setReferralData(data);
      } catch (err: any) {
        console.error('Failed to load referral details:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadReferrals();
  }, [isAuthenticated]);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(refCode);
      setCopiedCode(true);
      showToast('Referral code copied!', 'success');
      setTimeout(() => setCopiedCode(false), 2500);
    } catch {
      showToast('Copied referral code', 'info');
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopiedLink(true);
      showToast('Referral link copied to clipboard!', 'success');
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      showToast('Copied referral link', 'info');
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join CityDeals - Local Shop Offers',
          text: `Discover local offers and discounts near you with CityDeals! Use my invitation code "${refCode}":`,
          url: referralLink,
        });
        showToast('Shared invitation!', 'success');
      } catch (err: any) {
        if (err.name !== 'AbortError') console.warn(err);
      }
    } else {
      handleCopyLink();
    }
  };

  const handleWhatsApp = () => {
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareMessage)}`;
    window.open(waUrl, '_blank');
  };

  const handleTelegram = () => {
    const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(`Discover local offers on CityDeals! Use invitation code ${refCode}`)}`;
    window.open(tgUrl, '_blank');
  };

  // If user is not logged in, prompt them to sign in or register to get their personal code
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
        <div className="relative bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden my-6 p-6 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 text-white flex items-center justify-center mx-auto shadow-md">
            <Gift className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-extrabold text-slate-900">CityDeals Community Referrals</h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              Sign in or create your free account to unlock your personal referral link, invite neighbors & merchants, and track your referral metrics.
            </p>
          </div>
          <div className="pt-2 flex flex-col sm:flex-row gap-2.5 justify-center">
            <button
              onClick={() => {
                onClose();
                openModal('auth', { tab: 'login' });
              }}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm cursor-pointer"
            >
              Sign In to Your Account
            </button>
            <button
              onClick={() => {
                onClose();
                openModal('auth', { tab: 'register', defaultRole: 'public' });
              }}
              className="px-5 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs cursor-pointer"
            >
              Register Free
            </button>
          </div>
        </div>
      </div>
    );
  }

  const verifiedCount = referralData?.referralCount || 0;
  const pendingCount = referralData?.pendingCount || 0;
  const config = referralData?.campaignConfig;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-950 via-purple-950 to-indigo-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-600 text-white shadow-md">
              <Gift className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold">Referral Dashboard</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-500/30 text-purple-200 border border-purple-400/30">
                  {user.role === 'merchant' ? 'Merchant Partner' : 'Citizen Ambassador'}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Share CityDeals Dibrugarh & grow our local shop community
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Stat Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3.5 bg-purple-50/70 border border-purple-200 rounded-2xl text-center">
              <span className="text-[11px] font-bold text-purple-900 block">Verified Referrals</span>
              <span className="text-2xl font-black text-purple-700 mt-0.5 block">{verifiedCount}</span>
              <span className="text-[10px] text-purple-600 font-medium">Active accounts</span>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-center">
              <span className="text-[11px] font-bold text-slate-700 block">Pending Review</span>
              <span className="text-2xl font-black text-slate-700 mt-0.5 block">{pendingCount}</span>
              <span className="text-[10px] text-slate-500 font-medium">Awaiting verification</span>
            </div>

            <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-2xl text-center">
              <span className="text-[11px] font-bold text-amber-900 block">Community Badge</span>
              <div className="flex items-center justify-center gap-1 mt-1 text-amber-700 font-extrabold text-xs">
                <Award className="w-4 h-4 text-amber-500" />
                <span>{verifiedCount >= 5 ? 'Master Ambassador' : verifiedCount >= 1 ? 'Active Contributor' : 'Early Pioneer'}</span>
              </div>
              <span className="text-[10px] text-amber-600 font-medium">Platform status</span>
            </div>
          </div>

          {/* Personal Referral Link & Code Box */}
          <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl p-5 space-y-4 shadow-lg border border-indigo-800/40">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-purple-300">
                  Your Personal Referral Code
                </span>
              </div>
              <span className="text-[10px] bg-purple-500/30 text-purple-200 font-mono px-2 py-0.5 rounded border border-purple-400/30">
                Authoritative Server ID
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div className="flex-1 bg-white/10 border border-white/20 rounded-xl px-4 py-2.5 font-mono text-base font-extrabold tracking-widest text-white text-center sm:text-left select-all">
                {refCode || 'GENERATING...'}
              </div>
              <button
                onClick={handleCopyCode}
                className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all shrink-0"
              >
                {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedCode ? 'Code Copied!' : 'Copy Code'}</span>
              </button>
            </div>

            <div className="pt-2 border-t border-white/10 space-y-1.5">
              <label className="text-xs font-bold text-slate-300 block">Personal Shareable Link</label>
              <div className="flex items-center gap-2 bg-white/10 border border-white/20 rounded-xl p-1.5">
                <input
                  type="text"
                  readOnly
                  value={referralLink}
                  className="flex-1 bg-transparent border-none outline-none text-xs text-white font-mono px-2 select-all"
                />
                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white font-bold text-xs cursor-pointer transition-all shrink-0"
                >
                  {copiedLink ? 'Copied!' : 'Copy Link'}
                </button>
              </div>
            </div>
          </div>

          {/* Sharing Buttons */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 block">Quick Share via Mobile Apps</span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                onClick={handleNativeShare}
                className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
              >
                <Share2 className="w-4 h-4" />
                <span>Device Share Sheet</span>
              </button>

              <button
                onClick={handleWhatsApp}
                className="py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>

              <button
                onClick={handleTelegram}
                className="py-2.5 px-3 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
              >
                <Send className="w-4 h-4" />
                <span>Telegram</span>
              </button>
            </div>
          </div>

          {/* Transparent Reward Policy Notice (Requirement 4) */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 text-xs">
            <div className="flex items-center gap-2 font-bold text-slate-900">
              <Info className="w-4 h-4 text-blue-600 shrink-0" />
              <span>What Counts as a Successful Referral?</span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              A referral is counted when a real person (shopper or local shopkeeper) registers a genuine account on CityDeals through your link.
              <strong className="text-slate-800 font-semibold"> Link clicks alone do not count as referrals.</strong>
            </p>
            <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 space-y-1">
              <p>
                <strong className="text-slate-700 font-semibold">Rewards Policy:</strong> {config?.rewardDescription || 'Early Pioneer Community Badge and Priority Local Partner status. No cash rewards or financial payouts are promised or distributed during the early access phase.'}
              </p>
              <p>
                <strong className="text-slate-700 font-semibold">Anti-Abuse Verification:</strong> Self-referrals, duplicate email registrations, and simulated signups are automatically flagged and rejected by server-side verification.
              </p>
            </div>
          </div>

          {/* List of Successful Referrals */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800">Your Referred Members ({referralData?.referrals?.length || 0})</span>
              <span className="text-[11px] text-slate-500">Names masked for privacy</span>
            </div>

            {referralData?.referrals && referralData.referrals.length > 0 ? (
              <div className="space-y-2">
                {referralData.referrals.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs">
                        {item.referredUserName[0]}
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 block">{item.referredUserName}</span>
                        <span className="text-[10px] text-slate-500 capitalize">{item.referredUserRole} Account</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-400">
                        {new Date(item.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                          item.status === 'verified'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.status === 'flagged'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {item.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-1">
                <Users className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="text-xs font-semibold text-slate-700">No referrals yet</p>
                <p className="text-[11px] text-slate-500">
                  Share your link with friends, family, and local store owners to start building your community ambassador tier.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
