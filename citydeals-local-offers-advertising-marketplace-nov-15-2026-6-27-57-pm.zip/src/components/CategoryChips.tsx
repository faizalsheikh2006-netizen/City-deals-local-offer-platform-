import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Utensils,
  Shirt,
  ShoppingBag,
  Smartphone,
  Sparkles,
  Wrench,
  Home,
  Store,
  LayoutGrid,
} from 'lucide-react';

interface CategoryChipsProps {
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
  categoryCounts?: Record<string, number>;
}

export const CategoryChips: React.FC<CategoryChipsProps> = ({
  selectedCategory,
  onSelectCategory,
  categoryCounts = {},
}) => {
  const { categories } = useApp();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Utensils':
        return Utensils;
      case 'Shirt':
        return Shirt;
      case 'ShoppingBag':
        return ShoppingBag;
      case 'Smartphone':
        return Smartphone;
      case 'Sparkles':
        return Sparkles;
      case 'Home':
        return Home;
      case 'Wrench':
        return Wrench;
      default:
        return Store;
    }
  };

  const totalAllCount = Object.values(categoryCounts).reduce((a, b) => a + b, 0);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3 px-1">
        <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
          <Store className="w-4 h-4 text-blue-600" />
          <span>Shop Categories</span>
        </h2>
        {selectedCategory !== 'all' && (
          <button
            onClick={() => onSelectCategory('all')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-800"
          >
            Show All Shops
          </button>
        )}
      </div>

      {/* Horizontal scroll on mobile */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar scroll-smooth">
        {/* All Shops / All Offers chip */}
        <button
          onClick={() => onSelectCategory('all')}
          className={`shrink-0 flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
            selectedCategory === 'all'
              ? 'bg-slate-900 text-white shadow-md shadow-slate-900/20 ring-2 ring-slate-900/20'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <LayoutGrid className="w-3.5 h-3.5" />
          <span>All Categories</span>
          {totalAllCount > 0 && (
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                selectedCategory === 'all' ? 'bg-slate-700 text-slate-200' : 'bg-slate-100 text-slate-600'
              }`}
            >
              {totalAllCount}
            </span>
          )}
        </button>

        {/* Individual category chips */}
        {categories.map((cat) => {
          const Icon = getIcon(cat.iconName);
          const isSelected = selectedCategory === cat.slug;
          const count = categoryCounts[cat.slug] || 0;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(isSelected ? 'all' : cat.slug)}
              className={`shrink-0 flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/25 ring-2 ring-blue-600/20'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-blue-600'}`} />
              <span>{cat.name}</span>
              {count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isSelected ? 'bg-blue-700 text-blue-100' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
