import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Offer, Business } from '../types';
import { formatDistance, DISTRICT_CENTERS } from '../utils/geo';
import { MapPin, Navigation, Tag, Store, ExternalLink } from 'lucide-react';

interface InteractiveMapProps {
  offers: Offer[];
  shops: Array<{ business: Business; activeOffers: Offer[] }>;
  userLocation: { lat: number; lng: number } | null;
  onSelectOffer: (offer: Offer) => void;
  onSelectShop?: (shop: Business) => void;
  radiusKm?: number | null;
  selectedCategory?: string;
  selectedDistrict?: string;
  selectedLocality?: string;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  offers,
  shops,
  userLocation,
  onSelectOffer,
  onSelectShop,
  radiusKm,
  selectedCategory,
  selectedDistrict = 'Dibrugarh',
  selectedLocality,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const userCircleRef = useRef<L.Circle | null>(null);

  const getDistrictCenter = () => {
    return DISTRICT_CENTERS[selectedDistrict] || DISTRICT_CENTERS['Dibrugarh'] || { lat: 27.4835, lng: 94.9112 };
  };

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const centerCoords = getDistrictCenter();
      const initialLat = userLocation?.lat || centerCoords.lat;
      const initialLng = userLocation?.lng || centerCoords.lng;

      const map = L.map(mapContainerRef.current, {
        center: [initialLat, initialLng],
        zoom: 13,
        zoomControl: false,
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      // Clean, modern CartoDB Positron / OSM style tiles
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://carto.com/">CARTO</a>, &copy; <a href="https://openstreetmap.org">OSM</a>',
        maxZoom: 19,
      }).addTo(map);

      const markersGroup = L.layerGroup().addTo(map);
      markersLayerRef.current = markersGroup;
      mapInstanceRef.current = map;
    }

    return () => {
      // Map cleanup on unmount
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update markers when offers, shops, or location change
  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersGroup = markersLayerRef.current;
    if (!map || !markersGroup) return;

    markersGroup.clearLayers();

    // 1. Plot User Location if available
    if (userLocation) {
      const userMarkerHtml = `
        <div class="relative flex items-center justify-center w-8 h-8">
          <div class="absolute w-8 h-8 rounded-full bg-blue-500/20 animate-ping"></div>
          <div class="relative w-4 h-4 bg-blue-600 rounded-full border-2 border-white shadow-lg ring-2 ring-blue-400"></div>
        </div>
      `;
      const userIcon = L.divIcon({
        html: userMarkerHtml,
        className: 'user-pulse-marker',
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const userMarker = L.marker([userLocation.lat, userLocation.lng], { icon: userIcon });
      userMarker.bindPopup(`
        <div class="p-1 font-sans text-xs">
          <p class="font-bold text-slate-900 flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-blue-600 inline-block"></span> Your Current Location
          </p>
          <p class="text-slate-500 mt-0.5">GPS Fixed • ${selectedDistrict || 'Assam'}</p>
        </div>
      `);
      markersGroup.addLayer(userMarker);

      // Draw radius circle if requested
      if (radiusKm) {
        if (userCircleRef.current) {
          map.removeLayer(userCircleRef.current);
        }
        const circle = L.circle([userLocation.lat, userLocation.lng], {
          radius: radiusKm * 1000,
          color: '#2563EB',
          weight: 1.5,
          opacity: 0.6,
          fillColor: '#3B82F6',
          fillOpacity: 0.08,
          dashArray: '4, 6',
        }).addTo(map);
        userCircleRef.current = circle;
      }
    } else if (userCircleRef.current) {
      map.removeLayer(userCircleRef.current);
      userCircleRef.current = null;
    }

    // 2. Plot Shops and Offers
    const plottedCoords = new Set<string>();

    offers.forEach((offer) => {
      const lat = offer.latitude;
      const lng = offer.longitude;
      if (!lat || !lng) return;

      // Small jitter if exact overlapping coordinate
      const coordKey = `${lat.toFixed(4)},${lng.toFixed(4)}`;
      let finalLat = lat;
      let finalLng = lng;
      if (plottedCoords.has(coordKey)) {
        finalLat += (Math.random() - 0.5) * 0.0006;
        finalLng += (Math.random() - 0.5) * 0.0006;
      }
      plottedCoords.add(coordKey);

      const isSponsored = offer.isSponsored;
      const distBadge = offer.distanceKm !== undefined ? formatDistance(offer.distanceKm) : null;

      const markerHtml = `
        <div class="group cursor-pointer transform hover:scale-110 transition-transform">
          <div class="flex items-center gap-1 px-2 py-1 rounded-full text-[11px] font-bold text-white shadow-md border ${
            isSponsored
              ? 'bg-gradient-to-r from-amber-600 to-orange-500 border-amber-300 ring-2 ring-amber-400/50'
              : 'bg-gradient-to-r from-blue-700 to-indigo-800 border-blue-400'
          }">
            <span>${offer.discountValue || 'DEAL'}</span>
          </div>
          <div class="w-2 h-2 mx-auto -mt-0.5 bg-blue-700 transform rotate-45 border-r border-b border-blue-400"></div>
        </div>
      `;

      const customIcon = L.divIcon({
        html: markerHtml,
        className: 'citydeals-map-pin',
        iconSize: [80, 30],
        iconAnchor: [40, 28],
        popupAnchor: [0, -28],
      });

      const marker = L.marker([finalLat, finalLng], { icon: customIcon });

      const popupHtml = document.createElement('div');
      popupHtml.className = 'p-2 font-sans text-xs max-w-[240px]';
      popupHtml.innerHTML = `
        <div class="flex items-center justify-between gap-1 mb-1">
          <span class="inline-block px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 text-[10px] font-bold uppercase tracking-wider">
            ${offer.category.replace('-', ' ')}
          </span>
          ${distBadge ? `<span class="text-blue-700 font-bold text-[10px] bg-blue-50 px-1 py-0.5 rounded">📍 ${distBadge}</span>` : ''}
        </div>
        <h4 class="font-bold text-slate-900 text-sm leading-snug line-clamp-2">${offer.headline}</h4>
        <p class="text-slate-600 font-medium text-[11px] mt-1 flex items-center gap-1">
          <span class="text-slate-400">🏪</span> ${offer.shopName}
        </p>
        <p class="text-slate-400 text-[10px] mt-0.5">${offer.locality}, ${offer.district || offer.city || selectedDistrict || 'Assam'}</p>
        <div class="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between">
          <span class="text-rose-600 font-bold text-xs">${offer.discountValue}</span>
          <button id="view-offer-${offer.id}" class="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded text-[11px] transition-colors">
            View Deal →
          </button>
        </div>
      `;

      // Attach button click event
      const btn = popupHtml.querySelector(`#view-offer-${offer.id}`);
      if (btn) {
        btn.addEventListener('click', () => {
          onSelectOffer(offer);
        });
      }

      marker.bindPopup(popupHtml);
      markersGroup.addLayer(marker);
    });

    // Adjust map bounds if coordinates exist
    if (userLocation) {
      map.panTo([userLocation.lat, userLocation.lng]);
    }
  }, [offers, shops, userLocation, radiusKm, onSelectOffer, selectedDistrict]);

  // Recenter when selectedDistrict changes (if no GPS lock)
  useEffect(() => {
    if (!mapInstanceRef.current || userLocation) return;
    const centerCoords = getDistrictCenter();
    mapInstanceRef.current.setView([centerCoords.lat, centerCoords.lng], 13);
  }, [selectedDistrict]);

  return (
    <div className="relative w-full h-[520px] rounded-2xl overflow-hidden border border-slate-200/80 shadow-inner bg-slate-100">
      {/* Map container */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Floating Map Legend & Status Overlay */}
      <div className="absolute top-3 left-3 z-[400] flex flex-wrap items-center gap-2">
        <div className="bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-md border border-slate-200 text-xs text-slate-700 flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block animate-pulse"></span>
          <span className="font-semibold text-slate-900">{selectedDistrict || 'Assam'} Live Deals Map</span>
          <span className="text-slate-400">|</span>
          <span className="text-blue-700 font-bold">{offers.length} Active Deals</span>
        </div>

        {userLocation && (
          <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 shadow-sm">
            <Navigation className="w-3.5 h-3.5 text-emerald-600" />
            <span>GPS Active {radiusKm ? `• ${radiusKm}km radius` : ''}</span>
          </div>
        )}
      </div>

      {/* Floating Center on District Button */}
      <div className="absolute bottom-4 left-4 z-[400] flex flex-col gap-2">
        <button
          onClick={() => {
            if (mapInstanceRef.current) {
              if (userLocation) {
                mapInstanceRef.current.setView([userLocation.lat, userLocation.lng], 15);
              } else {
                const centerCoords = getDistrictCenter();
                mapInstanceRef.current.setView([centerCoords.lat, centerCoords.lng], 13);
              }
            }
          }}
          className="bg-white hover:bg-slate-50 text-slate-800 px-3 py-2 rounded-xl text-xs font-semibold shadow-lg border border-slate-200 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
        >
          <Navigation className="w-3.5 h-3.5 text-blue-600" />
          <span>{userLocation ? 'My Location' : `${selectedDistrict} Center`}</span>
        </button>
      </div>

      {/* Quick locality guide */}
      <div className="hidden sm:flex absolute bottom-4 right-14 z-[400] bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-200 text-[11px] text-slate-500 shadow-sm items-center gap-2">
        {selectedDistrict === 'Tinsukia' ? (
          <>
            <span>📍 Tinsukia Town</span>
            <span>•</span>
            <span>Doomdooma</span>
            <span>•</span>
            <span>Digboi</span>
            <span>•</span>
            <span>Makum</span>
          </>
        ) : (
          <>
            <span>📍 Dibrugarh Town</span>
            <span>•</span>
            <span>Chowkidinghee</span>
            <span>•</span>
            <span>Duliajan</span>
            <span>•</span>
            <span>Moran</span>
          </>
        )}
      </div>
    </div>
  );
};
