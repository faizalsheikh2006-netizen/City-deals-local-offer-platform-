import React from 'react';
import { ShopWithOffers, Offer } from '../types/index';
import {
  MapPin,
  Clock,
  Phone,
  MessageCircle,
  Navigation,
  Tag,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  ShoppingBag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatDistance } from '../utils/geo';
import { optimizeImageUrl } from '../utils/image';

interface ShopCardProps {
  shopData: ShopWithOffers;
  onSelectOffer: (offer: Offer) => void;
}

export const ShopCard: React.FC<ShopCardProps> = React.memo(({ shopData, onSelectOffer }) => {
  const { business, activeOffers } = shopData;
  const { setActiveView, setSelectedShopProfileId } = useApp();

  const handleDirections = (e: React.MouseEvent) => {
    e.stopPropagation();
    const destination = encodeURIComponent(`${business.name}, ${business.locality}, ${business.district || business.city}, Assam`);
    window.open(`https://www.google.com/maps/search/?api=1&query=${destination}`, '_blank');
  };

  const handleCall = (e: React.MouseEvent) => {
    e.stopPropagation();
    window.location.href = `tel:${business.phone}`;
  };

  const handleWhatsapp = (e: React.MouseEvent) => {
    e.stopPropagation();
    const wa = business.whatsapp || business.phone;
    const cleanWa = wa.replace(/[^0-9]/g, '');
    const msg = encodeURIComponent(
      `Hello! I found ${business.name} on CityDeals (${business.district || business.city}) and would like to inquire about your current in-store offers.`
    );
    window.open(`https://wa.me/${cleanWa}?text=${msg}`, '_blank');
  };

  const coverUrl = optimizeImageUrl(
    business.logoUrl || 'https://images.unsplash.com/photo-1556740738-b6a63e27c4df?auto=format&fit=crop&w=600&q=80',
    600,
    75
  );

  return (
    <div className="bg-white rounded-2xl border border-slate-200 hover:border-blue-300 shadow-xs hover:shadow-lg transition-shadow duration-200 overflow-hidden flex flex-col justify-between">
      <div>
        {/* Shop Cover Image */}
        <div className="relative h-44 w-full bg-slate-100 overflow-hidden">
          <img
            src={coverUrl}
            alt={business.name}
            width={600}
            height={176}
            className="w-full h-full object-cover"
            loading="lazy"
            decoding="async"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

          {/* Featured Shop Badge */}
          {business.isFeatured && (
            <div className="absolute top-3 left-3 bg-slate-900/90 text-amber-300 border border-amber-400/40 text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-md">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>FEATURED SHOP</span>
            </div>
          )}

          {/* Active Offers Count Pill & Distance */}
          <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
            <div className="bg-blue-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-md">
              <Tag className="w-3.5 h-3.5" />
              <span>
                {activeOffers.length} {activeOffers.length === 1 ? 'Active Offer' : 'Active Offers'}
              </span>
            </div>
            {business.distanceKm !== undefined && (
              <span className="bg-slate-900/90 text-white font-bold text-[10px] px-2 py-1 rounded-lg shadow-md flex items-center gap-1">
                <Navigation className="w-2.5 h-2.5 text-blue-400" />
                <span>{formatDistance(business.distanceKm)}</span>
              </span>
            )}
          </div>

          {/* Verified Badge - Genuine admin verification required */}
          {Boolean(business.isVerified || business.verifiedBadge || business.verified) && (
            <div className="absolute top-3 right-3 bg-white/95 backdrop-blur-xs text-emerald-800 text-[11px] font-black px-2 py-0.5 rounded-md flex items-center gap-1 shadow-xs border border-emerald-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Verified Shop</span>
            </div>
          )}
        </div>

        {/* Shop Information Body */}
        <div className="p-4 space-y-3">
          <div>
            <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block">
              {business.category.replace('-', ' ')}
            </span>
            <h3 className="text-base font-extrabold text-slate-900 mt-0.5">{business.name}</h3>
          </div>

          {/* Address & Landmark */}
          <div className="flex items-start gap-1.5 text-xs text-slate-600">
            <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">{business.fullAddress || business.address || `${business.locality}, ${business.district || business.city}`}</p>
              {business.landmark && (
                <p className="text-[11px] text-slate-600 mt-0.5">Near: {business.landmark}</p>
              )}
            </div>
          </div>

          {/* Hours */}
          {business.openingHours && (
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="font-medium text-slate-700">{business.openingHours}</span>
            </div>
          )}

          {/* Grouped In-Store Offers List under this Shop */}
          <div className="pt-2 border-t border-slate-100 space-y-2">
            <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
              Current In-Store Offers:
            </span>

            {activeOffers.length === 0 ? (
              <p className="text-xs text-slate-600 italic">No public offers running right now.</p>
            ) : (
              <div className="space-y-1.5">
                {activeOffers.map((offer) => (
                  <div
                    key={offer.id}
                    onClick={() => onSelectOffer(offer)}
                    className="p-2.5 rounded-xl bg-blue-50/50 hover:bg-blue-100/70 border border-blue-200/60 cursor-pointer transition-colors flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <span className="text-[10px] font-extrabold text-red-700 block uppercase">
                        {offer.discountValue}
                      </span>
                      <p className="text-xs font-bold text-slate-800 truncate">{offer.headline}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-blue-600 shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Shop Action Buttons */}
      <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleCall}
            className="p-2 rounded-xl bg-white border border-slate-200 hover:border-blue-500 text-slate-700 hover:text-blue-600 transition-colors shadow-2xs"
            aria-label={`Call ${business.name}`}
            title="Call Shop"
          >
            <Phone className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={handleWhatsapp}
            className="p-2 rounded-xl bg-white border border-slate-200 hover:border-emerald-500 text-emerald-700 transition-colors shadow-2xs"
            aria-label={`WhatsApp ${business.name}`}
            title="WhatsApp Shop"
          >
            <MessageCircle className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center gap-1.5 flex-1">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedShopProfileId(business.id);
              setActiveView('shopping');
            }}
            className="inline-flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-white border border-slate-200 hover:border-blue-500 text-slate-800 hover:text-blue-600 text-xs font-bold shadow-2xs transition-colors"
            title="Browse Shop Product Catalogue"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden sm:inline">Catalogue</span>
          </button>

          <button
            type="button"
            onClick={handleDirections}
            className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Directions</span>
          </button>
        </div>
      </div>
    </div>
  );
});
ShopCard.displayName = 'ShopCard';
