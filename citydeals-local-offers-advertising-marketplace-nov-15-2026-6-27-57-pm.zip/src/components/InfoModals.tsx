import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  MapPin,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Store,
  Info,
  Tag,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const InfoModals: React.FC = () => {
  const {
    modalType,
    closeModal,
    selectedCity,
    setSelectedCity,
    selectedDistrict,
    setSelectedDistrict,
    selectedLocality,
    setSelectedLocality,
    districts,
    getLocalitiesForDistrict,
    cities,
    promotionPackages,
    showToast,
  } = useApp();

  const [activeDistrictTab, setActiveDistrictTab] = useState<string>(selectedDistrict || 'Dibrugarh');

  useEffect(() => {
    if (selectedDistrict) {
      setActiveDistrictTab(selectedDistrict);
    }
  }, [selectedDistrict]);

  if (!modalType || !['info-about', 'info-rates', 'info-privacy', 'city-selector'].includes(modalType)) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="relative bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-4 right-4 z-10 p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* MODAL 1: ABOUT CITYDEALS */}
        {modalType === 'info-about' && (
          <div className="p-6 sm:p-8 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-md">
                <Tag className="w-6 h-6 -rotate-45" />
              </div>
              <div>
                <h2 className="text-xl font-extrabold text-slate-900">About CityDeals</h2>
                <p className="text-xs text-blue-600 font-bold">Dibrugarh, Assam Launch Edition</p>
              </div>
            </div>

            <div className="text-xs sm:text-sm text-slate-600 space-y-3 leading-relaxed">
              <p>
                <strong>CityDeals</strong> is a modern local discovery and advertising marketplace designed to connect
                every citizen and every brick-and-mortar business in a city.
              </p>
              <p>
                Unlike closed student discount programs or high-commission delivery apps, CityDeals is open to all
                citizens. <strong>Browsing verified offers is always 100% free</strong> with no forced registration.
              </p>
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                  Our Three Core Commitments:
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>Zero Fee for Public:</strong> Discover discounts freely anytime.</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>100% Verified Moderation:</strong> Every deal is vetted before publishing.</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>Direct Shop Connect:</strong> Call, WhatsApp, or navigate directly to the shop.</span>
                  </li>
                </ul>
              </div>
              <p className="text-[11px] text-slate-500 italic">
                Launch Market: Dibrugarh, Upper Assam. Future roadmaps planned for Guwahati, Jorhat, Tinsukia, and
                beyond across Assam.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={closeModal}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-xl"
              >
                Got It
              </button>
            </div>
          </div>
        )}

        {/* MODAL 2: ADVERTISING RATE CARD */}
        {modalType === 'info-rates' && (
          <div className="p-6 sm:p-8 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-md">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-extrabold text-slate-900">Advertising & Rate Card</h2>
                <p className="text-xs text-amber-700 font-bold">Monetization & Sponsored Placements</p>
              </div>
            </div>

            <div className="bg-amber-50 p-3.5 rounded-2xl border border-amber-200 text-xs text-amber-950">
              <p className="font-bold">Transparent Demonstration Note:</p>
              <p className="mt-0.5 text-amber-900 leading-relaxed">
                CityDeals earns revenue through merchant sponsored listings and advertising packages. The rates below
                are configurable example prices for this prototype.
              </p>
            </div>

            <div className="space-y-3">
              {promotionPackages.map((pkg) => (
                <div key={pkg.id} className="p-3.5 rounded-2xl border border-slate-200 bg-white space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-sm">{pkg.name}</h4>
                    <span className="text-base font-black text-blue-600">₹{pkg.priceInr}</span>
                  </div>
                  <p className="text-xs text-slate-500">{pkg.description}</p>
                  <div className="text-[11px] text-slate-600 font-medium">
                    Duration: {pkg.durationDays} Days • Badge: {pkg.badge}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2">
              <button
                onClick={closeModal}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2.5 rounded-xl shadow-md"
              >
                Close Rate Card
              </button>
            </div>
          </div>
        )}

        {/* MODAL 3: PRIVACY & TERMS */}
        {modalType === 'info-privacy' && (
          <div className="p-6 sm:p-8 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-extrabold text-slate-900">Privacy & Terms Policy</h2>
                <p className="text-xs text-slate-500">Consumer Protection & Shopkeeper Guidelines</p>
              </div>
            </div>

            <div className="text-xs text-slate-600 space-y-3 leading-relaxed max-h-60 overflow-y-auto pr-1">
              <p>
                <strong>1. Free Public Access:</strong> Anyone can search and view approved offers without registration.
                No student ID verification is enforced.
              </p>
              <p>
                <strong>2. Truth in Advertising:</strong> All merchant submissions must clearly define discount amounts,
                applicable dates, and unambiguous terms and conditions. Deceptive discounts or refusal to honor stated
                offers may result in listing suspension or merchant removal.
              </p>
              <p>
                <strong>3. Moderation & Server Enforcement:</strong> Deals are queued for administrative review before
                appearing publicly. Citizens can submit moderation reports if deals are misleading.
              </p>
              <p>
                <strong>4. Data Privacy:</strong> Merchant contact numbers (phone and WhatsApp) are published with their
                consent for customer redemption inquiries. We do not sell user data.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={closeModal}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-xl"
              >
                Acknowledge
              </button>
            </div>
          </div>
        )}

        {/* MODAL 4: DYNAMIC MULTI-DISTRICT & LOCALITY SELECTOR */}
        {modalType === 'city-selector' && (
          <div className="p-6 sm:p-8 space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-extrabold text-slate-900">Choose Your Location</h2>
                <p className="text-xs text-slate-500">Serving Tinsukia & Dibrugarh districts, Assam</p>
              </div>
            </div>

            {/* Step 1: District Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Select District
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['Dibrugarh', 'Tinsukia'].map((distName) => {
                  const isSelected = activeDistrictTab.toLowerCase() === distName.toLowerCase();
                  return (
                    <button
                      key={distName}
                      type="button"
                      onClick={() => setActiveDistrictTab(distName)}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'border-2 border-blue-600 bg-blue-50/70 shadow-xs'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-sm text-slate-900">{distName}</span>
                        <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-full">
                          Live Market
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">Assam, India</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Localities in Selected District */}
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Towns & Localities in {activeDistrictTab}
                </label>
                <span className="text-[11px] text-slate-500 font-medium">
                  {getLocalitiesForDistrict(activeDistrictTab).length} available
                </span>
              </div>

              {/* Entire District Option */}
              <button
                type="button"
                onClick={() => {
                  setSelectedDistrict(activeDistrictTab);
                  setSelectedLocality('all');
                  showToast(`Selected all localities in ${activeDistrictTab} District`, 'info');
                  closeModal();
                }}
                className={`w-full p-2.5 rounded-xl border text-left text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                  selectedDistrict.toLowerCase() === activeDistrictTab.toLowerCase() && selectedLocality === 'all'
                    ? 'border-blue-600 bg-blue-50 text-blue-700 ring-1 ring-blue-500'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span>All {activeDistrictTab} Areas (District-Wide)</span>
                {selectedDistrict.toLowerCase() === activeDistrictTab.toLowerCase() && selectedLocality === 'all' && (
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                )}
              </button>

              {/* Localities Grid */}
              <div className="max-h-60 overflow-y-auto pr-1 grid grid-cols-2 sm:grid-cols-3 gap-2">
                {getLocalitiesForDistrict(activeDistrictTab).map((loc) => {
                  const isLocSelected =
                    selectedDistrict.toLowerCase() === activeDistrictTab.toLowerCase() &&
                    selectedLocality.toLowerCase() === loc.name.toLowerCase();
                  return (
                    <button
                      key={loc.id || loc.name}
                      type="button"
                      onClick={() => {
                        setSelectedDistrict(activeDistrictTab);
                        setSelectedLocality(loc.name);
                        showToast(`Showing deals in ${loc.name}, ${activeDistrictTab}`, 'success');
                        closeModal();
                      }}
                      className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer flex items-center justify-between ${
                        isLocSelected
                          ? 'border-blue-600 bg-blue-600 text-white font-bold shadow-xs'
                          : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50 text-slate-800 font-medium'
                      }`}
                    >
                      <span className="truncate">{loc.name}</span>
                      {isLocSelected && <CheckCircle2 className="w-3.5 h-3.5 shrink-0 ml-1 text-white" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
