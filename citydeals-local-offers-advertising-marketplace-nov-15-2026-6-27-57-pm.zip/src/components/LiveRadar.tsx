import React, { useState, useEffect } from 'react';
import { Offer, Business } from '../types';
import { api } from '../api/client';
import { useApp } from '../context/AppContext';
import { optimizeImageUrl } from '../utils/image';
import {
  Flame,
  Sparkles,
  Clock,
  Store,
  ShieldCheck,
  ChevronRight,
  MapPin,
  Tag,
  Radio,
} from 'lucide-react';

interface LiveRadarProps {
  onSelectOffer: (offer: Offer) => void;
  onSelectShop?: (shop: Business) => void;
}

type RadarTab = 'trending' | 'new_today' | 'expiring_soon' | 'popular_shops' | 'recently_verified';

export const LiveRadar: React.FC<LiveRadarProps> = ({ onSelectOffer, onSelectShop }) => {
  const { selectedDistrict, selectedCity } = useApp();
  const currentCity = selectedDistrict || selectedCity || 'All Locations';

  const [activeTab, setActiveTab] = useState<RadarTab>('trending');
  const [loading, setLoading] = useState(true);
  const [radarData, setRadarData] = useState<{
    trendingOffers: Offer[];
    newOffersToday: Offer[];
    expiringSoonOffers: Offer[];
    popularShops: (Business & { activeOffersCount: number })[];
    recentlyVerifiedOffers: Offer[];
    meta?: { city: string; lastUpdated: string; activeDealsCount: number };
  }>({
    trendingOffers: [],
    newOffersToday: [],
    expiringSoonOffers: [],
    popularShops: [],
    recentlyVerifiedOffers: [],
  });

  useEffect(() => {
    let mounted = true;
    const fetchRadar = async () => {
      try {
        setLoading(true);
        const data = await api.getRadar({
          district: currentCity !== 'All Locations' ? currentCity : undefined,
          city: currentCity !== 'All Locations' ? currentCity : undefined,
        });
        if (mounted) {
          setRadarData(data);
        }
      } catch (err) {
        console.error('Failed to load live radar:', err);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    fetchRadar();
    // Poll radar data periodically only when tab is active
    const interval = setInterval(() => {
      if (typeof document === 'undefined' || !document.hidden) {
        fetchRadar();
      }
    }, 60000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [currentCity]);

  const tabs: Array<{
    id: RadarTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    color: string;
    badgeCount: number;
  }> = [
    {
      id: 'trending',
      label: `Trending in ${currentCity}`,
      icon: Flame,
      color: 'text-amber-500',
      badgeCount: radarData.trendingOffers.length,
    },
    {
      id: 'new_today',
      label: 'New Offers Today',
      icon: Sparkles,
      color: 'text-blue-500',
      badgeCount: radarData.newOffersToday.length,
    },
    {
      id: 'expiring_soon',
      label: 'Expiring Soon',
      icon: Clock,
      color: 'text-rose-500',
      badgeCount: radarData.expiringSoonOffers.length,
    },
    {
      id: 'popular_shops',
      label: 'Popular Local Shops',
      icon: Store,
      color: 'text-emerald-500',
      badgeCount: radarData.popularShops.length,
    },
    {
      id: 'recently_verified',
      label: 'Recently Verified',
      icon: ShieldCheck,
      color: 'text-indigo-500',
      badgeCount: radarData.recentlyVerifiedOffers.length,
    },
  ];

  return (
    <div className="bg-gradient-to-br from-slate-900 via-[#0A0F1D] to-blue-950 rounded-2xl p-4 sm:p-6 text-white border border-blue-900/40 shadow-xl overflow-hidden relative">
      {/* Background glow effects */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header with live pulsing radar indicator */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 border border-blue-400/30">
            <Radio className="w-4 h-4 animate-pulse motion-reduce:animate-none text-blue-400" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-slate-900 animate-ping motion-reduce:animate-none" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-slate-900" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold tracking-tight text-white">CityDeals Live Radar</h2>
              <span className="bg-blue-500/20 text-blue-300 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-blue-400/30">
                LIVE • {currentCity}
              </span>
            </div>
            <p className="text-xs text-slate-300">Real-time hyperlocal activity in {currentCity}</p>
          </div>
        </div>

        {radarData.meta && (
          <div className="text-right text-[11px] text-slate-400 hidden sm:block">
            <span className="text-blue-300 font-semibold">{radarData.meta.activeDealsCount}</span> live deals in {currentCity}
          </div>
        )}
      </div>

      {/* Scrollable Radar Tabs */}
      <div className="relative z-10 flex items-center gap-2 overflow-x-auto no-scrollbar py-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 border ${
                isActive
                  ? 'bg-blue-600 text-white border-blue-400 shadow-md shadow-blue-600/30 scale-[1.02]'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white border-white/10'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : tab.color}`} />
              <span>{tab.label}</span>
              {tab.badgeCount > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isActive ? 'bg-white/20 text-white' : 'bg-white/10 text-slate-300'
                  }`}
                >
                  {tab.badgeCount}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content Display */}
      <div className="relative z-10 mt-2">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[1, 2, 3].map((n) => (
              <div key={n} className="bg-white/5 rounded-xl p-3 animate-pulse border border-white/5 h-28" />
            ))}
          </div>
        ) : (
          <div>
            {/* 1. Trending Deals */}
            {activeTab === 'trending' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {radarData.trendingOffers.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center col-span-full">No trending offers right now.</p>
                ) : (
                  radarData.trendingOffers.map((offer) => (
                    <div
                      key={offer.id}
                      onClick={() => onSelectOffer(offer)}
                      className="group bg-white/5 hover:bg-white/10 p-3 rounded-xl border border-white/10 hover:border-blue-400/40 cursor-pointer transition-all flex gap-3 items-center"
                    >
                      {offer.imageUrl ? (
                        <img
                          src={optimizeImageUrl(offer.imageUrl, 160, 75)}
                          alt={offer.headline}
                          width={64}
                          height={64}
                          loading="lazy"
                          decoding="async"
                          className="w-16 h-16 rounded-lg object-cover flex-shrink-0 border border-white/10"
                        />
                      ) : (
                        <div className="w-16 h-16 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center flex-shrink-0">
                          <Tag className="w-6 h-6 text-blue-400" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20">
                            {offer.discountValue}
                          </span>
                          <span className="text-[10px] text-slate-300 truncate">{offer.locality}</span>
                        </div>
                        <h3 className="text-xs font-semibold text-white truncate group-hover:text-blue-300 transition-colors">
                          {offer.headline}
                        </h3>
                        <div className="flex items-center justify-between text-[11px] text-slate-300 mt-1">
                          <span className="truncate">{offer.shopName}</span>
                          <span className="text-blue-400 font-medium flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform flex-shrink-0">
                            View <ChevronRight className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* 2. New Offers Today */}
            {activeTab === 'new_today' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {radarData.newOffersToday.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center col-span-full">No new offers posted today yet.</p>
                ) : (
                  radarData.newOffersToday.map((offer) => (
                    <div
                      key={offer.id}
                      onClick={() => onSelectOffer(offer)}
                      className="group bg-white/5 hover:bg-white/10 p-3 rounded-xl border border-white/10 hover:border-blue-400/40 cursor-pointer transition-all flex gap-3 items-center"
                    >
                      {offer.imageUrl ? (
                        <img
                          src={optimizeImageUrl(offer.imageUrl, 160, 75)}
                          alt={offer.headline}
                          width={64}
                          height={64}
                          loading="lazy"
                          decoding="async"
                          className="w-16 h-16 rounded-lg object-cover flex-shrink-0 border border-white/10"
                        />
                      ) : (
                        <div className="w-16 h-16 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-6 h-6 text-blue-400" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="text-[10px] font-bold text-blue-400 bg-blue-400/10 px-1.5 py-0.5 rounded border border-blue-400/20">
                            NEW TODAY
                          </span>
                          <span className="text-[10px] text-emerald-400 font-semibold">{offer.discountValue}</span>
                        </div>
                        <h3 className="text-xs font-semibold text-white truncate group-hover:text-blue-300 transition-colors">
                          {offer.headline}
                        </h3>
                        <div className="flex items-center justify-between text-[11px] text-slate-300 mt-1">
                          <span className="truncate">{offer.shopName} • {offer.locality}</span>
                          <ChevronRight className="w-3.5 h-3.5 text-blue-400 group-hover:translate-x-0.5 transition-transform" />
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* 3. Expiring Soon */}
            {activeTab === 'expiring_soon' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {radarData.expiringSoonOffers.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center col-span-full">No offers expiring in the next 72 hours.</p>
                ) : (
                  radarData.expiringSoonOffers.map((offer) => (
                    <div
                      key={offer.id}
                      onClick={() => onSelectOffer(offer)}
                      className="group bg-white/5 hover:bg-white/10 p-3 rounded-xl border border-rose-500/20 hover:border-rose-400/50 cursor-pointer transition-all flex gap-3 items-center"
                    >
                      <div className="w-16 h-16 rounded-lg bg-rose-500/20 border border-rose-500/30 flex flex-col items-center justify-center flex-shrink-0 text-rose-300">
                        <Clock className="w-5 h-5 mb-0.5" />
                        <span className="text-[9px] font-bold uppercase tracking-wider">HURRY</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="text-[10px] font-bold text-rose-300 bg-rose-500/20 px-1.5 py-0.5 rounded">
                            Ends {new Date(offer.validUntil).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                          </span>
                          <span className="text-[10px] text-amber-400 font-semibold">{offer.discountValue}</span>
                        </div>
                        <h3 className="text-xs font-semibold text-white truncate group-hover:text-rose-200 transition-colors">
                          {offer.headline}
                        </h3>
                        <div className="flex items-center justify-between text-[11px] text-slate-300 mt-1">
                          <span className="truncate">{offer.shopName}</span>
                          <span className="text-rose-400 font-medium flex items-center gap-0.5 text-[11px]">
                            Claim →
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* 4. Popular Local Shops */}
            {activeTab === 'popular_shops' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {radarData.popularShops.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center col-span-full">No shops listed yet.</p>
                ) : (
                  radarData.popularShops.map((shop) => (
                    <div
                      key={shop.id}
                      onClick={() => onSelectShop?.(shop)}
                      className="group bg-white/5 hover:bg-white/10 p-3 rounded-xl border border-white/10 hover:border-emerald-400/40 cursor-pointer transition-all flex gap-3 items-center"
                    >
                      {shop.logoUrl ? (
                        <img
                          src={optimizeImageUrl(shop.logoUrl, 160, 75)}
                          alt={shop.name}
                          width={56}
                          height={56}
                          loading="lazy"
                          decoding="async"
                          className="w-14 h-14 rounded-xl object-cover flex-shrink-0 border border-white/10"
                        />
                      ) : (
                        <div className="w-14 h-14 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
                          <Store className="w-6 h-6 text-emerald-400" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1 mb-0.5">
                          <h3 className="text-xs font-semibold text-white truncate group-hover:text-emerald-300 transition-colors">
                            {shop.name}
                          </h3>
                          {shop.verified && (
                            <ShieldCheck className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-[11px] text-slate-300 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" /> {shop.locality}, {shop.district || shop.city || currentCity}
                        </p>
                        <div className="flex items-center justify-between text-[10px] text-emerald-400 font-medium mt-1">
                          <span>{shop.activeOffersCount} Active Offers</span>
                          <span className="text-slate-400 flex items-center gap-0.5">
                            Visit Store <ChevronRight className="w-3 h-3 text-emerald-400" />
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* 5. Recently Verified */}
            {activeTab === 'recently_verified' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {radarData.recentlyVerifiedOffers.length === 0 ? (
                  <p className="text-xs text-slate-400 py-6 text-center col-span-full">No verified offers yet.</p>
                ) : (
                  radarData.recentlyVerifiedOffers.map((offer) => (
                    <div
                      key={offer.id}
                      onClick={() => onSelectOffer(offer)}
                      className="group bg-white/5 hover:bg-white/10 p-3 rounded-xl border border-indigo-500/20 hover:border-indigo-400/50 cursor-pointer transition-all flex gap-3 items-center"
                    >
                      <div className="w-14 h-14 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center flex-shrink-0">
                        <ShieldCheck className="w-6 h-6 text-indigo-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1 mb-1">
                          <span className="text-[9px] font-bold text-indigo-300 bg-indigo-500/20 px-1.5 py-0.5 rounded flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                            Verified {offer.lastVerifiedAt ? new Date(offer.lastVerifiedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'Recently'}
                          </span>
                        </div>
                        <h3 className="text-xs font-semibold text-white truncate group-hover:text-indigo-300 transition-colors">
                          {offer.headline}
                        </h3>
                        <div className="flex items-center justify-between text-[11px] text-slate-300 mt-1">
                          <span className="truncate">{offer.shopName}</span>
                          <span className="text-emerald-400 font-bold">{offer.discountValue}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
