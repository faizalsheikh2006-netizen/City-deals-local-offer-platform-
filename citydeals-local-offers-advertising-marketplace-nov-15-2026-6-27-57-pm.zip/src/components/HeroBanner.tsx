import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Search,
  MapPin,
  Sparkles,
  Store,
  Navigation,
  Map as MapIcon,
  List,
  Compass,
  ArrowUpDown,
  LocateFixed,
  Loader2,
  History,
  X,
} from 'lucide-react';
import { useRecentSearches } from '../hooks/useRecentSearches';

interface HeroBannerProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedLocality: string;
  setSelectedLocality: (loc: string) => void;
  totalOffersCount: number;
  totalShopsCount: number;
  viewMode: 'offers' | 'shops' | 'map';
  setViewMode: (mode: 'offers' | 'shops' | 'map') => void;
  userLocation: { lat: number; lng: number } | null;
  onEnableLocation: () => void;
  isLocating: boolean;
  locationError: string | null;
  distanceFilter: number | null;
  setDistanceFilter: (d: number | null) => void;
  sortBy: string;
  setSortBy: (s: string) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  searchQuery,
  setSearchQuery,
  selectedLocality,
  setSelectedLocality,
  totalOffersCount,
  totalShopsCount,
  viewMode,
  setViewMode,
  userLocation,
  onEnableLocation,
  isLocating,
  locationError,
  distanceFilter,
  setDistanceFilter,
  sortBy,
  setSortBy,
}) => {
  const { selectedCity, cities, selectedDistrict, setSelectedDistrict, getLocalitiesForDistrict, openModal } = useApp();

  const districtLocalities = getLocalitiesForDistrict(selectedDistrict);
  const localities = districtLocalities.length > 0
    ? districtLocalities.map((l) => l.name)
    : (cities.find((c) => c.name.toLowerCase() === (selectedDistrict || selectedCity).toLowerCase())?.localities || []);

  const distanceOptions: Array<{ label: string; value: number | null }> = [
    { label: 'All Distances', value: null },
    { label: '500m', value: 0.5 },
    { label: '1 km', value: 1.0 },
    { label: '2 km', value: 2.0 },
    { label: '5 km', value: 5.0 },
  ];

  const { recentSearches, saveSearch, removeSearch, clearAllSearches } = useRecentSearches();
  const [showRecentDropdown, setShowRecentDropdown] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowRecentDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (searchQuery.trim().length >= 2) {
        saveSearch(searchQuery.trim());
      }
      setShowRecentDropdown(false);
    } else if (e.key === 'Escape') {
      setShowRecentDropdown(false);
    }
  };

  const handleSelectRecent = (term: string) => {
    setSearchQuery(term);
    saveSearch(term);
    setShowRecentDropdown(false);
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-blue-950 text-white pt-5 pb-6 sm:pt-8 sm:pb-9 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
      {/* Background radial blurs */}
      <div className="absolute top-0 left-1/4 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-5xl mx-auto space-y-4">
        {/* Top compact badge and headline */}
        <div className="text-center space-y-2.5">
          {/* Quick District Switcher Pills */}
          <div className="inline-flex items-center gap-1.5 p-1 rounded-full bg-slate-900/90 border border-slate-700/80 backdrop-blur-md">
            <span className="text-[11px] font-bold text-slate-400 pl-2.5">District:</span>
            {['Dibrugarh', 'Tinsukia'].map((dist) => {
              const active = (selectedDistrict || selectedCity).toLowerCase() === dist.toLowerCase();
              return (
                <button
                  key={dist}
                  type="button"
                  onClick={() => {
                    setSelectedDistrict(dist);
                    setSelectedLocality('all');
                  }}
                  className={`px-3 py-1 rounded-full text-xs font-extrabold transition-all cursor-pointer ${
                    active
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {dist}
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => openModal('city-selector')}
              className="text-[11px] font-medium text-blue-400 hover:text-blue-300 pr-2 pl-1 underline cursor-pointer"
            >
              Choose Area
            </button>
          </div>

          <h1 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Discover Local. <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">Save Smart.</span>
          </h1>
          <p className="max-w-2xl mx-auto text-xs sm:text-sm text-slate-300 leading-normal">
            Real live offers & verified promotions at neighborhood shops in <strong className="text-white">{selectedDistrict || selectedCity} District</strong>, Assam.
          </p>
        </div>

        {/* Search, GPS, and Locality Filter Card */}
        <div className="max-w-4xl mx-auto bg-white/95 backdrop-blur-md p-3 sm:p-4 rounded-2xl shadow-xl border border-white/20 text-slate-800 text-left">
          {/* Main search and filters row */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            {/* Search Input with Recent Searches Dropdown */}
            <div ref={searchContainerRef} className="relative flex-1">
              <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-xl border border-slate-200 focus-within:border-blue-500 focus-within:bg-white focus-within:shadow-xs transition-all">
                <Search className="w-4 h-4 text-slate-500 shrink-0" />
                <input
                  type="text"
                  aria-label="Search local shops, offer headlines, brands, or areas"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    if (!showRecentDropdown && recentSearches.length > 0) {
                      setShowRecentDropdown(true);
                    }
                  }}
                  onFocus={() => {
                    if (recentSearches.length > 0) {
                      setShowRecentDropdown(true);
                    }
                  }}
                  onKeyDown={handleKeyDown}
                  placeholder="Search shop, offer headline, brand, or area..."
                  className="w-full text-xs sm:text-sm bg-transparent border-none outline-none text-slate-900 placeholder:text-slate-500 font-medium"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setShowRecentDropdown(recentSearches.length > 0);
                    }}
                    className="text-xs text-slate-600 hover:text-slate-900 font-bold px-1 cursor-pointer"
                    title="Clear search input"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* Floating Recent Searches Dropdown */}
              {showRecentDropdown && recentSearches.length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-1.5 z-40 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 overflow-hidden animate-in fade-in-50 duration-150">
                  <div className="flex items-center justify-between px-3 py-1 border-b border-slate-100 text-[11px] font-semibold text-slate-600">
                    <span className="flex items-center gap-1.5">
                      <History className="w-3.5 h-3.5 text-blue-600" />
                      Recent Searches
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        clearAllSearches();
                        setShowRecentDropdown(false);
                      }}
                      className="text-[10px] text-slate-600 hover:text-rose-600 transition-colors cursor-pointer"
                    >
                      Clear all
                    </button>
                  </div>
                  <div className="max-h-48 overflow-y-auto divide-y divide-slate-50">
                    {recentSearches.map((term) => (
                      <div
                        key={term}
                        className="flex items-center justify-between px-3 py-2 hover:bg-blue-50/70 text-xs text-slate-700 cursor-pointer transition-colors group"
                        onClick={() => handleSelectRecent(term)}
                      >
                        <div className="flex items-center gap-2 min-w-0 flex-1">
                          <History className="w-3 h-3 text-slate-500 group-hover:text-blue-500 shrink-0" />
                          <span className="truncate font-medium">{term}</span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeSearch(term);
                          }}
                          className="p-1 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-md transition-all shrink-0 cursor-pointer"
                          aria-label={`Remove "${term}" from history`}
                          title={`Remove "${term}" from history`}
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Locality Dropdown */}
            <div className="sm:w-56 flex items-center gap-1.5 px-3 py-2 bg-slate-50 rounded-xl border border-slate-200">
              <MapPin className="w-4 h-4 text-blue-600 shrink-0" />
              <select
                aria-label="Filter offers by town or locality"
                value={selectedLocality}
                onChange={(e) => setSelectedLocality(e.target.value)}
                className="w-full text-xs sm:text-sm bg-transparent border-none outline-none text-slate-800 font-semibold cursor-pointer"
              >
                <option value="all">All {selectedDistrict || selectedCity} Localities</option>
                {localities.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>

            {/* GPS Nearby Discovery Button */}
            <button
              onClick={onEnableLocation}
              disabled={isLocating}
              className={`flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-sm shrink-0 cursor-pointer ${
                userLocation
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/20'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20'
              }`}
              title="Locate deals near your current GPS position"
            >
              {isLocating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Locating...</span>
                </>
              ) : userLocation ? (
                <>
                  <LocateFixed className="w-3.5 h-3.5 text-white" />
                  <span>Near Me Active</span>
                </>
              ) : (
                <>
                  <Navigation className="w-3.5 h-3.5 text-white" />
                  <span>Find Near Me</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Recent Searches Chips Row */}
          {recentSearches.length > 0 && (
            <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center flex-wrap gap-1.5">
              <span className="text-[11px] font-semibold text-slate-600 flex items-center gap-1 shrink-0">
                <History className="w-3 h-3 text-blue-500" />
                Recent:
              </span>
              {recentSearches.slice(0, 4).map((term) => (
                <span
                  key={term}
                  onClick={() => handleSelectRecent(term)}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 text-[11px] font-medium border border-slate-200 transition-colors cursor-pointer group"
                >
                  <span className="truncate max-w-[140px]">{term}</span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeSearch(term);
                    }}
                    className="text-slate-600 hover:text-rose-600 p-0.5 rounded-full transition-colors cursor-pointer"
                    aria-label={`Remove "${term}"`}
                    title={`Remove "${term}"`}
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                </span>
              ))}
              {recentSearches.length > 4 && (
                <button
                  type="button"
                  onClick={() => setShowRecentDropdown(true)}
                  className="text-[10px] text-blue-600 hover:underline font-semibold cursor-pointer ml-0.5"
                >
                  +{recentSearches.length - 4} more
                </button>
              )}
            </div>
          )}

          {locationError && (
            <p className="text-[11px] text-rose-600 font-medium mt-1.5 px-1">{locationError}</p>
          )}

          {/* Secondary Controls: Distance Pills & View Mode Toggle */}
          <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2.5">
            {/* Distance Filter Pills (500m, 1km, 2km, 5km) */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] font-bold text-slate-600 mr-1 flex items-center gap-1">
                <Compass className="w-3 h-3 text-blue-600" />
                Distance:
              </span>
              {distanceOptions.map((opt) => {
                const isSelected = distanceFilter === opt.value;
                return (
                  <button
                    key={opt.label}
                    onClick={() => {
                      if (!userLocation && opt.value !== null) {
                        onEnableLocation();
                      }
                      setDistanceFilter(opt.value);
                      if (opt.value !== null) {
                        setSortBy('nearest');
                      }
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>

            {/* Sort & View Mode Switcher */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Sort By Dropdown */}
              <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 px-2 py-1 rounded-lg text-xs">
                <ArrowUpDown className="w-3 h-3 text-slate-500" />
                <select
                  aria-label="Sort offers and shops"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-transparent border-none outline-none text-slate-700 font-medium text-xs cursor-pointer"
                >
                  <option value="newest">Newest First</option>
                  {userLocation && <option value="nearest">Nearest to Me</option>}
                  <option value="popular">Most Popular</option>
                  <option value="expiring_soon">Expiring Soon</option>
                </select>
              </div>

              {/* View Mode Toggle: Offers vs Shops vs Map */}
              <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
                <button
                  onClick={() => setViewMode('offers')}
                  className={`px-2.5 py-1 rounded-md font-bold text-[11px] transition-all flex items-center gap-1 ${
                    viewMode === 'offers'
                      ? 'bg-white text-blue-700 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <List className="w-3 h-3" />
                  <span>Offers ({totalOffersCount})</span>
                </button>

                <button
                  onClick={() => setViewMode('shops')}
                  className={`px-2.5 py-1 rounded-md font-bold text-[11px] transition-all flex items-center gap-1 ${
                    viewMode === 'shops'
                      ? 'bg-white text-blue-700 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Store className="w-3 h-3 text-blue-600" />
                  <span>Shops ({totalShopsCount})</span>
                </button>

                <button
                  onClick={() => setViewMode('map')}
                  className={`px-2.5 py-1 rounded-md font-bold text-[11px] transition-all flex items-center gap-1 ${
                    viewMode === 'map'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <MapIcon className="w-3 h-3" />
                  <span>Interactive Map</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
