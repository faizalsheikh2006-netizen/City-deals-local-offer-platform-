import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { ShoppingOrder } from '../types/index';
import {
  X,
  PackageCheck,
  Store,
  ChevronRight,
  Search,
  Clock,
  Phone,
  ShoppingBag,
} from 'lucide-react';

export const OrderHistoryModal: React.FC = () => {
  const { closeModal, openModal, user, isAuthenticated, setActiveView } = useApp();
  const [orders, setOrders] = useState<ShoppingOrder[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [phoneLookup, setPhoneLookup] = useState<string>(user?.phone || '');

  const fetchOrders = async (phoneToQuery?: string) => {
    try {
      setIsLoading(true);
      const res = await api.getMyOrders(phoneToQuery);
      setOrders(res.orders || []);
    } catch (err) {
      console.warn('Error fetching orders:', err);
      setOrders([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders(phoneLookup || undefined);
  }, []);

  const handlePhoneSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneLookup.trim()) {
      fetchOrders(phoneLookup.trim());
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <PackageCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-slate-900">Your Shopping Orders</h3>
              <p className="text-xs text-slate-500 font-medium">Track local Dibrugarh purchases</p>
            </div>
          </div>

          <button
            onClick={closeModal}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Lookup by Phone input */}
        <form onSubmit={handlePhoneSearch} className="p-3 sm:p-4 bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="tel"
                value={phoneLookup}
                onChange={(e) => setPhoneLookup(e.target.value)}
                placeholder="Search orders by phone number..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs bg-white font-medium focus:outline-none focus:border-blue-600"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-xl hover:bg-blue-700 cursor-pointer shadow-2xs"
            >
              Lookup
            </button>
          </div>
        </form>

        {/* Orders List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-20 bg-slate-100 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3">
                <ShoppingBag className="w-7 h-7" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">No orders found</h4>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                You haven't placed any shopping orders with this phone number yet.
              </p>
              <button
                onClick={() => {
                  closeModal();
                  setActiveView('shopping');
                }}
                className="px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs hover:bg-blue-700 cursor-pointer shadow-xs"
              >
                Browse Dibrugarh Products
              </button>
            </div>
          ) : (
            orders.map((ord) => (
              <div
                key={ord.id}
                onClick={() => openModal('order-details', ord)}
                className="p-3.5 rounded-2xl border border-slate-200 hover:border-blue-400 bg-white shadow-2xs hover:shadow-sm transition-all cursor-pointer flex items-center justify-between gap-3 group"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-[11px] font-black text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded border border-blue-100">
                      #{ord.orderNumber}
                    </span>
                    <span className="text-[10px] font-bold text-slate-400">
                      {new Date(ord.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                      })}
                    </span>
                  </div>
                  <h5 className="font-extrabold text-xs text-slate-900 group-hover:text-blue-600 truncate">
                    {ord.shopName}
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                    {ord.items.length} {ord.items.length === 1 ? 'item' : 'items'} • ₹
                    {ord.totalAmount.toLocaleString('en-IN')} ({ord.fulfillmentType === 'delivery' ? 'Delivery' : 'Pickup'})
                  </p>
                </div>

                <div className="text-right shrink-0 flex items-center gap-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                      ord.status === 'delivered'
                        ? 'bg-emerald-100 text-emerald-800'
                        : ord.status === 'rejected' || ord.status === 'cancelled'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {ord.status.replace(/_/g, ' ')}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
