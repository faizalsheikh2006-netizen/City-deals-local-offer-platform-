import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { trackMerchantBusinessSaved } from '../lib/analytics';
import { Offer, Business, PromotionPackage, PromotionRequest, VerificationRequest, Product, ShoppingOrder, OrderStatus } from '../types/index';
import {
  Store,
  Tag,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Sparkles,
  Plus,
  Eye,
  MousePointer,
  MapPin,
  Calendar,
  Building,
  Phone,
  MessageCircle,
  Edit,
  Trash2,
  Power,
  ShieldAlert,
  ShieldCheck,
  FileCheck,
  Award,
  Share2,
  Gift,
  Copy,
  ExternalLink,
  RefreshCw,
  ShoppingBag,
  PackageCheck,
  Truck,
} from 'lucide-react';

export const ShopkeeperPortal: React.FC = () => {
  const {
    user,
    role,
    effectiveRole,
    isAuthenticated,
    setActiveView,
    switchRole,
    showToast,
    refreshKey,
    triggerRefresh,
    openModal,
    promotionPackages,
    categories,
    shareCityDeals,
    getPermanentAppUrl,
    selectedDistrict,
    getLocalitiesForDistrict,
    districts,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'offers' | 'products' | 'orders' | 'promotions' | 'verification' | 'profile'>('offers');
  const [offers, setOffers] = useState<Offer[]>([]);
  const [business, setBusiness] = useState<Business | null>(null);
  const [promoRequests, setPromoRequests] = useState<PromotionRequest[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<ShoppingOrder[]>([]);
  const [verificationRequest, setVerificationRequest] = useState<VerificationRequest | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const [bizForm, setBizForm] = useState({
    name: '',
    category: 'fashion',
    state: 'Assam',
    district: selectedDistrict || 'Dibrugarh',
    districtId: (selectedDistrict || 'Dibrugarh').toLowerCase(),
    city: selectedDistrict || 'Dibrugarh',
    locality: 'Dibrugarh Town',
    localityId: 'dibrugarh-town',
    address: '',
    fullAddress: '',
    landmark: '',
    openingHours: '10:00 AM – 8:30 PM (Mon–Sat)',
    phone: '',
    whatsapp: '',
    description: '',
  });

  // Load merchant data only when operating in merchant view
  useEffect(() => {
    if (effectiveRole !== 'merchant') {
      return;
    }
    async function loadData() {
      try {
        setIsLoading(true);
        const [bizRes, offersRes, promoRes, prodsRes, ordersRes, verifRes] = await Promise.all([
          api.getMerchantBusiness(),
          api.getMerchantOffers(),
          api.getMerchantPromotionRequests(),
          api.getMerchantProducts().catch(() => ({ count: 0, products: [] })),
          api.getMerchantOrders().catch(() => ({ count: 0, orders: [] })),
          api.getMerchantVerification().catch(() => ({ request: null, business: null, verificationFee: 499 })),
        ]);
        setBusiness(bizRes.business);
        setOffers(offersRes.offers);
        setPromoRequests(promoRes.promotionRequests);
        setProducts(prodsRes.products || []);
        setOrders(ordersRes.orders || []);
        setVerificationRequest(verifRes.request);
      } catch (err: any) {
        console.error('Failed to load merchant data:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, [effectiveRole, user, refreshKey]);

  useEffect(() => {
    if (business) {
      const resolvedDist = business.district || business.city || 'Dibrugarh';
      setBizForm({
        name: business.name || '',
        category: business.category || 'fashion',
        state: business.state || 'Assam',
        district: resolvedDist,
        districtId: business.districtId || resolvedDist.toLowerCase().replace(/[^a-z0-9]/g, '_'),
        city: resolvedDist,
        locality: business.locality || 'Dibrugarh Town',
        localityId: business.localityId || '',
        address: business.address || '',
        fullAddress: business.fullAddress || business.address || '',
        landmark: business.landmark || '',
        openingHours: business.openingHours || '10:00 AM – 8:30 PM (Mon–Sat)',
        phone: business.phone || '',
        whatsapp: business.whatsapp || '',
        description: business.description || '',
      });
    }
  }, [business]);

  if (effectiveRole !== 'merchant') {
    return (
      <div className="max-w-2xl mx-auto my-16 px-4 text-center">
        <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-10 shadow-sm">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center mx-auto mb-4 border border-blue-200 shadow-2xs">
            <Store className="w-8 h-8" />
          </div>

          {isAuthenticated && role === 'public' ? (
            <>
              <span className="text-[10px] font-bold uppercase tracking-widest text-amber-700 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-200">
                Customer Account
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2 mb-2">
                Merchant Portal Access Restricted
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mb-6 max-w-lg mx-auto leading-relaxed">
                You are currently signed in as a <strong className="text-slate-900">Public Customer</strong> ({user.email}).
                Customer accounts can browse, search, and bookmark all verified in-store deals, but cannot access merchant offer management tools.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => setActiveView('browse')}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-600/20 cursor-pointer"
                >
                  Return to Browse Local Deals
                </button>
                <button
                  onClick={() => openModal('auth', { tab: 'register', defaultRole: 'merchant' })}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs sm:text-sm cursor-pointer"
                >
                  Register a Shopkeeper Account
                </button>
              </div>
            </>
          ) : (
            <>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mb-2">
                Shopkeeper Portal Access
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mb-6 max-w-lg mx-auto leading-relaxed">
                Are you a local shopkeeper or retail business owner in Dibrugarh or Tinsukia? Create your free business profile, submit in-store offers for moderation, and reach thousands of local shoppers searching near your shop.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  onClick={() => openModal('auth', { tab: 'login', defaultRole: 'merchant' })}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-600/20 cursor-pointer"
                >
                  Sign In to Merchant Account
                </button>
                <button
                  onClick={() => openModal('auth', { tab: 'register', defaultRole: 'merchant' })}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs sm:text-sm cursor-pointer"
                >
                  Register New Shopkeeper Account
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  const handleDistrictChange = (newDistrict: string) => {
    const locs = getLocalitiesForDistrict(newDistrict);
    const defaultLoc = locs.length > 0 ? locs[0].name : '';
    const defaultLocId = locs.length > 0 ? locs[0].id : '';
    setBizForm((prev) => ({
      ...prev,
      district: newDistrict,
      districtId: newDistrict.toLowerCase().replace(/[^a-z0-9]/g, '_'),
      city: newDistrict,
      locality: defaultLoc,
      localityId: defaultLocId,
    }));
  };

  const handleSaveBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.saveMerchantBusiness(bizForm);
      setBusiness(res.business);
      showToast('Shop business profile updated successfully', 'success');

      // Track GA4 Merchant Profile Saved
      if (res.business) {
        trackMerchantBusinessSaved({
          name: res.business.name,
          category: res.business.category,
          city: res.business.city,
          locality: res.business.locality,
        });
      }

      triggerRefresh();
    } catch (err: any) {
      showToast(err.message || 'Failed to save business', 'error');
    }
  };

  const handleToggleOfferActive = async (offer: Offer) => {
    try {
      const res = await api.toggleOfferActive(offer.id);
      showToast(res.message, 'info');
      triggerRefresh();
    } catch (err: any) {
      showToast(err.message || 'Failed to update offer state', 'error');
    }
  };

  const handleDeleteOffer = async (id: string, headline: string) => {
    if (!window.confirm(`Are you sure you want to delete the offer "${headline}"?`)) return;
    try {
      await api.deleteOffer(id);
      showToast('Offer deleted from shop', 'info');
      triggerRefresh();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete offer', 'error');
    }
  };

  const handleToggleProductStock = async (product: Product) => {
    try {
      const res = await api.toggleProductStock(product.id);
      showToast(res.message, 'info');
      triggerRefresh();
    } catch (err: any) {
      showToast(err.message || 'Failed to update stock', 'error');
    }
  };

  const handleDeleteProduct = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to remove "${name}" from your shop catalog?`)) return;
    try {
      await api.deleteMerchantProduct(id);
      showToast('Product removed from catalog', 'info');
      triggerRefresh();
    } catch (err: any) {
      showToast(err.message || 'Failed to remove product', 'error');
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus, merchantNotes?: string) => {
    try {
      const res = await api.updateMerchantOrderStatus(orderId, status, merchantNotes);
      showToast(res.message, 'success');
      triggerRefresh();
    } catch (err: any) {
      showToast(err.message || 'Failed to update order status', 'error');
    }
  };

  const pendingOffers = offers.filter((o) => o.status === 'pending');
  const approvedOffers = offers.filter((o) => o.status === 'approved' && o.isActive !== false);
  const inactiveOffers = offers.filter((o) => o.status === 'approved' && o.isActive === false);
  const rejectedOffers = offers.filter((o) => o.status === 'rejected');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-blue-800/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-400/30">
                <Store className="w-5 h-5" />
              </span>
              <span className="text-xs uppercase tracking-widest font-bold text-blue-300">
                Shopkeeper Portal • In-Store Offers Directory
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {business?.name || `${user.name}'s Shop Dashboard`}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Manage your physical shop profile once, then submit and manage active in-store offers for Dibrugarh
              residents. No complex online product inventories or order processing required.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => shareCityDeals()}
              className="inline-flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-white/20 transition-all cursor-pointer backdrop-blur-md"
              title="Share CityDeals app with fellow shopkeepers"
            >
              <Share2 className="w-4 h-4 text-blue-300" />
              <span>Share CityDeals</span>
            </button>
            <button
              onClick={() => openModal('referrals')}
              className="inline-flex items-center gap-1.5 bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 font-bold text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-amber-400/30 transition-all cursor-pointer"
            >
              <Gift className="w-4 h-4 text-amber-300" />
              <span>Referrals ({user.referralCount || 0})</span>
            </button>
            <button
              onClick={() => openModal('post-offer')}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Submit In-Store Offer</span>
            </button>
            <button
              onClick={() => openModal('post-product')}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/25 transition-all hover:scale-105 cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>+ Add Product</span>
            </button>
            <button
              onClick={() => setActiveTab('promotions')}
              className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-lg transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>Promote Shop</span>
            </button>
            {business?.isVerified ? (
              <div
                onClick={() => setActiveTab('verification')}
                className="inline-flex items-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-emerald-400/40 backdrop-blur-md cursor-pointer transition-all"
                title="Click to view official verification certificate & renewal details"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verified Shop ✓</span>
              </div>
            ) : (
              <button
                onClick={() => openModal('request-verification')}
                className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 border border-indigo-400/30 transition-all hover:scale-105 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-blue-200" />
                <span>Get Verified (₹499)</span>
              </button>
            )}
          </div>
        </div>

        {/* Stats strip */}
        <div className="mt-6 pt-6 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          <div className="bg-white/5 backdrop-blur-xs p-3 rounded-xl border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Pending Review</span>
            <span className="text-xl font-bold text-amber-400">{pendingOffers.length}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Hidden till approved</span>
          </div>
          <div className="bg-white/5 backdrop-blur-xs p-3 rounded-xl border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Active Offers</span>
            <span className="text-xl font-bold text-emerald-400">{approvedOffers.length}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Live in directory</span>
          </div>
          <div className="bg-white/5 backdrop-blur-xs p-3 rounded-xl border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Shopper Views</span>
            <span className="text-xl font-bold text-blue-300">
              {offers.reduce((a, b) => a + (b.viewsCount || 0), 0)}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Genuine impressions</span>
          </div>
          <div className="bg-white/5 backdrop-blur-xs p-3 rounded-xl border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Customer Inquiries</span>
            <span className="text-xl font-bold text-indigo-300">
              {offers.reduce((a, b) => a + (b.clicksCount || 0), 0)}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Calls, directions & WhatsApp</span>
          </div>
          <div className="bg-white/5 backdrop-blur-xs p-3 rounded-xl border border-white/10 col-span-2 sm:col-span-1">
            <span className="text-slate-400 block text-[11px] font-medium">Total Shares</span>
            <span className="text-xl font-bold text-purple-300">
              {offers.reduce((a, b) => a + (b.sharesCount || 0), 0)}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">WhatsApp & native shares</span>
          </div>
        </div>
      </div>

      {/* Merchant Growth & Referral Banner */}
      <div className="bg-white rounded-2xl border border-blue-200/80 p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-100 text-blue-700 font-bold text-xs">
              <Gift className="w-4 h-4" />
            </span>
            <h3 className="text-sm font-extrabold text-slate-900">
              Merchant Referral Program • Grow the Dibrugarh Local Market
            </h3>
          </div>
          <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
            Invite fellow neighborhood retailers or regular customers to CityDeals. Your unique merchant referral code is{' '}
            <strong className="font-mono text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200 font-bold">
              {user.referralCode || 'DIB-MERCHANT'}
            </strong>. Verified accounts count towards community partner badges.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={() => {
              const url = getPermanentAppUrl(user.referralCode);
              const text = `Join CityDeals Dibrugarh using my merchant invite link to discover or list in-store offers: ${url}`;
              window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Share on WhatsApp</span>
          </button>
          <button
            onClick={() => {
              const url = getPermanentAppUrl(user.referralCode);
              navigator.clipboard.writeText(url);
              showToast('Personal referral link copied to clipboard!', 'success');
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5 text-slate-600" />
            <span>Copy Link</span>
          </button>
          <button
            onClick={() => openModal('referrals')}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs border border-blue-200 transition-colors cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>View Referral Stats</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('offers')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 cursor-pointer ${
            activeTab === 'offers'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>Shop Offers ({offers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 cursor-pointer ${
            activeTab === 'products'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>My Products ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 cursor-pointer ${
            activeTab === 'orders'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <PackageCheck className="w-4 h-4" />
          <span>Customer Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('promotions')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 cursor-pointer ${
            activeTab === 'promotions'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>Promotions & Sponsorships ({promoRequests.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Shop Business Profile</span>
        </button>

        <button
          onClick={() => setActiveTab('verification')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 cursor-pointer ${
            activeTab === 'verification'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className={`w-4 h-4 ${business?.isVerified ? 'text-emerald-500' : 'text-blue-500'}`} />
          <span>Shop Verification {business?.isVerified ? '(Verified ✓)' : ''}</span>
        </button>
      </div>

      {/* TAB 1: OFFERS LIST */}
      {activeTab === 'offers' && (
        <div className="space-y-6">
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-900">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-950">In-Store Local Offers Only</p>
              <p className="mt-0.5 text-amber-800 leading-relaxed">
                CityDeals is a physical shop offers directory. Submit deals and promotions running at your store.
                All offers default to <strong>Pending</strong> review and remain hidden from public search until approved
                by a CityDeals moderator. You can deactivate an offer at any time.
              </p>
            </div>
          </div>

          {offers.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-600 mx-auto flex items-center justify-center">
                <Store className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">No Offers Running Yet</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Attract more walk-in customers to your Dibrugarh store! Submit an offer headline (e.g. "Up to 20% Off",
                "Buy 1 Get 1", or "Festival Special").
              </p>
              <button
                onClick={() => openModal('post-offer')}
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Submit Your First In-Store Offer</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {offers.map((offer) => {
                const isPending = offer.status === 'pending';
                const isPastExpiry = new Date(offer.validUntil).getTime() < Date.now();
                const isExpired = offer.status === 'expired' || isPastExpiry;
                const isApproved = offer.status === 'approved' && offer.isActive !== false && !isPastExpiry;
                const isDeactivated = offer.status === 'approved' && offer.isActive === false && !isPastExpiry;
                const isRejected = offer.status === 'rejected';

                return (
                  <div
                    key={offer.id}
                    className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs hover:shadow-md transition-all flex flex-col md:flex-row gap-4 justify-between"
                  >
                    {/* Left: Thumbnail & Offer details */}
                    <div className="flex flex-col sm:flex-row gap-4 items-start flex-1">
                      <div className="w-full sm:w-36 h-28 rounded-xl bg-slate-100 overflow-hidden relative shrink-0">
                        <img
                          src={offer.imageUrl}
                          alt={offer.headline}
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute top-1.5 left-1.5 bg-red-600 text-white font-extrabold text-[10px] px-2 py-0.5 rounded shadow-xs">
                          {offer.discountValue}
                        </span>
                      </div>

                      <div className="space-y-1.5 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          {isPending && (
                            <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 font-bold text-xs px-2.5 py-0.5 rounded-full border border-amber-300">
                              <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                              <span>Pending Admin Review</span>
                            </span>
                          )}
                          {isApproved && (
                            <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-900 font-bold text-xs px-2.5 py-0.5 rounded-full border border-emerald-300">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Live in Directory</span>
                            </span>
                          )}
                          {isDeactivated && (
                            <span className="inline-flex items-center gap-1 bg-slate-200 text-slate-800 font-bold text-xs px-2.5 py-0.5 rounded-full">
                              <Power className="w-3 h-3 text-slate-500" />
                              <span>Deactivated by You</span>
                            </span>
                          )}
                          {isRejected && (
                            <span className="inline-flex items-center gap-1 bg-red-100 text-red-900 font-bold text-xs px-2.5 py-0.5 rounded-full border border-red-300">
                              <XCircle className="w-3.5 h-3.5 text-red-600" />
                              <span>Rejected by Admin</span>
                            </span>
                          )}
                          {isExpired && (
                            <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-900 font-bold text-xs px-2.5 py-0.5 rounded-full border border-rose-300">
                              <Clock className="w-3.5 h-3.5 text-rose-600" />
                              <span>Offer Expired</span>
                            </span>
                          )}

                          {offer.isSponsored && (
                            <span className="bg-blue-600 text-white font-bold text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1">
                              <Sparkles className="w-3 h-3 text-amber-300" />
                              <span>Sponsored: {offer.sponsorTier}</span>
                            </span>
                          )}

                          <span className="text-[11px] text-slate-500 capitalize">
                            {offer.category.replace('-', ' ')} • {offer.locality}
                          </span>
                        </div>

                        <h3 className="text-base font-bold text-slate-900 leading-snug">
                          {offer.headline}
                        </h3>

                        <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                          {offer.description}
                        </p>

                        {/* Rejection callout */}
                        {isRejected && offer.rejectionReason && (
                          <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900">
                            <span className="font-bold flex items-center gap-1 text-red-950">
                              <ShieldAlert className="w-3.5 h-3.5 text-red-600" />
                              Admin Rejection Reason:
                            </span>
                            <p className="mt-1 font-medium">{offer.rejectionReason}</p>
                          </div>
                        )}

                        <div className="flex flex-wrap items-center gap-4 pt-1 text-[11px] text-slate-500">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            <span>Valid until {new Date(offer.validUntil).toLocaleDateString()}</span>
                          </span>
                          <span className="flex items-center gap-1">
                            <Eye className="w-3 h-3 text-slate-400" />
                            <span>{offer.viewsCount || 0} In-Store Shopper Views</span>
                          </span>
                          <span className="flex items-center gap-1">
                            <MousePointer className="w-3 h-3 text-slate-400" />
                            <span>{offer.clicksCount || 0} Direct Connections</span>
                          </span>
                          <span className="flex items-center gap-1">
                            <Share2 className="w-3 h-3 text-slate-400" />
                            <span>{offer.sharesCount || 0} Shares</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Right: Actions */}
                    <div className="flex sm:flex-col items-center justify-end gap-2 border-t sm:border-t-0 sm:border-l border-slate-100 pt-3 sm:pt-0 sm:pl-4 shrink-0">
                      {isExpired && (
                        <button
                          onClick={() => openModal('edit-offer', offer)}
                          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Renew / Re-list</span>
                        </button>
                      )}

                      {isApproved && (
                        <button
                          onClick={() => openModal('request-promotion', { offerId: offer.id, offer })}
                          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs shadow-xs transition-colors"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Promote Offer</span>
                        </button>
                      )}

                      {/* Deactivate / Activate button as required by prompt */}
                      {offer.status === 'approved' && (
                        <button
                          onClick={() => handleToggleOfferActive(offer)}
                          className={`w-full inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                            offer.isActive
                              ? 'border-slate-300 text-slate-700 hover:bg-slate-100'
                              : 'border-emerald-300 text-emerald-800 bg-emerald-50 hover:bg-emerald-100'
                          }`}
                        >
                          <Power className="w-3.5 h-3.5" />
                          <span>{offer.isActive ? 'Deactivate' : 'Reactivate'}</span>
                        </button>
                      )}

                      <button
                        onClick={() => openModal('details', offer)}
                        className="w-full inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Preview</span>
                      </button>

                      <button
                        onClick={() => openModal('edit-offer', offer)}
                        className="w-full inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl border border-slate-200 text-blue-600 hover:bg-blue-50 text-xs font-semibold"
                      >
                        <Edit className="w-3.5 h-3.5" />
                        <span>{isRejected ? 'Edit & Resubmit' : 'Edit'}</span>
                      </button>

                      <button
                        onClick={() => handleDeleteOffer(offer.id, offer.headline)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                        title="Delete offer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PROMOTION PACKAGES */}
      {activeTab === 'promotions' && (
        <div className="space-y-6">
          <div className="bg-blue-50/70 border border-blue-200 rounded-3xl p-5 sm:p-6 space-y-3">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-blue-600 text-white">
                <Sparkles className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Drive In-Store Footfall with CityDeals Promotion
                </h3>
                <p className="text-xs text-slate-600">
                  CityDeals is free for the public. We earn by helping local shops get maximum visibility.
                </p>
              </div>
            </div>

            <div className="p-3 bg-amber-100/60 border border-amber-300 rounded-xl text-xs text-amber-950 font-medium">
              <strong>Proposed Example Rates:</strong> The packages below (Boost Offer ₹199, Featured Shop ₹499,
              Homepage Spotlight ₹999) are configurable prototype examples. In production, payment provider confirmation
              is required before an admin activates your campaign.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {promotionPackages.map((pkg) => (
              <div
                key={pkg.id}
                className={`rounded-3xl p-6 bg-white border flex flex-col justify-between transition-all ${
                  pkg.recommended
                    ? 'border-2 border-blue-600 shadow-xl relative ring-4 ring-blue-50'
                    : 'border-slate-200 shadow-sm hover:shadow-md'
                }`}
              >
                {pkg.recommended && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] uppercase font-extrabold px-3 py-1 rounded-full shadow-md">
                    Recommended For Local Retailers
                  </span>
                )}

                <div className="space-y-4">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      {pkg.badge}
                    </span>
                    <h4 className="text-xl font-extrabold text-slate-900 mt-1">{pkg.name}</h4>
                    <p className="text-xs text-slate-500 mt-1">{pkg.description}</p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-baseline gap-1">
                    <span className="text-3xl font-black text-slate-900">₹{pkg.priceInr}</span>
                    <span className="text-xs text-slate-500 font-medium">/ {pkg.durationDays} days</span>
                  </div>

                  <ul className="space-y-2 pt-2 text-xs text-slate-600">
                    {pkg.features.map((feat, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => openModal('request-promotion', { packageId: pkg.id })}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all ${
                      pkg.recommended
                        ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-md'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    Select {pkg.name}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Promotion Requests List */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Your Campaign & Promotion Requests</h3>
            {promoRequests.length === 0 ? (
              <p className="text-xs text-slate-500">
                You have not submitted any promotion requests yet. Choose a package above to promote your shop or offer!
              </p>
            ) : (
              <div className="space-y-3">
                {promoRequests.map((pr) => (
                  <div
                    key={pr.id}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{pr.packageName}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                            pr.status === 'active'
                              ? 'bg-emerald-100 text-emerald-800'
                              : pr.status === 'pending_verification'
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-red-100 text-red-900'
                          }`}
                        >
                          {pr.status === 'active'
                            ? 'Active & Live'
                            : pr.status === 'pending_verification'
                            ? 'Pending Admin Verification'
                            : 'Rejected'}
                        </span>
                      </div>
                      <p className="text-slate-600 mt-0.5 font-medium">Target: {pr.offerHeadline}</p>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        Ref: {pr.transactionReference} • ₹{pr.priceInr} ({pr.durationDays} Days)
                      </p>
                      {pr.adminNotes && (
                        <p className="text-blue-700 text-[11px] mt-1 italic">Admin Note: {pr.adminNotes}</p>
                      )}
                    </div>

                    <div className="text-right text-slate-500 text-[11px]">
                      <span>Submitted: {new Date(pr.requestedAt).toLocaleDateString()}</span>
                      {pr.expiresAt && (
                        <div className="text-emerald-700 font-semibold">
                          Expires: {new Date(pr.expiresAt).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB: SHOP VERIFICATION */}
      {activeTab === 'verification' && (
        <div className="space-y-6 max-w-4xl">
          {/* Main Status Header */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-slate-100">
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border ${
                  business?.isVerified
                    ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                    : (verificationRequest?.status === 'pending' || verificationRequest?.status === 'pending_review')
                    ? 'bg-amber-50 text-amber-600 border-amber-200'
                    : 'bg-blue-50 text-blue-600 border-blue-200'
                }`}>
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-extrabold text-slate-900">
                      {business?.name || 'Local Shop'} Verification
                    </h2>
                    {business?.isVerified && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        Verified Badge Active
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Official verification badge for physical shops in Dibrugarh & Assam districts.
                  </p>
                </div>
              </div>

              {!business?.isVerified && (
                <button
                  onClick={() => openModal('request-verification')}
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm px-5 py-3 rounded-2xl shadow-lg shadow-blue-600/25 transition-all hover:scale-105 cursor-pointer shrink-0"
                >
                  <Award className="w-4 h-4 text-amber-300" />
                  <span>{verificationRequest ? 'Update / Re-apply' : 'Apply for Verification (₹499/yr)'}</span>
                </button>
              )}
            </div>

            {/* Current Status Banner */}
            <div className="pt-6">
              {business?.isVerified ? (
                <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 space-y-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-emerald-950">
                        Official Verified Shop Status Active
                      </p>
                      <p className="text-xs text-emerald-800 leading-relaxed">
                        Your physical storefront has passed official document and address moderation. The distinctive 
                        Verified Badge is displayed on your store profile and alongside all of your live offers.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                    <div className="bg-white p-3 rounded-xl border border-emerald-200">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Verification Badge</span>
                      <span className="font-extrabold text-emerald-700 flex items-center gap-1.5 mt-0.5">
                        <Award className="w-4 h-4 text-emerald-600" />
                        Verified Merchant
                      </span>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-emerald-200">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Valid Until</span>
                      <span className="font-bold text-slate-800 mt-0.5 block">
                        {business.verificationValidUntil
                          ? new Date(business.verificationValidUntil).toLocaleDateString('en-IN', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })
                          : '1 Year from Approval'}
                      </span>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-emerald-200">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Document Status</span>
                      <span className="font-bold text-slate-800 mt-0.5 block">
                        Trade License / GST Verified
                      </span>
                    </div>
                  </div>
                </div>
              ) : (verificationRequest?.status === 'pending' || verificationRequest?.status === 'pending_review') ? (
                <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 space-y-4">
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-amber-950">
                        Verification Request Under Admin Review
                      </p>
                      <p className="text-xs text-amber-800 mt-1 leading-relaxed">
                        Your application and supporting documents have been submitted to CityDeals admin moderation. 
                        Our team verifies trade licenses, GST credentials, and payment UTR records within 24 business hours.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                    <div className="bg-white p-3 rounded-xl border border-amber-200">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Payment Status</span>
                      <span className="font-bold text-amber-700 mt-0.5 block">
                        {verificationRequest.paymentStatus === 'verified' ? 'Payment Confirmed' : 'Payment Verification Pending'}
                      </span>
                      {verificationRequest.paymentReference && (
                        <span className="text-[10px] text-slate-500 font-mono mt-0.5 block">
                          UTR: {verificationRequest.paymentReference}
                        </span>
                      )}
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-amber-200">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Trade / GST #</span>
                      <span className="font-bold text-slate-800 mt-0.5 block truncate">
                        {verificationRequest.tradeLicenseNumber || verificationRequest.gstNumber || 'Uploaded on file'}
                      </span>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-amber-200">
                      <span className="text-slate-400 block text-[10px] uppercase font-bold">Submitted Date</span>
                      <span className="font-bold text-slate-800 mt-0.5 block">
                        {new Date(verificationRequest.createdAt || verificationRequest.requestedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
              ) : verificationRequest?.status === 'rejected' ? (
                <div className="p-5 rounded-2xl bg-rose-50 border border-rose-200 space-y-4">
                  <div className="flex items-start gap-3">
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-rose-950">
                        Verification Application Needs Attention
                      </p>
                      <p className="text-xs text-rose-800 mt-1 leading-relaxed">
                        {verificationRequest.adminNotes || 'The submitted business documents or payment reference could not be verified by our administrative team. Please update your documents and resubmit.'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => openModal('request-verification')}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm cursor-pointer"
                  >
                    <span>Resubmit Verification Documents</span>
                  </button>
                </div>
              ) : (
                <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-start gap-3">
                    <FileCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-slate-900">
                        Your Shop is Not Yet Verified
                      </p>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                        Unverified shops can still post offers, but verified shops earn higher trust, priority ranking, and 
                        an official green checkmark badge that tells customers your establishment is a legitimate local business.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Benefits Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                <Award className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-extrabold text-slate-900">Verified Trust Badge</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Stand out against unverified listings. Customers in Dibrugarh look for verified badges when discovering physical shops.
              </p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                <Sparkles className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-extrabold text-slate-900">Priority Placement</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Verified merchant offers and catalogs receive higher visibility in locality filters and category searches.
              </p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
                <FileCheck className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-extrabold text-slate-900">1-Year Official Coverage</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                A single affordable fee of ₹499 covers full annual verification with renewal reminders and local team support.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: BUSINESS PROFILE */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 max-w-3xl space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Physical Shop Profile</h2>
            <p className="text-xs text-slate-500">
              Set up your physical shop once. All in-store offers will be automatically grouped under this business profile.
            </p>
          </div>

          <form onSubmit={handleSaveBusiness} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Shop Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={bizForm.name}
                  onChange={(e) => setBizForm({ ...bizForm, name: e.target.value })}
                  placeholder="e.g. Heritage Silks of Assam"
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900 font-medium"
                  required
                />
              </div>

              <div>
                <label htmlFor="biz-form-category" className="block text-xs font-bold text-slate-700 mb-1">
                  Primary Category <span className="text-red-500">*</span>
                </label>
                <select
                  id="biz-form-category"
                  value={bizForm.category}
                  onChange={(e) => setBizForm({ ...bizForm, category: e.target.value })}
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900 font-medium bg-white"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.slug}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Location Hierarchy: State, District, Locality, and Full Address */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label htmlFor="biz-form-state" className="block text-xs font-bold text-slate-700 mb-1">State</label>
                <input
                  id="biz-form-state"
                  type="text"
                  value={bizForm.state}
                  disabled
                  className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 text-slate-600 font-bold"
                />
              </div>

              <div>
                <label htmlFor="biz-form-district" className="block text-xs font-bold text-slate-700 mb-1">
                  District <span className="text-red-500">*</span>
                </label>
                <select
                  id="biz-form-district"
                  value={bizForm.district}
                  onChange={(e) => handleDistrictChange(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900 font-bold bg-white"
                >
                  {['Dibrugarh', 'Tinsukia'].map((d) => (
                    <option key={d} value={d}>
                      {d} District
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="biz-form-locality" className="block text-xs font-bold text-slate-700 mb-1">
                  Town / Locality in {bizForm.district} <span className="text-red-500">*</span>
                </label>
                <select
                  id="biz-form-locality"
                  value={bizForm.locality}
                  onChange={(e) => {
                    const locName = e.target.value;
                    const locItem = getLocalitiesForDistrict(bizForm.district).find((l) => l.name === locName);
                    setBizForm((prev) => ({
                      ...prev,
                      locality: locName,
                      localityId: locItem?.id || locName.toLowerCase().replace(/[^a-z0-9]/g, '-'),
                    }));
                  }}
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900 font-medium bg-white"
                >
                  {getLocalitiesForDistrict(bizForm.district).map((loc) => (
                    <option key={loc.id || loc.name} value={loc.name}>
                      {loc.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Physical Store Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={bizForm.fullAddress || bizForm.address}
                  onChange={(e) =>
                    setBizForm((prev) => ({
                      ...prev,
                      address: e.target.value,
                      fullAddress: e.target.value,
                    }))
                  }
                  placeholder={`e.g. Shop 14, Main Market Road, ${bizForm.locality}, ${bizForm.district}`}
                  required
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Prominent Landmark
                </label>
                <input
                  type="text"
                  value={bizForm.landmark}
                  onChange={(e) => setBizForm({ ...bizForm, landmark: e.target.value })}
                  placeholder="e.g. Near Bata Showroom or Opposite Namghar"
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Opening Hours
                </label>
                <input
                  type="text"
                  value={bizForm.openingHours}
                  onChange={(e) => setBizForm({ ...bizForm, openingHours: e.target.value })}
                  placeholder="e.g. 10:00 AM – 8:30 PM (Mon–Sat)"
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Customer Phone <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  value={bizForm.phone}
                  onChange={(e) => setBizForm({ ...bizForm, phone: e.target.value })}
                  placeholder="+91 94350 00000"
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  WhatsApp Contact
                </label>
                <input
                  type="tel"
                  value={bizForm.whatsapp}
                  onChange={(e) => setBizForm({ ...bizForm, whatsapp: e.target.value })}
                  placeholder="+91 94350 00000"
                  className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Shop Specialty & What Customers Can Expect
              </label>
              <textarea
                value={bizForm.description}
                onChange={(e) => setBizForm({ ...bizForm, description: e.target.value })}
                rows={3}
                placeholder="Describe your physical store so customers know what to expect when visiting in person..."
                className="w-full text-xs rounded-xl border border-slate-300 p-2.5 text-slate-900"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md transition-colors"
              >
                Save Shop Profile
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 4: PRODUCTS & CATALOG MANAGEMENT */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
                <h3 className="font-extrabold text-base text-slate-900">My Products</h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage your shop's products, stock availability, pricing, and fulfillment options.
              </p>
            </div>

            <button
              onClick={() => openModal('post-product')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/25 transition-all cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Add Product</span>
            </button>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-blue-900">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold">Catalog Moderation & Verification Policy</p>
              <p className="text-blue-800 leading-relaxed">
                All newly submitted products require administrative approval before becoming publicly visible in the CityDeals Shopping marketplace. Once approved, local customers can discover, add to cart, and order directly from your shop.
              </p>
            </div>
          </div>

          {products.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-base text-slate-800">No products added yet</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Expand your shop reach! Add your top in-store products so local customers can order online for home delivery or store pickup.
              </p>
              <button
                onClick={() => openModal('post-product')}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs cursor-pointer inline-flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Add Product</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map((prod) => (
                <div
                  key={prod.id}
                  className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div className="p-4 space-y-3">
                    <div className="flex gap-3">
                      <img
                        src={prod.imageUrl}
                        alt={prod.name}
                        className="w-20 h-20 rounded-xl object-cover bg-slate-100 shrink-0 border border-slate-200"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded capitalize ${
                              prod.status === 'approved'
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                : prod.status === 'pending'
                                ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                : 'bg-rose-100 text-rose-800 border border-rose-200'
                            }`}
                          >
                            {prod.status === 'approved'
                              ? 'Approved'
                              : prod.status === 'pending'
                              ? 'Pending Approval'
                              : 'Rejected'}
                          </span>
                          <span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-1.5 py-0.5 rounded capitalize">
                            {prod.category}
                          </span>
                        </div>

                        <h4 className="font-extrabold text-sm text-slate-900 mt-1 truncate" title={prod.name}>
                          {prod.name}
                        </h4>

                        {/* Associated Shop Name & Location Display */}
                        <div className="flex items-center gap-1 text-[11px] text-slate-500 font-medium mt-0.5">
                          <Store className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate">
                            {prod.shopName || business?.name} • {prod.locality || business?.locality}, {prod.city || business?.district || business?.city}
                          </span>
                        </div>

                        <div className="flex items-baseline gap-1.5 mt-1">
                          <span className="font-black text-sm text-slate-900">
                            ₹{prod.price.toLocaleString('en-IN')}
                          </span>
                          {prod.originalPrice && (
                            <span className="text-[11px] text-slate-400 line-through">
                              ₹{prod.originalPrice.toLocaleString('en-IN')}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {prod.description}
                    </p>

                    {/* Delivery & Pickup Badges */}
                    <div className="flex items-center gap-1.5 flex-wrap pt-1">
                      {prod.deliveryAvailable !== false && (
                        <span className="inline-flex items-center gap-1 text-[10px] bg-blue-50 text-blue-700 font-bold px-2 py-0.5 rounded-md border border-blue-200">
                          <Truck className="w-3 h-3" /> Delivery
                        </span>
                      )}
                      {prod.pickupAvailable !== false && (
                        <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-md border border-emerald-200">
                          <Store className="w-3 h-3" /> Pickup
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400 text-[11px] font-bold">In Stock:</span>
                        <button
                          onClick={() => handleToggleProductStock(prod)}
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-black cursor-pointer transition-colors ${
                            prod.inStock
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                              : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                          }`}
                        >
                          {prod.inStock ? 'Yes' : 'Out of Stock'}
                        </button>
                      </div>

                      <span className="text-slate-400 text-[11px] font-medium">
                        Qty: {prod.stockQuantity}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-500 font-medium">
                      {prod.viewsCount || 0} views
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => openModal('edit-product', prod)}
                        className="px-2.5 py-1 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg flex items-center gap-1 cursor-pointer"
                      >
                        <Edit className="w-3 h-3 text-slate-500" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(prod.id, prod.name)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                        title="Delete product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: CUSTOMER ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <PackageCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="font-extrabold text-base text-slate-900">Incoming Customer Orders</h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage fulfillment for Home Delivery & Store Pickup orders across Dibrugarh.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl">
                Total Orders: <strong className="text-slate-900">{orders.length}</strong>
              </span>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
                Revenue: ₹{orders.filter((o) => o.status === 'delivered').reduce((s, o) => s + o.totalAmount, 0).toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {orders.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500 space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <PackageCheck className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-base text-slate-800">No customer orders yet</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Orders placed for your shop products will appear here with customer contact information, item lists, and delivery addresses.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((ord) => {
                const customerCleanPhone = ord.customerPhone.replace(/[^0-9]/g, '');

                return (
                  <div
                    key={ord.id}
                    className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-xs font-black text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                            #{ord.orderNumber}
                          </span>
                          <span className="text-xs text-slate-400 font-medium">
                            {new Date(ord.createdAt).toLocaleDateString('en-IN', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 uppercase">
                            {ord.fulfillmentType === 'delivery' ? 'Home Delivery' : 'Store Pickup'}
                          </span>
                        </div>
                        <h4 className="font-black text-sm sm:text-base text-slate-900 mt-1">
                          {ord.customerName} • <span className="font-mono">{ord.customerPhone}</span>
                        </h4>
                      </div>

                      {/* Status Update Dropdown */}
                      <div className="flex items-center gap-2">
                        <label htmlFor={`order-status-${ord.id}`} className="text-xs font-bold text-slate-600">
                          Order Status:
                        </label>
                        <select
                          id={`order-status-${ord.id}`}
                          value={ord.status}
                          onChange={(e) => handleUpdateOrderStatus(ord.id, e.target.value as OrderStatus)}
                          className="text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-300 bg-slate-50 focus:outline-none cursor-pointer"
                        >
                          <option value="pending">Pending</option>
                          <option value="accepted">Accepted</option>
                          <option value="preparing">Preparing Items</option>
                          <option value="ready_for_pickup">Ready for Pickup</option>
                          <option value="out_for_delivery">Out for Delivery</option>
                          <option value="delivered">Delivered / Completed</option>
                          <option value="rejected">Rejected / Declined</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Delivery & Customer Notes */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div>
                        <span className="font-bold text-slate-400 uppercase text-[10px] block">
                          Delivery Address
                        </span>
                        <p className="text-slate-800 font-medium mt-0.5">
                          {ord.deliveryAddress || 'Store Pickup at Shop'}
                        </p>
                      </div>
                      <div>
                        <span className="font-bold text-slate-400 uppercase text-[10px] block">
                          Customer Instructions
                        </span>
                        <p className="text-slate-800 font-medium mt-0.5 italic">
                          {ord.customerNotes || 'None'}
                        </p>
                      </div>
                    </div>

                    {/* Items table */}
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                        Ordered Items ({ord.items.length})
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {ord.items.map((item, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/80 text-xs"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              {item.imageUrl && (
                                <img
                                  src={item.imageUrl}
                                  alt={item.productName}
                                  className="w-8 h-8 rounded object-cover bg-slate-200 shrink-0"
                                />
                              )}
                              <span className="font-bold text-slate-900 truncate">
                                {item.productName} × {item.quantity}
                              </span>
                            </div>
                            <span className="font-black text-slate-800 shrink-0 ml-2">
                              ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Bottom strip: Payment, Total, Contact Actions */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-100">
                      <div className="text-xs">
                        <span className="text-slate-500 font-medium">Total: </span>
                        <span className="text-base font-black text-blue-700">
                          ₹{ord.totalAmount.toLocaleString('en-IN')}
                        </span>
                        <span className="text-[11px] text-emerald-700 font-bold ml-2">
                          ({ord.fulfillmentType === 'delivery' ? 'Cash on Delivery' : 'Pay at Shop'})
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={`https://wa.me/91${customerCleanPhone.slice(-10)}?text=${encodeURIComponent(
                            `Hello ${ord.customerName}, this is ${ord.shopName} regarding your CityDeals order #${ord.orderNumber}.`
                          )}`}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>WhatsApp Customer</span>
                        </a>

                        <a
                          href={`tel:${ord.customerPhone}`}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-800 text-xs font-bold transition-colors cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5 text-blue-600" />
                          <span>Call</span>
                        </a>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
