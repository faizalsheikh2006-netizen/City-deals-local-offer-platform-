import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import { Product } from '../types/index';
import {
  X,
  Store,
  MapPin,
  ShoppingBag,
  Plus,
  Minus,
  MessageCircle,
  Phone,
  Truck,
  ShieldCheck,
  Play,
  CheckCircle2,
  ChevronRight,
  Share2,
} from 'lucide-react';

export const ProductDetailsModal: React.FC = () => {
  const {
    modalData,
    closeModal,
    addToCart,
    forceAddToCart,
    setSelectedShopProfileId,
    openModal,
    showToast,
  } = useApp();

  const initialProduct: Product = modalData;
  const [product, setProduct] = useState<Product>(initialProduct);
  const [otherProducts, setOtherProducts] = useState<Product[]>([]);
  const [quantity, setQuantity] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<'photo' | 'video'>('photo');
  const [conflictShop, setConflictShop] = useState<string | null>(null);

  useEffect(() => {
    if (initialProduct?.id) {
      setProduct(initialProduct);
      setQuantity(1);
      setActiveTab('photo');
      api.getProductById(initialProduct.id)
        .then((res) => {
          if (res.product) setProduct(res.product);
          const related = res.otherProducts || res.otherShopProducts;
          if (related) setOtherProducts(related);
        })
        .catch((err) => {
          console.warn('Could not load extra product details:', err);
        });
    }
  }, [initialProduct?.id]);

  if (!product) return null;

  const discountPercent =
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null;

  const handleAdd = () => {
    const res = addToCart(product, quantity);
    if (!res.success && res.conflictShopName) {
      setConflictShop(res.conflictShopName);
    } else if (res.success) {
      closeModal();
    }
  };

  const handleWhatsAppInquiry = () => {
    const phone =
      product.contactWhatsapp ||
      product.shopWhatsapp ||
      product.contactPhone ||
      product.shopPhone ||
      '919435000000';
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const message = encodeURIComponent(
      `Hello ${product.shopName}, I found "${product.name}" (₹${product.price}) on CityDeals Dibrugarh. Is this currently available for delivery or store pickup?`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  const handleShareProduct = () => {
    if (navigator.share) {
      navigator.share({
        title: `${product.name} - CityDeals Shopping Dibrugarh`,
        text: `Check out ${product.name} for ₹${product.price} at ${product.shopName} on CityDeals Shopping Dibrugarh!`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      showToast('Product link copied to clipboard!', 'success');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 relative animate-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-3.5 right-3.5 z-20 w-9 h-9 rounded-full bg-slate-900/60 hover:bg-slate-900/80 text-white flex items-center justify-center backdrop-blur-md cursor-pointer transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Media Section (Image or Video) */}
        <div className="relative aspect-video sm:aspect-21/9 w-full bg-slate-950 overflow-hidden">
          {activeTab === 'video' && product.videoUrl ? (
            <video
              src={product.videoUrl}
              controls
              autoPlay
              loop
              playsInline
              className="w-full h-full object-contain"
            />
          ) : (
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          )}

          {/* Media tab switchers if video exists */}
          {product.videoUrl && (
            <div className="absolute bottom-3 right-3 flex items-center gap-2 z-10">
              <button
                onClick={() => setActiveTab('photo')}
                className={`px-3 py-1 rounded-lg text-xs font-bold backdrop-blur-md transition-all cursor-pointer ${
                  activeTab === 'photo'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-900/70 text-slate-200 hover:bg-slate-900'
                }`}
              >
                Photo
              </button>
              <button
                onClick={() => setActiveTab('video')}
                className={`px-3 py-1 rounded-lg text-xs font-bold backdrop-blur-md flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'video'
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-900/70 text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Play className="w-3 h-3 fill-white" />
                <span>Video Reel</span>
              </button>
            </div>
          )}

          {/* Badges Overlay */}
          <div className="absolute top-3.5 left-3.5 flex flex-col gap-1.5 z-10">
            {discountPercent && (
              <span className="bg-rose-600 text-white text-xs font-black px-2.5 py-1 rounded-lg shadow-md">
                {discountPercent}% OFF
              </span>
            )}
            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-lg shadow-md ${
                product.inStock ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
              }`}
            >
              {product.inStock ? 'In Stock' : 'Out of Stock'}
            </span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-6">
          {/* Shop Header Pill */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="font-extrabold text-sm text-slate-900">{product.shopName}</h4>
                  <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                </div>
                <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>{product.locality}, Dibrugarh</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setSelectedShopProfileId(product.businessId);
                closeModal();
              }}
              className="text-xs font-extrabold text-blue-700 hover:text-blue-900 bg-white px-3 py-1.5 rounded-xl border border-blue-200 shrink-0 self-start sm:self-auto cursor-pointer"
            >
              View Shop Profile & Items →
            </button>
          </div>

          {/* Product Header */}
          <div>
            <div className="flex items-start justify-between gap-4">
              <h2 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                {product.name}
              </h2>
              <button
                onClick={handleShareProduct}
                className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 transition-colors cursor-pointer"
                title="Share product"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>

            {/* Pricing */}
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900">
                ₹{product.price.toLocaleString('en-IN')}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-slate-600 line-through">
                  ₹{product.originalPrice.toLocaleString('en-IN')}
                </span>
              )}
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                Inclusive of all taxes
              </span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-600 mb-1.5">
              Description & Specifications
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
              {product.description}
            </p>
          </div>

          {/* Fulfillment info */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5">
              <Truck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-extrabold text-slate-900">Home Delivery</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Across Dibrugarh town • Pay on Delivery</p>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2.5">
              <Store className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-extrabold text-slate-900">Store Pickup</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Pick up directly from {product.locality} shop</p>
              </div>
            </div>
          </div>

          {/* Merchant Inquiries */}
          <div className="flex flex-wrap items-center gap-2 pt-2">
            <button
              onClick={handleWhatsAppInquiry}
              className="flex-1 min-w-[140px] py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Ask on WhatsApp</span>
            </button>
            {(product.contactPhone || product.shopPhone) && (
              <a
                href={`tel:${product.contactPhone || product.shopPhone}`}
                className="py-2 px-4 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-4 h-4 text-blue-600" />
                <span>Call Shop</span>
              </a>
            )}
          </div>

          {/* Add to Cart Actions Footer */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
            {/* Quantity Stepper */}
            <div className="flex items-center gap-2 border border-slate-200 rounded-xl p-1 bg-slate-50">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-8 h-8 rounded-lg bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold cursor-pointer transition-colors shadow-2xs"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="w-8 text-center text-sm font-extrabold text-slate-900">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="w-8 h-8 rounded-lg bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center font-bold cursor-pointer transition-colors shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Add Button */}
            <button
              onClick={handleAdd}
              disabled={!product.inStock}
              className={`flex-1 py-3 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                product.inStock
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/30'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>
                {product.inStock ? `Add to Cart • ₹${(product.price * quantity).toLocaleString('en-IN')}` : 'Out of Stock'}
              </span>
            </button>
          </div>

          {/* More from this Shop */}
          {otherProducts.length > 0 && (
            <div className="pt-4 border-t border-slate-100">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-600 mb-3">
                More from {product.shopName}
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {otherProducts.slice(0, 2).map((other) => (
                  <div
                    key={other.id}
                    onClick={() => {
                      setProduct(other);
                      setQuantity(1);
                      setActiveTab('photo');
                    }}
                    className="flex items-center gap-2.5 p-2 rounded-xl border border-slate-200 hover:border-blue-400 transition-all cursor-pointer bg-white group"
                  >
                    <img
                      src={other.imageUrl}
                      alt={other.name}
                      className="w-12 h-12 rounded-lg object-cover bg-slate-100 shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate">
                        {other.name}
                      </p>
                      <p className="text-xs font-black text-slate-800">
                        ₹{other.price.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Cross-Shop Conflict Sub-Modal */}
      {conflictShop && (
        <div className="fixed inset-0 z-60 bg-slate-950/80 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
              <Store className="w-6 h-6" />
            </div>
            <h3 className="text-base font-extrabold text-slate-900">Replace current cart?</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Your cart has items from <strong>{conflictShop}</strong>. CityDeals fulfills orders directly with one shop per delivery.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setConflictShop(null)}
                className="py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700"
              >
                Keep Cart
              </button>
              <button
                onClick={() => {
                  forceAddToCart(product, quantity);
                  setConflictShop(null);
                  closeModal();
                }}
                className="py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-extrabold text-white"
              >
                Replace Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
