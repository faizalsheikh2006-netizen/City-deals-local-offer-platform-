import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../api/client';
import {
  X,
  Lock,
  Mail,
  User as UserIcon,
  Phone,
  Store,
  Compass,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  ArrowRight,
  Info,
  Gift,
  Eye,
  EyeOff,
  RefreshCw,
  ArrowLeft,
} from 'lucide-react';
import { UserRole } from '../types/index';

type AuthTab = 'login' | 'register' | 'forgot-password' | 'reset-password';

export const AuthModal: React.FC = () => {
  const { modalType, modalData, closeModal, login, loginWithGoogle, sendPasswordReset, register, showToast, activeReferralCode, referrerInfo } = useApp();

  const getInitialTab = (): AuthTab => {
    if (modalData?.tab === 'forgot-password') return 'forgot-password';
    if (modalData?.tab === 'reset-password') return 'reset-password';
    if (modalData?.tab === 'register') return 'register';
    return 'login';
  };

  const [tab, setTab] = useState<AuthTab>(getInitialTab());

  // Form states - Login
  const [loginEmail, setLoginEmail] = useState(modalData?.email || '');
  const [loginPassword, setLoginPassword] = useState('');

  // Form states - Register
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRole, setRegRole] = useState<'public' | 'merchant'>(modalData?.defaultRole === 'merchant' ? 'merchant' : 'public');
  const [regReferralCode, setRegReferralCode] = useState<string>(() => {
    return activeReferralCode || '';
  });

  // Form states - Forgot Password
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetSentInfo, setResetSentInfo] = useState<{
    email: string;
    resetLink: string;
    resetToken: string;
    expiresInMinutes: number;
  } | null>(null);

  // Form states - Reset Password
  const [resetToken, setResetToken] = useState(modalData?.token || '');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [tokenVerifying, setTokenVerifying] = useState(false);
  const [tokenVerifiedEmail, setTokenVerifiedEmail] = useState<string | null>(null);
  const [tokenError, setTokenError] = useState<string | null>(null);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Synchronize modalData changes
  useEffect(() => {
    if (modalData?.tab) {
      setTab(modalData.tab);
    }
    if (modalData?.defaultRole === 'merchant' || modalData?.defaultRole === 'public') {
      setRegRole(modalData.defaultRole);
    }
    if (modalData?.token) {
      setResetToken(modalData.token);
    }
    if (modalData?.email) {
      setLoginEmail(modalData.email);
      setForgotEmail(modalData.email);
    }
  }, [modalData]);

  // Verify Reset Token when entering reset-password screen
  useEffect(() => {
    if (tab === 'reset-password' && resetToken) {
      let isMounted = true;
      setTokenVerifying(true);
      setTokenError(null);
      setErrorMsg(null);

      api.verifyResetToken(resetToken)
        .then((res) => {
          if (isMounted) {
            setTokenVerifiedEmail(res.email);
            setTokenVerifying(false);
          }
        })
        .catch((err: any) => {
          if (isMounted) {
            setTokenError(err.message || 'This password reset link is invalid or has expired.');
            setTokenVerifying(false);
          }
        });

      return () => {
        isMounted = false;
      };
    }
  }, [tab, resetToken]);

  if (modalType !== 'auth') return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!loginEmail || !loginPassword) {
      setErrorMsg('Please enter both your email address and password.');
      return;
    }

    try {
      setIsSubmitting(true);
      await login(loginEmail, loginPassword);
    } catch (err: any) {
      setErrorMsg(err.message || 'Invalid email or password.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!regName.trim() || regName.trim().length < 2) {
      setErrorMsg('Full name must be at least 2 characters.');
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setErrorMsg('Please provide a valid email address.');
      return;
    }
    if (!regPassword || regPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    try {
      setIsSubmitting(true);
      await register(regName, regEmail, regPassword, regRole, regPhone, regReferralCode.trim().toUpperCase() || undefined);
    } catch (err: any) {
      setErrorMsg(err.message || 'Registration failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!forgotEmail.trim() || !forgotEmail.includes('@')) {
      setErrorMsg('Please enter a valid registered email address.');
      return;
    }

    try {
      setIsSubmitting(true);
      // Attempt Firebase / backend password recovery
      try {
        await sendPasswordReset(forgotEmail.trim());
      } catch (err: any) {
        console.warn('Firebase sendPasswordReset fallback:', err?.message);
      }

      // Generate verification link token via API for immediate on-screen access & verification
      const res = await api.requestPasswordReset(forgotEmail.trim()).catch(() => null);
      if (res) {
        setResetSentInfo({
          email: res.email,
          resetLink: res.resetLink,
          resetToken: res.resetToken,
          expiresInMinutes: res.expiresInMinutes || 60,
        });
      } else {
        setResetSentInfo({
          email: forgotEmail.trim(),
          resetLink: `${window.location.origin}/?tab=reset-password`,
          resetToken: 'firebase-auth-flow',
          expiresInMinutes: 60,
        });
      }
      showToast('Password reset link generated and dispatched!', 'success');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to request password reset. Please check your connection.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!newPassword || newPassword.length < 6) {
      setErrorMsg('New password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg('Passwords do not match. Please ensure both fields are identical.');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await api.resetPassword(resetToken, newPassword);
      setResetSuccessMessage(res.message);
      showToast('Password updated successfully! Please sign in.', 'success');

      // Autofill email in login form
      if (tokenVerifiedEmail || forgotEmail) {
        setLoginEmail(tokenVerifiedEmail || forgotEmail);
      }
      setLoginPassword('');

      // Redirect to login tab after brief pause
      setTimeout(() => {
        setTab('login');
        setResetSuccessMessage(null);
        setResetToken('');
        setNewPassword('');
        setConfirmPassword('');
      }, 1800);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to reset password. The reset link may have expired.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white p-5 relative">
          <button
            onClick={closeModal}
            className="absolute top-4 right-4 p-1.5 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5 mb-1.5">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center border border-white/20 shrink-0">
              {tab === 'reset-password' ? (
                <ShieldCheck className="w-5 h-5 text-emerald-300" />
              ) : tab === 'forgot-password' ? (
                <KeyRound className="w-5 h-5 text-amber-300" />
              ) : (
                <KeyRound className="w-5 h-5 text-amber-300" />
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight">
                {tab === 'forgot-password'
                  ? 'Forgot Password'
                  : tab === 'reset-password'
                  ? 'Set New Password'
                  : 'CityDeals Account'}
              </h2>
              <p className="text-xs text-blue-200">
                {tab === 'forgot-password'
                  ? 'Recover your account credentials'
                  : tab === 'reset-password'
                  ? 'Choose a secure password'
                  : 'Dibrugarh Local Shop Directory'}
              </p>
            </div>
          </div>

          {/* Navigation Controls in Header */}
          {tab === 'login' || tab === 'register' ? (
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-black/20 rounded-xl mt-4">
              <button
                onClick={() => {
                  setTab('login');
                  setErrorMsg(null);
                }}
                className={`py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  tab === 'login'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-white/80 hover:text-white hover:bg-white/5'
                }`}
              >
                Sign In
              </button>
              <button
                onClick={() => {
                  setTab('register');
                  setErrorMsg(null);
                }}
                className={`py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  tab === 'register'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-white/80 hover:text-white hover:bg-white/5'
                }`}
              >
                Create Account
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/10">
              <span className="text-xs text-blue-100 font-medium">
                {tab === 'forgot-password' ? 'Password Recovery' : 'Account Security'}
              </span>
              <button
                type="button"
                onClick={() => {
                  setTab('login');
                  setErrorMsg(null);
                  setResetSentInfo(null);
                  setTokenError(null);
                }}
                className="text-xs text-amber-300 hover:text-white font-bold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Sign In</span>
              </button>
            </div>
          )}
        </div>

        {/* Body */}
        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div>
                <p className="font-semibold">Notice</p>
                <p className="leading-relaxed">{errorMsg}</p>
              </div>
            </div>
          )}

          {/* TAB 1: LOGIN */}
          {tab === 'login' && (
            <>
              {/* Unified Sign-In Info Banner */}
              <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl text-xs text-blue-900 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  <strong>Unified Sign-In:</strong> Whether you are a Customer, Merchant, or Administrator, sign in using your account credentials below. You will be automatically routed to your dashboard.
                </p>
              </div>

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="e.g. heritage.silks@gmail.com"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Enter account password"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                    />
                  </div>
                </div>

                {/* 1. FORGOT PASSWORD LINK BELOW PASSWORD FIELD */}
                <div className="flex items-center justify-between pt-0.5">
                  <span className="text-[11px] text-slate-500">Trouble remembering?</span>
                  <button
                    type="button"
                    onClick={() => {
                      setTab('forgot-password');
                      setErrorMsg(null);
                      setForgotEmail(loginEmail || '');
                      setResetSentInfo(null);
                    }}
                    className="text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors cursor-pointer py-1 px-1 -mr-1"
                  >
                    Forgot Password?
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-sm shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                      <span>Signing in...</span>
                    </>
                  ) : (
                    <>
                      <span>Sign In to Account</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                <div className="relative flex py-1 items-center">
                  <div className="grow border-t border-slate-200"></div>
                  <span className="shrink mx-3 text-slate-400 text-[11px] uppercase tracking-wider font-semibold">Or continue with</span>
                  <div className="grow border-t border-slate-200"></div>
                </div>

                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={async () => {
                    try {
                      setIsSubmitting(true);
                      setErrorMsg(null);
                      await loginWithGoogle();
                    } catch (err: any) {
                      setErrorMsg(err.message || 'Google sign-in could not be completed.');
                    } finally {
                      setIsSubmitting(false);
                    }
                  }}
                  className="w-full py-2.5 px-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-50 text-slate-700 font-semibold text-sm shadow-xs flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Sign In with Google</span>
                </button>
              </form>
            </>
          )}

          {/* TAB 2: REGISTER */}
          {tab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Select Account Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRegRole('public')}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      regRole === 'public'
                        ? 'border-blue-600 bg-blue-50/70 text-blue-900 ring-2 ring-blue-500/20'
                        : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      <Compass className="w-3.5 h-3.5 text-blue-600" />
                      <span>Customer</span>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                      Discover local deals, shop & earn rewards
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRegRole('merchant')}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      regRole === 'merchant'
                        ? 'border-blue-600 bg-blue-50/70 text-blue-900 ring-2 ring-blue-500/20'
                        : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      <Store className="w-3.5 h-3.5 text-blue-600" />
                      <span>Merchant</span>
                    </div>
                    <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                      Manage shop profile, catalogue & offers
                    </p>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="e.g. Manash Baruah"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="e.g. manash.retail@gmail.com"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Password (Min 6 Characters)
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Choose a strong password"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Mobile Phone (Optional)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="+91 94350 00000"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Referral Code (Optional)
                </label>
                <div className="relative">
                  <Gift className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={regReferralCode}
                    onChange={(e) => setRegReferralCode(e.target.value.toUpperCase())}
                    placeholder="e.g. DIB-MANASH-A1B2"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-mono tracking-wider uppercase focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 placeholder:normal-case placeholder:font-sans placeholder:tracking-normal"
                  />
                </div>
                <p className="text-[10px] text-slate-500 mt-1">
                  If someone invited you, enter their referral code to attribute ambassador community credit.
                </p>
              </div>

              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600 flex items-start gap-2">
                <Info className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                <span>
                  Admin privileges cannot be self-registered and require direct authorization. All new shopkeeper offers default to Pending until approved by CityDeals moderation.
                </span>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-sm shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                    <span>Creating account...</span>
                  </>
                ) : (
                  <>
                    <span>Register & Continue</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="relative flex py-1 items-center">
                <div className="grow border-t border-slate-200"></div>
                <span className="shrink mx-3 text-slate-400 text-[11px] uppercase tracking-wider font-semibold">Or join with</span>
                <div className="grow border-t border-slate-200"></div>
              </div>

              <button
                type="button"
                disabled={isSubmitting}
                onClick={async () => {
                  try {
                    setIsSubmitting(true);
                    setErrorMsg(null);
                    await loginWithGoogle();
                  } catch (err: any) {
                    setErrorMsg(err.message || 'Google sign-up could not be completed.');
                  } finally {
                    setIsSubmitting(false);
                  }
                }}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-50 text-slate-700 font-semibold text-sm shadow-xs flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Continue with Google</span>
              </button>
            </form>
          )}

          {/* TAB 3: FORGOT PASSWORD */}
          {tab === 'forgot-password' && (
            <div>
              {!resetSentInfo ? (
                <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
                  <div className="p-3 bg-blue-50/70 border border-blue-100 rounded-xl text-xs text-blue-900 flex items-start gap-2.5">
                    <KeyRound className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">
                      Enter the email address registered to your CityDeals account. We will dispatch a secure 60-minute password recovery link.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Your Registered Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="e.g. heritage.silks@gmail.com"
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-sm shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                        <span>Sending recovery link...</span>
                      </>
                    ) : (
                      <>
                        <Mail className="w-4 h-4" />
                        <span>Send Password Reset Email</span>
                      </>
                    )}
                  </button>

                  <div className="pt-2 text-center">
                    <button
                      type="button"
                      onClick={() => {
                        setTab('login');
                        setErrorMsg(null);
                      }}
                      className="text-xs font-semibold text-slate-600 hover:text-blue-600 cursor-pointer transition-colors"
                    >
                      Remembered your password? Sign In
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-bold text-sm text-emerald-950">Password Reset Email Dispatched!</h4>
                        <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
                          We have sent a secure password reset link to{' '}
                          <strong className="font-mono text-emerald-950">{resetSentInfo.email}</strong>.
                          For your security, this link is valid for {resetSentInfo.expiresInMinutes} minutes.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-2">
                    <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                      <Info className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                      <span>Direct Recovery Link:</span>
                    </div>
                    <div className="text-[11px] text-slate-600 font-mono break-all bg-white p-2.5 rounded-lg border border-slate-200 select-all">
                      {resetSentInfo.resetLink}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Tap below to set your new password directly:
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setResetToken(resetSentInfo.resetToken);
                      setTab('reset-password');
                      setErrorMsg(null);
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>Proceed to Set New Password</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTab('login');
                      setErrorMsg(null);
                      setResetSentInfo(null);
                    }}
                    className="w-full py-2 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Return to Sign In
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: RESET PASSWORD */}
          {tab === 'reset-password' && (
            <div>
              {tokenVerifying ? (
                <div className="py-8 text-center space-y-3">
                  <RefreshCw className="w-6 h-6 text-blue-600 animate-spin mx-auto" />
                  <p className="text-xs text-slate-600 font-semibold">Validating security token...</p>
                </div>
              ) : tokenError ? (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-bold text-sm text-rose-950">Reset Link Expired or Invalid</h4>
                        <p className="text-xs text-rose-800 mt-1 leading-relaxed">{tokenError}</p>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setTab('forgot-password');
                      setTokenError(null);
                      setErrorMsg(null);
                    }}
                    className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>Request a New Reset Link</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTab('login');
                      setTokenError(null);
                      setErrorMsg(null);
                    }}
                    className="w-full py-2 px-4 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Back to Sign In
                  </button>
                </div>
              ) : resetSuccessMessage ? (
                <div className="py-6 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h4 className="font-bold text-slate-900 text-base">Password Reset Successfully!</h4>
                  <p className="text-xs text-slate-600 max-w-xs mx-auto leading-relaxed">
                    {resetSuccessMessage} Redirecting you to the Sign In screen...
                  </p>
                </div>
              ) : (
                <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
                  {tokenVerifiedEmail && (
                    <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs flex items-center justify-between">
                      <span className="text-slate-500 font-medium">Resetting password for:</span>
                      <span className="font-bold font-mono text-slate-900 truncate max-w-[200px]">
                        {tokenVerifiedEmail}
                      </span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      New Password (Min 6 Characters)
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        minLength={6}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Enter new account password"
                        className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                        aria-label="Toggle password visibility"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Confirm New Password
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        minLength={6}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Re-enter new password"
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-sm shadow-md shadow-blue-600/20 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                        <span>Saving new password...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Update Password & Continue</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Account Security Notice */}
          <div className="mt-6 pt-4 border-t border-slate-100 text-center">
            <p className="text-[11px] text-slate-500">
              CityDeals accounts are protected with salted cryptographic scrypt hashing. Browsing verified local shop deals is always free without mandatory login.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
