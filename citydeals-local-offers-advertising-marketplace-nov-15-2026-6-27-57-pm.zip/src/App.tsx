import React, { useState, useEffect, useCallback, useMemo, Suspense, lazy } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { CategoryChips } from './components/CategoryChips';
import { SpotlightSection } from './components/SpotlightSection';
import { OfferCard } from './components/OfferCard';
import { ShopCard } from './components/ShopCard';
import { LiveRadar } from './components/LiveRadar';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';
import { api } from './api/client';
import { trackPageView } from './lib/analytics';
import { Offer, ShopWithOffers } from './types/index';
import { requestUserLocation } from './utils/geo';
import {
  Store,
  Bookmark,
  ArrowUpDown,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  MapPin,
  Eye,
  ShieldCheck,
} from 'lucide-react';

// Code-split secondary portals, map library (Leaflet), and modals to minimize initial JS payload
const InteractiveMap = lazy(() =>
  import('./components/InteractiveMap').then((m) => ({ default: m.InteractiveMap }))
);
const ShoppingMarketplace = lazy(() =>
  import('./components/ShoppingMarketplace').then((m) => ({ default: m.ShoppingMarketplace }))
);
const ShopkeeperPortal = lazy(() =>
  import('./components/ShopkeeperPortal').then((m) => ({ default: m.ShopkeeperPortal }))
);
const AdminPortal = lazy(() =>
  import('./components/AdminPortal').then((m) => ({ default: m.AdminPortal }))
);
const SuggestDealModal = lazy(() =>
  import('./components/SuggestDealModal').then((m) => ({ default: m.SuggestDealModal }))
);
const OfferDetailsModal = lazy(() =>
  import('./components/OfferDetailsModal').then((m) => ({ default: m.OfferDetailsModal }))
);
const ReportModal = lazy(() =>
  import('./components/ReportModal').then((m) => ({ default: m.ReportModal }))
);
const OfferFormModal = lazy(() =>
  import('./components/OfferFormModal').then((m) => ({ default: m.OfferFormModal }))
);
const PromotionRequestModal = lazy(() =>
  import('./components/PromotionRequestModal').then((m) => ({ default: m.PromotionRequestModal }))
);
const VerificationRequestModal = lazy(() =>
  import('./components/VerificationRequestModal').then((m) => ({ default: m.VerificationRequestModal }))
);
const InfoModals = lazy(() =>
  import('./components/InfoModals').then((m) => ({ default: m.InfoModals }))
);
const AuthModal = lazy(() =>
  import('./components/AuthModal').then((m) => ({ default: m.AuthModal }))
);
const ShareModal = lazy(() =>
  import('./components/ShareModal').then((m) => ({ default: m.ShareModal }))
);
const ReferralModal = lazy(() =>
  import('./components/ReferralModal').then((m) => ({ default: m.ReferralModal }))
);
const ProductDetailsModal = lazy(() =>
  import('./components/ProductDetailsModal').then((m) => ({ default: m.ProductDetailsModal }))
);
const CartModal = lazy(() =>
  import('./components/CartModal').then((m) => ({ default: m.CartModal }))
);
const CheckoutModal = lazy(() =>
  import('./components/CheckoutModal').then((m) => ({ default: m.CheckoutModal }))
);
const OrderDetailsModal = lazy(() =>
  import('./components/OrderDetailsModal').then((m) => ({ default: m.OrderDetailsModal }))
);
const OrderHistoryModal = lazy(() =>
  import('./components/OrderHistoryModal').then((m) => ({ default: m.OrderHistoryModal }))
);
const ProductFormModal = lazy(() =>
  import('./components/ProductFormModal').then((m) => ({ default: m.ProductFormModal }))
);

const ViewFallback: React.FC = () => (
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3 animate-pulse">
      <div className="w-10 h-10 rounded-xl bg-blue-100 mx-auto" />
      <div className="h-4 w-48 bg-slate-200 rounded mx-auto" />
      <div className="h-3 w-64 bg-slate-100 rounded mx-auto" />
    </div>
  </div>
);

const MainContent: React.FC = () => {
  const {
    activeView,
    role,
    effectiveRole,
    user,
    adminPreviewMode,
    setAdminPreviewMode,
    selectedCity,
    selectedDistrict,
    setSelectedDistrict,
    selectedLocality,
    setSelectedLocality,
    savedOfferIds,
    savedOffers,
    isOffline,
    isSyncingSavedOffers,
    modalType,
    modalData,
    closeModal,
    toast,
    showToast,
    refreshKey,
    switchRole,
    setActiveView,
    openModal,
    cities,
    categories,
  } = useApp();

  // Public offers & shops state
  const [offers, setOffers] = useState<Offer[]>([]);
  const [primaryOffers, setPrimaryOffers] = useState<Offer[]>([]);
  const [nearbyOffers, setNearbyOffers] = useState<Offer[]>([]);
  const [districtWideOffers, setDistrictWideOffers] = useState<Offer[]>([]);
  const [shops, setShops] = useState<ShopWithOffers[]>([]);
  const [viewMode, setViewMode] = useState<'offers' | 'shops' | 'map'>('offers');
  const [isLoading, setIsLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Search & filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [showSavedOnly, setShowSavedOnly] = useState(false);

  // GPS Geolocation state
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [distanceFilter, setDistanceFilter] = useState<number | null>(null);

  const handleEnableLocation = useCallback(async () => {
    setIsLocating(true);
    setLocationError(null);
    try {
      const loc = await requestUserLocation();
      setUserLocation(loc);
      setSortBy('nearest');
    } catch (err: any) {
      setLocationError(err.message || 'Unable to access your GPS position');
    } finally {
      setIsLocating(false);
    }
  }, []);

  const handleNavigateHome = useCallback(() => {
    setActiveView('browse');
    setShowSavedOnly(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [setActiveView]);

  const handleNavigateOffers = useCallback(() => {
    setActiveView('browse');
    setViewMode('offers');
    setShowSavedOnly(false);
    setTimeout(() => {
      const el = document.getElementById('offers-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.scrollTo({ top: 380, behavior: 'smooth' });
      }
    }, 50);
  }, [setActiveView]);

  // Load public approved offers and shops from server
  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        setFetchError(null);
        const [offersRes, shopsRes] = await Promise.all([
          api.getOffers({
            district: selectedDistrict || selectedCity,
            city: selectedDistrict || selectedCity,
            category: selectedCategory !== 'all' ? selectedCategory : undefined,
            locality: selectedLocality !== 'all' ? selectedLocality : undefined,
            search: searchQuery.trim() !== '' ? searchQuery.trim() : undefined,
            sort: sortBy,
            userLat: userLocation?.lat,
            userLng: userLocation?.lng,
            maxDistanceKm: distanceFilter || undefined,
          }),
          api.getShops({
            district: selectedDistrict || selectedCity,
            city: selectedDistrict || selectedCity,
            category: selectedCategory !== 'all' ? selectedCategory : undefined,
            locality: selectedLocality !== 'all' ? selectedLocality : undefined,
            search: searchQuery.trim() !== '' ? searchQuery.trim() : undefined,
            sort: sortBy === 'nearest' ? 'nearest' : undefined,
            userLat: userLocation?.lat,
            userLng: userLocation?.lng,
            maxDistanceKm: distanceFilter || undefined,
          }),
        ]);
        setOffers(offersRes.offers);
        setPrimaryOffers(offersRes.primaryOffers || offersRes.offers);
        setNearbyOffers(offersRes.nearbyOffers || []);
        setDistrictWideOffers(offersRes.districtWideOffers || []);
        setShops(shopsRes.shops);
      } catch (err: any) {
        // When offline or network error occurs, check if we have saved offers in IndexedDB
        if (savedOffers.length > 0 || !navigator.onLine) {
          console.info('[CityDeals] Network offline - loading bookmarked offers from IndexedDB');
          setShowSavedOnly(true);
          setFetchError(null);
        } else {
          setFetchError(err.message || 'Could not load local directory');
        }
      } finally {
        setIsLoading(false);
      }
    }

    if (activeView === 'browse') {
      fetchData();
    }
  }, [
    selectedCity,
    selectedDistrict,
    selectedCategory,
    selectedLocality,
    searchQuery,
    sortBy,
    userLocation,
    distanceFilter,
    refreshKey,
    activeView,
  ]);

  // Track SPA Page Views & dynamic SEO metadata (canonical, description, robots privacy protection)
  useEffect(() => {
    const titles: Record<string, string> = {
      browse: 'CityDeals – Verified Local Shop Offers in Assam',
      shopping: 'CityDeals Shopping – Local Products in Assam',
      merchant: 'Merchant Dashboard | CityDeals',
      admin: 'Admin Control Centre | CityDeals',
    };
    const descriptions: Record<string, string> = {
      browse: 'Discover verified in-store deals, nearby shop discounts, and local offers across Dibrugarh and Tinsukia, Assam. Discover Local. Save Smart.',
      shopping: 'Shop authentic Assamese silk, tea, handicrafts, gadgets, and everyday goods from verified local shops in Dibrugarh & Tinsukia.',
      merchant: 'Manage your physical shop profile, publish in-store offers, and track customer orders on CityDeals.',
      admin: 'Private CityDeals administration and moderation control panel.',
    };

    const currentTitle = titles[activeView] || titles.browse;
    const currentDesc = descriptions[activeView] || descriptions.browse;
    document.title = currentTitle;

    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', currentDesc);

    const robotsMeta = document.querySelector('meta[name="robots"]');
    if (robotsMeta) {
      const isPrivateView = activeView === 'admin' || activeView === 'merchant';
      robotsMeta.setAttribute('content', isPrivateView ? 'noindex, nofollow' : 'index, follow');
    }

    const canonicalUrl = `${window.location.origin}/`;
    let canonicalLink = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.rel = 'canonical';
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonicalUrl);
    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) ogUrl.setAttribute('content', canonicalUrl);

    trackPageView(`/${activeView === 'browse' ? '' : activeView}`, currentTitle);
  }, [activeView]);

  // Compute category offer counts cleanly with useMemo
  const categoryCounts = useMemo(
    () =>
      offers.reduce((acc, offer) => {
        acc[offer.category] = (acc[offer.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
    [offers]
  );

  // Filter for saved offers if toggled (merging live offers with IndexedDB saved snapshots for offline resilience)
  const displayedOffers = showSavedOnly
    ? (() => {
        const map = new Map<string, Offer>();
        // First add any saved offers loaded from IndexedDB
        savedOffers.forEach((o) => {
          if (savedOfferIds.includes(o.id)) map.set(o.id, o);
        });
        // Override with any fresh server copies if available
        offers.forEach((o) => {
          if (savedOfferIds.includes(o.id)) map.set(o.id, o);
        });
        return Array.from(map.values());
      })()
    : offers;

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden flex flex-col bg-slate-50 text-slate-900 selection:bg-blue-600 selection:text-white">
      {/* Admin Preview Mode Persistent Banner (Visible ONLY when authenticated administrator is previewing as Merchant or Public) */}
      {user.role === 'admin' && adminPreviewMode !== 'admin' && (
        <aside
          role="region"
          aria-label="Admin Preview Mode Banner"
          className="sticky top-0 z-50 bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-slate-950 px-3 sm:px-6 py-2 sm:py-2.5 shadow-md border-b border-amber-600 flex flex-wrap items-center justify-between gap-3 animate-in slide-in-from-top-2 duration-150"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="w-7 h-7 rounded-lg bg-slate-950 text-amber-400 flex items-center justify-center shrink-0 shadow-xs">
              <Eye className="w-4 h-4 animate-pulse" />
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] sm:text-xs font-black uppercase tracking-wider bg-slate-950 text-white px-2 py-0.5 rounded-full shrink-0">
                  Preview Active
                </span>
                <span className="font-extrabold text-xs sm:text-sm text-slate-950 truncate">
                  {adminPreviewMode === 'merchant' ? 'Merchant View' : 'Public Customer View'}
                </span>
              </div>
              <p className="text-[11px] text-slate-900/90 font-medium truncate hidden md:block">
                Previewing CityDeals as a {adminPreviewMode === 'merchant' ? 'Shopkeeper / Merchant' : 'Public Citizen'}. Real administrator credentials ({user.email}) remain active.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Quick Switcher between Preview Modes */}
            <div className="flex items-center bg-slate-950/15 rounded-xl p-0.5 border border-slate-950/20">
              <button
                onClick={() => {
                  setAdminPreviewMode('merchant');
                  setActiveView('merchant');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  adminPreviewMode === 'merchant'
                    ? 'bg-slate-950 text-white shadow-xs'
                    : 'text-slate-950 hover:bg-white/40'
                }`}
              >
                Merchant View
              </button>
              <button
                onClick={() => {
                  setAdminPreviewMode('public');
                  setActiveView('browse');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  adminPreviewMode === 'public'
                    ? 'bg-slate-950 text-white shadow-xs'
                    : 'text-slate-950 hover:bg-white/40'
                }`}
              >
                Public View
              </button>
            </div>

            {/* Prominent Return Button */}
            <button
              onClick={() => {
                setAdminPreviewMode('admin');
                setActiveView('admin');
              }}
              className="px-3.5 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-900 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-slate-950/20 transition-all cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Return to Admin Dashboard</span>
            </button>
          </div>
        </aside>
      )}

      {/* Top Header - Rendered on public customer/merchant views or when previewing */}
      {(activeView !== 'admin' || adminPreviewMode !== 'admin') && <Header />}

      {/* Main View Router */}
      <main className="flex-1 pb-20 sm:pb-24">
        {activeView === 'browse' && (
          <div>
            {/* Hero Section with Search, GPS Nearby Discovery, and Locality Filter */}
            <HeroBanner
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedLocality={selectedLocality}
              setSelectedLocality={setSelectedLocality}
              totalOffersCount={offers.length}
              totalShopsCount={shops.length}
              viewMode={viewMode}
              setViewMode={setViewMode}
              userLocation={userLocation}
              onEnableLocation={handleEnableLocation}
              isLocating={isLocating}
              locationError={locationError}
              distanceFilter={distanceFilter}
              setDistanceFilter={setDistanceFilter}
              sortBy={sortBy}
              setSortBy={setSortBy}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
              {/* CityDeals Live Radar widget */}
              {!showSavedOnly && searchQuery.trim() === '' && selectedCategory === 'all' && (
                <LiveRadar
                  onSelectOffer={(offer) => openModal('details', offer)}
                  onSelectShop={(shop) => {
                    setSelectedLocality(shop.locality);
                    setViewMode('shops');
                  }}
                />
              )}

              {/* Category Chips Bar */}
              <CategoryChips
                selectedCategory={selectedCategory}
                onSelectCategory={setSelectedCategory}
                categoryCounts={categoryCounts}
              />

              {/* Sponsored Spotlight Carousel */}
              {!showSavedOnly && searchQuery.trim() === '' && selectedCategory === 'all' && (
                <SpotlightSection offers={offers} />
              )}

              {/* Filter & Sort Bar */}
              <div id="offers-section" className="bg-white rounded-2xl border border-slate-200 p-3.5 sm:p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 scroll-mt-20">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="font-bold text-slate-900">
                    {viewMode === 'offers'
                      ? `${displayedOffers.length} ${displayedOffers.length === 1 ? 'In-Store Offer' : 'In-Store Offers'} Active`
                      : `${shops.length} ${shops.length === 1 ? 'Local Shop' : 'Local Shops'} Listed`}
                  </span>
                  {selectedCategory !== 'all' && (
                    <span className="bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded-full capitalize">
                      {selectedCategory.replace('-', ' ')}
                    </span>
                  )}
                  {selectedLocality !== 'all' && (
                    <span className="bg-slate-100 text-slate-700 font-semibold px-2 py-0.5 rounded-full">
                      📍 {selectedLocality}
                    </span>
                  )}
                  {searchQuery && (
                    <span className="bg-amber-100 text-amber-900 font-semibold px-2 py-0.5 rounded-full">
                      Search: "{searchQuery}"
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2.5">
                  {/* Saved Deals Toggle */}
                  <button
                    onClick={() => setShowSavedOnly(!showSavedOnly)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      showSavedOnly
                        ? 'bg-amber-500 text-white shadow-sm ring-2 ring-amber-400/40'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                    title="View bookmarked deals stored in IndexedDB (available offline)"
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${showSavedOnly ? 'fill-white' : ''}`} />
                    <span>Saved Offers ({savedOfferIds.length})</span>
                    {isOffline && (
                      <span className="text-[10px] bg-slate-900 text-amber-300 px-1.5 py-0.2 rounded font-mono font-bold">
                        Offline Ready
                      </span>
                    )}
                    {isSyncingSavedOffers && (
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-300 animate-ping"></span>
                    )}
                  </button>

                  {/* Sort Selector for Offers */}
                  {viewMode === 'offers' && (
                    <div className="flex items-center gap-1.5 text-xs">
                      <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
                      <select
                        aria-label="Sort active offers"
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="rounded-xl border border-slate-200 bg-slate-50 p-1.5 text-xs font-semibold text-slate-700 outline-none cursor-pointer"
                      >
                        <option value="newest">Featured & Newest</option>
                        <option value="expiring_soon">Expiring Soonest</option>
                        <option value="popular">Most Visited</option>
                      </select>
                    </div>
                  )}
                </div>
              </div>

              {/* Loading State */}
              {isLoading && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 py-8">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div
                      key={i}
                      className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3 animate-pulse"
                    >
                      <div className="w-full h-44 bg-slate-200 rounded-xl"></div>
                      <div className="w-24 h-4 bg-slate-200 rounded"></div>
                      <div className="w-full h-5 bg-slate-200 rounded"></div>
                      <div className="w-3/4 h-4 bg-slate-200 rounded"></div>
                    </div>
                  ))}
                </div>
              )}

              {/* Error State */}
              {!isLoading && fetchError && (
                <div className="p-6 bg-red-50 border border-red-200 rounded-2xl text-center space-y-2">
                  <AlertCircle className="w-8 h-8 text-red-600 mx-auto" />
                  <h2 className="font-bold text-red-900">Failed to Load Directory</h2>
                  <p className="text-xs text-red-700">{fetchError}</p>
                </div>
              )}

              {/* Empty State */}
              {!isLoading && !fetchError && (viewMode === 'offers' ? displayedOffers.length === 0 : shops.length === 0) && (
                <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-4 max-w-xl mx-auto">
                  <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-600 mx-auto flex items-center justify-center">
                    <Store className="w-8 h-8" />
                  </div>
                  <h2 className="text-lg font-bold text-slate-900">
                    {showSavedOnly
                      ? 'No Saved In-Store Offers Yet'
                      : offers.length === 0
                      ? 'No offers available yet. Check back soon.'
                      : 'No Offers Match Your Search'}
                  </h2>
                  <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                    {showSavedOnly
                      ? 'Bookmark any in-store offer on CityDeals to view and redeem during your shopping trip in Dibrugarh.'
                      : offers.length === 0
                      ? 'Local physical shops in Dibrugarh are currently preparing their seasonal deals and in-store promotions. Check back soon or register your shop to post an offer.'
                      : `Try clearing filters, searching for a different shop or category, or exploring other Dibrugarh localities.`}
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                    {showSavedOnly ? (
                      <button
                        onClick={() => setShowSavedOnly(false)}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs cursor-pointer"
                      >
                        Explore All Offers
                      </button>
                    ) : offers.length === 0 ? (
                      <button
                        onClick={() => {
                          setActiveView('merchant');
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-xs cursor-pointer"
                      >
                        Are you a shopkeeper? List your shop
                      </button>
                    ) : (
                      <>
                        <button
                          onClick={() => {
                            setSearchQuery('');
                            setSelectedCategory('all');
                            setSelectedLocality('all');
                          }}
                          className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2 rounded-xl cursor-pointer"
                        >
                          Reset Filters
                        </button>
                        <button
                          onClick={() => {
                            setActiveView('merchant');
                          }}
                          className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-xs cursor-pointer"
                        >
                          Register a Shop in this Area
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* Main Directory: Active Offers Grid (Locality-Partitioned) */}
              {!isLoading && !fetchError && viewMode === 'offers' && (
                selectedLocality !== 'all' ? (
                  <div className="space-y-8">
                    {/* Primary Locality Section */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                            Verified Offers in {selectedLocality}
                          </h2>
                          <p className="text-xs text-slate-600">
                            Direct in-store offers from local shops in {selectedLocality}, {selectedDistrict || selectedCity}
                          </p>
                        </div>
                        <span className="text-xs font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full border border-blue-200">
                          {primaryOffers.length} {primaryOffers.length === 1 ? 'deal' : 'deals'}
                        </span>
                      </div>

                      {primaryOffers.length > 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                          {primaryOffers.map((offer, index) => (
                            <OfferCard key={offer.id} offer={offer} priority={index < 2} />
                          ))}
                        </div>
                      ) : (
                        <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-2">
                          <p className="text-sm font-semibold text-slate-700">
                            No active offers currently published in <strong className="text-slate-900">{selectedLocality}</strong> today.
                          </p>
                          <p className="text-xs text-slate-600 max-w-md mx-auto">
                            Check out neighboring deals in {selectedDistrict || selectedCity} below, or invite local {selectedLocality} shopkeepers to list their promotions!
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Nearby Localities in Same District Section */}
                    {nearbyOffers.length > 0 && (
                      <div className="pt-6 border-t border-slate-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 flex items-center gap-2">
                              <MapPin className="w-4 h-4 text-emerald-600" />
                              Nearby Offers in {selectedDistrict || selectedCity} District
                            </h2>
                            <p className="text-xs text-slate-600">
                              Active offers from neighboring towns and areas across {selectedDistrict || selectedCity}
                            </p>
                          </div>
                          <span className="text-xs font-bold bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full border border-emerald-200">
                            {nearbyOffers.length} nearby
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                          {nearbyOffers.map((offer) => (
                            <OfferCard key={offer.id} offer={offer} />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* District-Wide Promotions Section */}
                    {districtWideOffers.length > 0 && (
                      <div className="pt-6 border-t border-slate-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h2 className="text-base sm:text-lg font-extrabold text-indigo-950 flex items-center gap-2">
                              <Sparkles className="w-4 h-4 text-indigo-600" />
                              District-Wide Promotions ({selectedDistrict || selectedCity})
                            </h2>
                            <p className="text-xs text-slate-600">
                              Major showroom promotions and festival specials available across the entire district
                            </p>
                          </div>
                          <span className="text-xs font-bold bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-full border border-indigo-200">
                            {districtWideOffers.length} district-wide
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                          {districtWideOffers.map((offer) => (
                            <OfferCard key={offer.id} offer={offer} />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  displayedOffers.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {displayedOffers.map((offer, index) => (
                        <OfferCard key={offer.id} offer={offer} priority={index < 2} />
                      ))}
                    </div>
                  )
                )
              )}

              {/* Main Directory: Local Shops Grid (Grouped by Shop) */}
              {!isLoading && !fetchError && viewMode === 'shops' && shops.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {shops.map((shopItem) => (
                    <ShopCard
                      key={shopItem.business.id}
                      shopData={shopItem}
                      onSelectOffer={(offer) => openModal('details', offer)}
                    />
                  ))}
                </div>
              )}

              {/* Main Directory: Interactive Leaflet Map View */}
              {!isLoading && !fetchError && viewMode === 'map' && (
                <Suspense fallback={<ViewFallback />}>
                  <InteractiveMap
                    offers={displayedOffers}
                    shops={shops}
                    userLocation={userLocation}
                    selectedDistrict={selectedDistrict}
                    selectedLocality={selectedLocality}
                    onSelectOffer={(offer) => openModal('details', offer)}
                    onSelectShop={(shop) => {
                      setSelectedLocality(shop.locality);
                      setViewMode('shops');
                    }}
                    radiusKm={distanceFilter}
                    selectedCategory={selectedCategory !== 'all' ? selectedCategory : undefined}
                  />
                </Suspense>
              )}

              {/* Shopkeeper Directory CTA Banner */}
              <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="space-y-2 text-center md:text-left">
                  <span className="text-xs font-bold text-blue-300 uppercase tracking-widest block">
                    Own a Physical Shop or Restaurant in Dibrugarh or Tinsukia?
                  </span>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                    Promote In-Store Offers to Local Shoppers
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
                    CityDeals is not an online store or delivery app with hefty commissions. Add your shop profile,
                    publish in-store discount offers, and direct footfall to your physical doors across Dibrugarh, Tinsukia, and surrounding localities.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3 shrink-0">
                  <button
                    onClick={() => {
                      if (effectiveRole === 'merchant' || role === 'admin') {
                        switchRole('merchant');
                        setActiveView('merchant');
                        openModal('post-offer');
                      } else {
                        switchRole('merchant');
                      }
                    }}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg transition-transform hover:scale-105"
                  >
                    List Your Shop & Offers
                  </button>
                  <button
                    onClick={() => openModal('info-rates')}
                    className="bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm px-4 py-3 rounded-xl border border-white/20 transition-colors"
                  >
                    View Promotion Rates
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Shopping Marketplace View */}
        {activeView === 'shopping' && (
          <Suspense fallback={<ViewFallback />}>
            <ShoppingMarketplace />
          </Suspense>
        )}

        {/* Merchant Portal View */}
        {activeView === 'merchant' && (
          <Suspense fallback={<ViewFallback />}>
            <ShopkeeperPortal />
          </Suspense>
        )}

        {/* Private Founder & Admin Control Centre */}
        {activeView === 'admin' && (
          <Suspense fallback={<ViewFallback />}>
            <AdminPortal />
          </Suspense>
        )}
      </main>

      {/* Global Modals (Code-split & mounted on demand) */}
      <Suspense fallback={null}>
        {modalType === 'details' && modalData && (
          <OfferDetailsModal offer={modalData} onClose={closeModal} />
        )}

        {modalType === 'report' && modalData && (
          <ReportModal offer={modalData} onClose={closeModal} />
        )}

        {modalType === 'suggest-deal' && (
          <SuggestDealModal
            isOpen={true}
            onClose={closeModal}
            cities={cities}
            categories={categories}
          />
        )}

        {(modalType === 'post-offer' || modalType === 'edit-offer') && (
          <OfferFormModal
            initialOffer={modalType === 'edit-offer' ? modalData : null}
            onClose={closeModal}
          />
        )}

        {modalType === 'request-promotion' && (
          <PromotionRequestModal initialData={modalData} onClose={closeModal} />
        )}

        {modalType === 'request-verification' && (
          <VerificationRequestModal onClose={closeModal} />
        )}

        {modalType === 'auth' && <AuthModal />}

        {modalType === 'share' && <ShareModal onClose={closeModal} />}

        {modalType === 'referrals' && <ReferralModal onClose={closeModal} />}

        {/* CityDeals Shopping Modals */}
        {modalType === 'product-details' && <ProductDetailsModal />}

        {modalType === 'cart' && <CartModal />}

        {modalType === 'checkout' && <CheckoutModal />}

        {modalType === 'order-details' && <OrderDetailsModal />}

        {modalType === 'order-history' && <OrderHistoryModal />}

        {(modalType === 'post-product' || modalType === 'edit-product') && <ProductFormModal />}

        <InfoModals />
      </Suspense>

      {/* Global Toast Alert */}
      {toast && (
        <div className="fixed bottom-20 sm:bottom-6 right-5 z-50 animate-in slide-in-from-bottom duration-200">
          <div
            className={`flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-xl text-xs font-bold border backdrop-blur-md ${
              toast.type === 'success'
                ? 'bg-emerald-950/90 text-emerald-200 border-emerald-700'
                : toast.type === 'error'
                ? 'bg-red-950/90 text-red-200 border-red-700'
                : 'bg-slate-900/90 text-white border-slate-700'
            }`}
          >
            {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
            {toast.type === 'info' && <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Fixed Responsive Bottom Navigation Bar */}
      <BottomNav
        currentTab={activeView === 'browse' && viewMode === 'offers' ? 'offers' : undefined}
        onNavigateHome={handleNavigateHome}
        onNavigateOffers={handleNavigateOffers}
      />

      {/* Footer - Public views only */}
      {activeView !== 'admin' && <Footer />}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
