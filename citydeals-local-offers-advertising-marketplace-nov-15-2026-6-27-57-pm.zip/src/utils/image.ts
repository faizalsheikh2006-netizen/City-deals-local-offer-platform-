/**
 * Optimizes image URLs (such as Unsplash CDN assets) for responsive mobile delivery,
 * WebP format negotiation, and smaller payload sizes on slow 4G networks.
 */
export function optimizeImageUrl(url: string | undefined, width = 640, quality = 75): string {
  if (!url) return '';
  if (url.includes('images.unsplash.com')) {
    try {
      const parsed = new URL(url);
      parsed.searchParams.set('auto', 'format');
      parsed.searchParams.set('fit', 'crop');
      parsed.searchParams.set('fm', 'webp');
      parsed.searchParams.set('w', String(width));
      parsed.searchParams.set('q', String(quality));
      return parsed.toString();
    } catch {
      return url;
    }
  }
  return url;
}
