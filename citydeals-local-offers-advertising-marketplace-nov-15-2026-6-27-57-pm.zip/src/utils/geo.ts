/**
 * Dibrugarh Hyperlocal Geolocation & Distance Utilities
 * CityDeals - Discover Local. Save Smart.
 */

export interface Coordinates {
  lat: number;
  lng: number;
}

// Accurate coordinate mapping for Assam's prominent districts and localities (Dibrugarh and Tinsukia)
export const ASSAM_LOCALITY_COORDS: Record<string, Coordinates> = {
  // --- Tinsukia District ---
  'Tinsukia Town': { lat: 27.4922, lng: 95.3468 },
  'Doomdooma': { lat: 27.5683, lng: 95.5686 },
  'Dhola': { lat: 27.7681, lng: 95.6022 },
  'Makum': { lat: 27.5028, lng: 95.4528 },
  'Digboi': { lat: 27.3822, lng: 95.6289 },
  'Margherita': { lat: 27.2847, lng: 95.6833 },
  'Daily Bazar': { lat: 27.4935, lng: 95.3482 },
  'GNB Road': { lat: 27.491, lng: 95.345 },
  'Chirwapatty': { lat: 27.496, lng: 95.352 },
  'Parbotia': { lat: 27.489, lng: 95.339 },

  // --- Dibrugarh District ---
  'Dibrugarh Town': { lat: 27.4835, lng: 94.9112 },
  'Chowkidinghee': { lat: 27.4695, lng: 94.9178 },
  'Chabua': { lat: 27.4789, lng: 95.1764 },
  'Naharkatia': { lat: 27.2817, lng: 95.2575 },
  'Duliajan': { lat: 27.3592, lng: 95.3211 },
  'Moran': { lat: 27.1856, lng: 94.9317 },
  'Tengakhat': { lat: 27.4128, lng: 95.1483 },
  'Lahowal': { lat: 27.4583, lng: 95.0089 },
  'Khowang': { lat: 27.2833, lng: 94.9167 },
  'Joypur': { lat: 27.2667, lng: 95.3833 },
  'Thana Chariali': { lat: 27.4835, lng: 94.9112 },
  'Graham Bazar': { lat: 27.4782, lng: 94.9048 },
  'HS Road': { lat: 27.4851, lng: 94.9135 },
  'New Market': { lat: 27.4851, lng: 94.9135 },
  'Boiragimoth': { lat: 27.465, lng: 94.921 },
  'Mancotta Road': { lat: 27.4612, lng: 94.913 },
  'Phoolbagan': { lat: 27.488, lng: 94.916 },
  'Amolapatty': { lat: 27.476, lng: 94.918 },
  'Naliapool': { lat: 27.4895, lng: 94.908 },
  'Gabharupathar': { lat: 27.458, lng: 94.931 },
  'Khalihamari': { lat: 27.48, lng: 94.9195 },
  'Jalan Nagar': { lat: 27.452, lng: 94.901 },
  'Dibrugarh University Campus': { lat: 27.4475, lng: 94.8978 },
};

// Aliased for backwards compatibility
export const DIBRUGARH_LOCALITY_COORDS = ASSAM_LOCALITY_COORDS;

// District Centers
export const DISTRICT_CENTERS: Record<string, Coordinates> = {
  'Dibrugarh': { lat: 27.4835, lng: 94.9112 },
  'Tinsukia': { lat: 27.4922, lng: 95.3468 },
  'Guwahati': { lat: 26.1445, lng: 91.7362 },
  'Jorhat': { lat: 26.7509, lng: 94.2037 },
};

export const DIBRUGARH_CENTER: Coordinates = DISTRICT_CENTERS['Dibrugarh'];
export const TINSUKIA_CENTER: Coordinates = DISTRICT_CENTERS['Tinsukia'];

/**
 * Calculates straight-line distance in kilometers using the Haversine formula
 */
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.round(d * 10) / 10;
}

/**
 * Resolves coordinates for a given locality name
 */
export function getLocalityCoords(locality: string): Coordinates {
  if (!locality) return DIBRUGARH_CENTER;
  const cleanLoc = locality.trim();
  if (DIBRUGARH_LOCALITY_COORDS[cleanLoc]) {
    return DIBRUGARH_LOCALITY_COORDS[cleanLoc];
  }

  // Fuzzy check
  const lower = cleanLoc.toLowerCase();
  for (const [key, coords] of Object.entries(DIBRUGARH_LOCALITY_COORDS)) {
    if (key.toLowerCase().includes(lower) || lower.includes(key.toLowerCase())) {
      return coords;
    }
  }

  return DIBRUGARH_CENTER;
}

/**
 * Formats distance for user display (e.g. "450m away" or "1.8 km away")
 */
export function formatDistance(km: number | undefined | null): string | null {
  if (km === undefined || km === null || isNaN(km)) return null;
  if (km < 0.1) return 'Near you (< 100m)';
  if (km < 1) return `${Math.round(km * 1000)}m away`;
  return `${km.toFixed(1)} km away`;
}

/**
 * Requests user browser geolocation
 */
export function requestUserLocation(): Promise<Coordinates> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser.'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
      },
      (err) => {
        let msg = 'Could not access your location.';
        if (err.code === err.PERMISSION_DENIED) {
          msg = 'Location permission was denied. You can still filter by locality.';
        } else if (err.code === err.POSITION_UNAVAILABLE) {
          msg = 'Location information is currently unavailable.';
        } else if (err.code === err.TIMEOUT) {
          msg = 'Location request timed out.';
        }
        reject(new Error(msg));
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      }
    );
  });
}
