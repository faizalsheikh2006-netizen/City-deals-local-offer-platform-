import {
  Offer,
  Business,
  PromotionPackage,
  PromotionRequest,
  Report,
  User,
  City,
  Category,
  ShopWithOffers,
  AuditLog,
  Referral,
  ReferralCampaignConfig,
  ReferralStatus,
  DealSuggestion,
  Product,
  ShoppingOrder,
  OrderStatus,
  FulfillmentType,
  District,
  LocalityItem,
  VerificationRequest,
  VerificationStatus,
} from '../types/index';

class ApiClient {
  private token: string | null = null;

  constructor() {
    try {
      this.token = localStorage.getItem('citydeals_token');
    } catch {
      this.token = null;
    }
  }

  public setToken(token: string | null) {
    this.token = token;
    try {
      if (token) {
        localStorage.setItem('citydeals_token', token);
      } else {
        localStorage.removeItem('citydeals_token');
      }
    } catch {
      // storage unavailable
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  // Backward compatibility alias
  public setAuth(_userId: string, _role: string) {
    // Handled via setToken
  }

  public getAuth() {
    return { token: this.token };
  }

  private getHeaders(): HeadersInit {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  // Config
  async getConfig(): Promise<{
    cities: City[];
    districts?: District[];
    launchDistricts?: string[];
    categories: Category[];
    promotionPackages: PromotionPackage[];
    launchCity: string;
    state: string;
    country: string;
  }> {
    const res = await fetch('/api/config');
    if (!res.ok) throw new Error('Failed to load platform configuration');
    return res.json();
  }

  // Public Dynamic Districts & Localities
  async getDistricts(): Promise<{ districts: District[] }> {
    const res = await fetch('/api/districts');
    if (!res.ok) throw new Error('Failed to fetch districts');
    return res.json();
  }

  // Public Offers with District & Locality partitioning support
  async getOffers(params?: {
    district?: string;
    city?: string;
    category?: string;
    locality?: string;
    search?: string;
    sort?: string;
    userLat?: number;
    userLng?: number;
    maxDistanceKm?: number;
  }): Promise<{
    count: number;
    totalDistrictOffers?: number;
    offers: Offer[];
    primaryOffers?: Offer[];
    nearbyOffers?: Offer[];
    districtWideOffers?: Offer[];
    selectedLocality?: string;
    selectedDistrict?: string;
  }> {
    const query = new URLSearchParams();
    if (params?.district) query.set('district', params.district);
    if (params?.city) query.set('city', params.city);
    if (params?.category) query.set('category', params.category);
    if (params?.locality) query.set('locality', params.locality);
    if (params?.search) query.set('search', params.search);
    if (params?.sort) query.set('sort', params.sort);
    if (params?.userLat !== undefined) query.set('userLat', params.userLat.toString());
    if (params?.userLng !== undefined) query.set('userLng', params.userLng.toString());
    if (params?.maxDistanceKm !== undefined) query.set('maxDistanceKm', params.maxDistanceKm.toString());

    const res = await fetch(`/api/offers?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch offers');
    return res.json();
  }

  // Public Shops (Grouped Shops with active in-store offers)
  async getShops(params?: {
    district?: string;
    city?: string;
    category?: string;
    locality?: string;
    search?: string;
    sort?: string;
    userLat?: number;
    userLng?: number;
    maxDistanceKm?: number;
  }): Promise<{ count: number; shops: ShopWithOffers[] }> {
    const query = new URLSearchParams();
    if (params?.district) query.set('district', params.district);
    if (params?.city) query.set('city', params.city);
    if (params?.category) query.set('category', params.category);
    if (params?.locality) query.set('locality', params.locality);
    if (params?.search) query.set('search', params.search);
    if (params?.sort) query.set('sort', params.sort);
    if (params?.userLat !== undefined) query.set('userLat', params.userLat.toString());
    if (params?.userLng !== undefined) query.set('userLng', params.userLng.toString());
    if (params?.maxDistanceKm !== undefined) query.set('maxDistanceKm', params.maxDistanceKm.toString());

    const res = await fetch(`/api/shops?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch shops directory');
    return res.json();
  }

  async getShopById(id: string): Promise<{ business: Business; offers: Offer[] }> {
    const res = await fetch(`/api/shops/${id}`);
    if (!res.ok) throw new Error('Shop not found');
    return res.json();
  }

  // Hyperlocal Live Radar (Trending, New Today, Expiring Soon, Popular Shops, Recently Verified)
  async getRadar(params?: { district?: string; city?: string }): Promise<{
    trendingOffers: Offer[];
    newOffersToday: Offer[];
    expiringSoonOffers: Offer[];
    popularShops: (Business & { activeOffersCount: number })[];
    recentlyVerifiedOffers: Offer[];
    meta?: { city: string; lastUpdated: string; activeDealsCount: number };
  }> {
    const defaultLoc = params?.district || params?.city || 'All Locations';
    const fallback = {
      trendingOffers: [],
      newOffersToday: [],
      expiringSoonOffers: [],
      popularShops: [],
      recentlyVerifiedOffers: [],
      meta: { city: defaultLoc, lastUpdated: new Date().toISOString(), activeDealsCount: 0 },
    };

    try {
      const queryParams = new URLSearchParams();
      if (params?.district) queryParams.set('district', params.district);
      if (params?.city) queryParams.set('city', params.city);
      const url = queryParams.toString() ? `/api/radar?${queryParams.toString()}` : '/api/radar';

      const res = await fetch(url);
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) {
        return fallback;
      }
      const data = await res.json();
      return {
        trendingOffers: Array.isArray(data?.trendingOffers) ? data.trendingOffers : [],
        newOffersToday: Array.isArray(data?.newOffersToday) ? data.newOffersToday : [],
        expiringSoonOffers: Array.isArray(data?.expiringSoonOffers) ? data.expiringSoonOffers : [],
        popularShops: Array.isArray(data?.popularShops) ? data.popularShops : [],
        recentlyVerifiedOffers: Array.isArray(data?.recentlyVerifiedOffers) ? data.recentlyVerifiedOffers : [],
        meta: data?.meta || fallback.meta,
      };
    } catch {
      return fallback;
    }
  }

  // Community Citizen Deal Suggestion
  async suggestDeal(data: {
    shopName: string;
    locality: string;
    category?: string;
    offerHeadline: string;
    estimatedDiscount?: string;
    details?: string;
    submitterName?: string;
    submitterContact?: string;
  }): Promise<{ success: boolean; message: string; suggestion: DealSuggestion }> {
    const res = await fetch('/api/community/suggest-deal', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to submit deal suggestion');
    }
    return res.json();
  }

  async getOfferById(id: string): Promise<{ offer: Offer; shop?: Business; otherOffers?: Offer[] }> {
    const res = await fetch(`/api/offers/${id}`, {
      headers: this.getHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Offer not found or access restricted');
    }
    return res.json();
  }

  async trackClick(id: string): Promise<void> {
    try {
      await fetch(`/api/offers/${id}/click`, {
        method: 'POST',
        headers: this.getHeaders(),
      });
    } catch {
      // Ignore click tracking failures silently
    }
  }

  async trackShare(id: string): Promise<void> {
    try {
      await fetch(`/api/offers/${id}/share`, {
        method: 'POST',
        headers: this.getHeaders(),
      });
    } catch {
      // Ignore share tracking failures silently
    }
  }

  async reportOffer(
    id: string,
    data: { reason: string; details: string; reporterName?: string; reporterContact?: string }
  ): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/offers/${id}/report`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to submit report');
    }
    return res.json();
  }

  // Auth Endpoints
  async getDemoCredentials(): Promise<{ accounts: any[] }> {
    const res = await fetch('/api/auth/demo-credentials');
    if (!res.ok) throw new Error('Failed to load demo accounts');
    return res.json();
  }

  async login(email: string, password: string): Promise<{ success: boolean; token: string; user: User; business?: Business }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Login failed. Please check your credentials.');
    }
    const data = await res.json();
    this.setToken(data.token);
    return data;
  }

  async register(
    name: string,
    email: string,
    password: string,
    role: 'public' | 'merchant',
    phone?: string,
    referralCode?: string
  ): Promise<{ success: boolean; token: string; user: User; business?: Business }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role, phone, referralCode }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Registration failed.');
    }
    const data = await res.json();
    this.setToken(data.token);
    return data;
  }

  async logout(): Promise<void> {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: this.getHeaders(),
      });
    } catch {
      // ignore
    } finally {
      this.setToken(null);
    }
  }

  // Auth / Me
  async getMe(): Promise<{ user: User; business?: Business }> {
    const res = await fetch('/api/auth/me', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to get session');
    return res.json();
  }

  // Password Recovery Endpoints
  async forgotPassword(email: string) {
    return this.requestPasswordReset(email);
  }

  async requestPasswordReset(email: string): Promise<{
    success: boolean;
    message: string;
    email: string;
    resetToken: string;
    resetLink: string;
    expiresInMinutes: number;
  }> {
    const res = await fetch('/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to request password reset. Please check your network connection.');
    }
    return res.json();
  }

  async verifyResetToken(token: string): Promise<{
    valid: boolean;
    email: string;
    name: string;
    error?: string;
  }> {
    const res = await fetch(`/api/auth/verify-reset-token?token=${encodeURIComponent(token)}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Password reset link is invalid or has expired.');
    }
    return res.json();
  }

  async resetPassword(token: string, newPassword: string): Promise<{
    success: boolean;
    message: string;
    email: string;
  }> {
    const res = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, newPassword }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to reset password. Please try again.');
    }
    return res.json();
  }

  // Merchant Endpoints
  async getMerchantBusiness(): Promise<{ business: Business | null }> {
    const res = await fetch('/api/merchant/business', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to get business profile');
    return res.json();
  }

  async saveMerchantBusiness(data: Partial<Business>): Promise<{ success: boolean; business: Business }> {
    const res = await fetch('/api/merchant/business', {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to save business profile');
    }
    return res.json();
  }

  async getMerchantOffers(): Promise<{ count: number; offers: Offer[] }> {
    const res = await fetch('/api/merchant/offers', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load merchant offers');
    return res.json();
  }

  async createOffer(data: Partial<Offer>): Promise<{ success: boolean; offer: Offer; message: string }> {
    const res = await fetch('/api/merchant/offers', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to submit offer');
    }
    return res.json();
  }

  async updateOffer(id: string, data: Partial<Offer>): Promise<{ success: boolean; offer: Offer; message: string }> {
    const res = await fetch(`/api/merchant/offers/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update offer');
    }
    return res.json();
  }

  async toggleOfferActive(id: string): Promise<{ success: boolean; message: string; isActive: boolean }> {
    const res = await fetch(`/api/merchant/offers/${id}/toggle-active`, {
      method: 'POST',
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to toggle offer status');
    return res.json();
  }

  async deleteOffer(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/merchant/offers/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to delete offer');
    return res.json();
  }

  async requestPromotion(data: {
    offerId: string;
    packageId: string;
    paymentMethod: string;
    transactionReference: string;
  }): Promise<{ success: boolean; promotionRequest: PromotionRequest; message: string }> {
    const res = await fetch('/api/merchant/promotion-requests', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to submit promotion request');
    }
    return res.json();
  }

  async getMerchantPromotionRequests(): Promise<{ promotionRequests: PromotionRequest[] }> {
    const res = await fetch('/api/merchant/promotion-requests', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load promotion requests');
    return res.json();
  }

  // Merchant Verification (Get Verified)
  async getMerchantVerification(): Promise<{
    request: VerificationRequest | null;
    business: Business | null;
    verificationFee: number;
  }> {
    const res = await fetch('/api/merchant/verification', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load merchant verification status');
    return res.json();
  }

  async submitMerchantVerification(data: {
    tradeLicenseNumber?: string;
    gstNumber?: string;
    documentType: string;
    documentUrl: string;
    documentName?: string;
    paymentMethod: string;
    paymentReference: string;
  }): Promise<{ success: boolean; message: string; request: VerificationRequest }> {
    const res = await fetch('/api/merchant/verification-requests', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to submit verification request');
    }
    return res.json();
  }

  // Admin Endpoints
  async getAdminStats(): Promise<{ stats: any }> {
    const res = await fetch('/api/admin/stats', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load admin stats');
    return res.json();
  }

  async getAdminOffers(params?: { status?: string; search?: string } | string): Promise<{ offers: Offer[] }> {
    const query = new URLSearchParams();
    if (typeof params === 'string') {
      if (params !== 'all') query.set('status', params);
    } else if (params) {
      if (params.status && params.status !== 'all') query.set('status', params.status);
      if (params.search) query.set('search', params.search);
    }

    const res = await fetch(`/api/admin/offers?${query.toString()}`, {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load moderation offers');
    return res.json();
  }

  async approveOffer(id: string): Promise<{ success: boolean; offer: Offer; message: string }> {
    const res = await fetch(`/api/admin/offers/${id}/approve`, {
      method: 'POST',
      headers: this.getHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to approve offer');
    }
    return res.json();
  }

  async rejectOffer(id: string, reason: string): Promise<{ success: boolean; offer: Offer; message: string }> {
    const res = await fetch(`/api/admin/offers/${id}/reject`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to reject offer');
    }
    return res.json();
  }

  async suspendOffer(id: string, reason?: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/admin/offers/${id}/suspend`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason }),
    });
    if (!res.ok) throw new Error('Failed to suspend offer');
    return res.json();
  }

  async setSponsored(id: string, isSponsored: boolean, tier?: string, durationDays?: number): Promise<{ success: boolean }> {
    const res = await fetch(`/api/admin/offers/${id}/sponsor`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ isSponsored, tier, durationDays }),
    });
    if (!res.ok) throw new Error('Failed to update sponsorship');
    return res.json();
  }

  async getAdminShops(): Promise<{ shops: Business[] }> {
    const res = await fetch('/api/admin/shops', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load shops');
    return res.json();
  }

  async approveShop(id: string): Promise<{ success: boolean; shop: Business }> {
    const res = await fetch(`/api/admin/shops/${id}/approve`, {
      method: 'POST',
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to approve shop');
    return res.json();
  }

  async rejectShop(id: string, reason?: string): Promise<{ success: boolean; shop: Business }> {
    const res = await fetch(`/api/admin/shops/${id}/reject`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason }),
    });
    if (!res.ok) throw new Error('Failed to reject shop');
    return res.json();
  }

  async getReports(): Promise<{ reports: Report[] }> {
    const res = await fetch('/api/admin/reports', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load reports');
    return res.json();
  }

  async resolveReport(id: string, action: { status: string; adminNotes?: string; suspendOffer?: boolean }): Promise<any> {
    const res = await fetch(`/api/admin/reports/${id}/resolve`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(action),
    });
    if (!res.ok) throw new Error('Failed to resolve report');
    return res.json();
  }

  async getAdminPromotionRequests(): Promise<{ promotionRequests: PromotionRequest[] }> {
    const res = await fetch('/api/admin/promotion-requests', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load promotion requests');
    return res.json();
  }

  async handlePromotionAction(
    id: string,
    action: 'approve' | 'reject' | 'activate' | 'deactivate',
    adminNotes?: string,
    extra?: { startDate?: string; expiresAt?: string; durationDays?: number }
  ): Promise<any> {
    const res = await fetch(`/api/admin/promotion-requests/${id}/action`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ action, adminNotes, ...(extra || {}) }),
    });
    if (!res.ok) throw new Error(`Failed to ${action} promotion request`);
    return res.json();
  }

  // Admin Verification Requests
  async getAdminVerificationRequests(): Promise<{ requests: VerificationRequest[] }> {
    const res = await fetch('/api/admin/verification-requests', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load verification requests');
    return res.json();
  }

  async handleVerificationAction(
    id: string,
    action: 'approve' | 'reject' | 'revoke',
    adminNotes?: string
  ): Promise<{ success: boolean; message: string; request: VerificationRequest; business?: Business }> {
    const res = await fetch(`/api/admin/verification-requests/${id}/action`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ action, adminNotes }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Failed to ${action} verification request`);
    }
    return res.json();
  }

  async getAuditLogs(): Promise<{ auditLogs: AuditLog[] }> {
    const res = await fetch('/api/admin/audit-logs', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load audit logs');
    return res.json();
  }

  // Referral Endpoints
  async validateReferralCode(code: string): Promise<{
    valid: boolean;
    code?: string;
    referrerName?: string;
    referrerRole?: string;
    referrer?: { name: string; role: string; code: string };
    message?: string;
  }> {
    const res = await fetch(`/api/referrals/validate/${encodeURIComponent(code)}`);
    return res.json();
  }

  async getMyReferrals(): Promise<{
    referralCode: string;
    referralCount: number;
    pendingCount: number;
    campaignConfig: ReferralCampaignConfig;
    referrals: Array<{
      id: string;
      referredUserName: string;
      referredUserRole: string;
      status: string;
      createdAt: string;
    }>;
  }> {
    const res = await fetch('/api/referrals/me', {
      headers: this.getHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to load referral statistics');
    }
    return res.json();
  }

  async getAdminReferrals(): Promise<{
    stats: {
      totalReferrals: number;
      totalVerified: number;
      totalFlagged: number;
      totalPending: number;
    };
    config: ReferralCampaignConfig;
    topReferrers: Array<{
      id: string;
      name: string;
      email: string;
      code: string;
      role: string;
      count: number;
    }>;
    referrals: Referral[];
  }> {
    const res = await fetch('/api/admin/referrals', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load admin referral analytics');
    return res.json();
  }

  async updateReferralConfig(config: Partial<ReferralCampaignConfig>): Promise<{
    success: boolean;
    message: string;
    config: ReferralCampaignConfig;
  }> {
    const res = await fetch('/api/admin/referrals/config', {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(config),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update referral configuration');
    }
    return res.json();
  }

  async updateReferralStatus(
    id: string,
    status: ReferralStatus,
    notes?: string
  ): Promise<{ success: boolean; referral: Referral }> {
    const res = await fetch(`/api/admin/referrals/${id}/status`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, notes }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update referral status');
    }
    return res.json();
  }

  // Admin Deal Suggestions
  async getAdminDealSuggestions(): Promise<{ suggestions: DealSuggestion[] }> {
    const res = await fetch('/api/admin/deal-suggestions', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load deal suggestions');
    return res.json();
  }

  async handleDealSuggestionAction(
    id: string,
    action: 'verify' | 'dismiss',
    notes?: string
  ): Promise<{ success: boolean; message: string; suggestion: DealSuggestion }> {
    const res = await fetch(`/api/admin/deal-suggestions/${id}/action`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ action, notes }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to moderate suggestion');
    }
    return res.json();
  }

  // Admin Promotion Package Pricing
  async getPromotionPackages(): Promise<{ packages: PromotionPackage[] }> {
    const res = await fetch('/api/promotion-packages');
    if (!res.ok) throw new Error('Failed to load promotion packages');
    return res.json();
  }

  async updatePromotionPackage(
    id: string,
    data: Partial<PromotionPackage>
  ): Promise<{ success: boolean; message: string; package: PromotionPackage }> {
    const res = await fetch(`/api/admin/promotion-packages/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update promotion package');
    }
    return res.json();
  }

  // ==================== CITYDEALS SHOPPING: PUBLIC API ====================

  async getProducts(params?: {
    category?: string;
    locality?: string;
    shopId?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
    userLat?: number;
    userLng?: number;
    maxDistanceKm?: number;
    inStockOnly?: boolean;
  }): Promise<{ count: number; products: Product[] }> {
    const query = new URLSearchParams();
    if (params?.category) query.set('category', params.category);
    if (params?.locality) query.set('locality', params.locality);
    if (params?.shopId) query.set('shopId', params.shopId);
    if (params?.search) query.set('search', params.search);
    if (params?.minPrice !== undefined) query.set('minPrice', params.minPrice.toString());
    if (params?.maxPrice !== undefined) query.set('maxPrice', params.maxPrice.toString());
    if (params?.sort) query.set('sort', params.sort);
    if (params?.userLat !== undefined) query.set('userLat', params.userLat.toString());
    if (params?.userLng !== undefined) query.set('userLng', params.userLng.toString());
    if (params?.maxDistanceKm !== undefined) query.set('maxDistanceKm', params.maxDistanceKm.toString());
    if (params?.inStockOnly) query.set('inStockOnly', 'true');

    const res = await fetch(`/api/products?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to load shopping products');
    return res.json();
  }

  async getProductById(id: string): Promise<{ product: Product; otherProducts?: Product[]; otherShopProducts?: Product[] }> {
    const res = await fetch(`/api/products/${id}`);
    if (!res.ok) throw new Error('Product not found or unavailable');
    return res.json();
  }

  async createOrder(orderData: {
    businessId: string;
    customerName: string;
    customerPhone: string;
    customerEmail?: string;
    fulfillmentType: FulfillmentType;
    deliveryAddress?: string;
    customerNotes?: string;
    items: { productId: string; quantity: number }[];
  }): Promise<{ success: boolean; message: string; order: ShoppingOrder }> {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(orderData),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to place order');
    }
    return res.json();
  }

  async getMyOrders(phone?: string): Promise<{ count: number; orders: ShoppingOrder[] }> {
    const query = phone ? `?phone=${encodeURIComponent(phone)}` : '';
    const res = await fetch(`/api/orders/my${query}`, {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load order history');
    return res.json();
  }

  async getOrderById(id: string): Promise<{ order: ShoppingOrder }> {
    const res = await fetch(`/api/orders/${id}`);
    if (!res.ok) throw new Error('Order not found');
    return res.json();
  }

  async cancelOrder(id: string, reason?: string): Promise<{ success: boolean; message: string; order: ShoppingOrder }> {
    const res = await fetch(`/api/orders/${id}/cancel`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to cancel order');
    }
    return res.json();
  }

  // ==================== CITYDEALS SHOPPING: MERCHANT API ====================

  async getMerchantProducts(): Promise<{ count: number; products: Product[] }> {
    const res = await fetch('/api/merchant/products', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load merchant products');
    return res.json();
  }

  async createMerchantProduct(data: Partial<Product>): Promise<{ success: boolean; message: string; product: Product }> {
    const res = await fetch('/api/merchant/products', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to create product listing');
    }
    return res.json();
  }

  async updateMerchantProduct(id: string, data: Partial<Product>): Promise<{ success: boolean; message: string; product: Product }> {
    const res = await fetch(`/api/merchant/products/${id}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update product listing');
    }
    return res.json();
  }

  async toggleProductStock(id: string): Promise<{ success: boolean; inStock: boolean; message: string }> {
    const res = await fetch(`/api/merchant/products/${id}/toggle-stock`, {
      method: 'POST',
      headers: this.getHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to toggle product stock');
    }
    return res.json();
  }

  async deleteMerchantProduct(id: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/merchant/products/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to remove product');
    }
    return res.json();
  }

  async getMerchantOrders(): Promise<{ count: number; orders: ShoppingOrder[] }> {
    const res = await fetch('/api/merchant/orders', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load shop orders');
    return res.json();
  }

  async updateMerchantOrderStatus(
    id: string,
    status: OrderStatus,
    merchantNotes?: string
  ): Promise<{ success: boolean; message: string; order: ShoppingOrder }> {
    const res = await fetch(`/api/merchant/orders/${id}/status`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ status, merchantNotes }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update order status');
    }
    return res.json();
  }

  // ==================== CITYDEALS SHOPPING: ADMIN API ====================

  async getAdminProducts(status?: string, search?: string): Promise<{ products: Product[] }> {
    const query = new URLSearchParams();
    if (status) query.set('status', status);
    if (search) query.set('search', search);

    const res = await fetch(`/api/admin/products?${query.toString()}`, {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load catalog for moderation');
    return res.json();
  }

  async approveProduct(id: string): Promise<{ success: boolean; message: string; product: Product }> {
    const res = await fetch(`/api/admin/products/${id}/approve`, {
      method: 'POST',
      headers: this.getHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to approve product');
    }
    return res.json();
  }

  async rejectProduct(id: string, reason: string, notes?: string): Promise<{ success: boolean; message: string; product: Product }> {
    const res = await fetch(`/api/admin/products/${id}/reject`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason, moderationNotes: notes }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to reject product');
    }
    return res.json();
  }

  async suspendProduct(id: string, reason?: string): Promise<{ success: boolean; message: string; product: Product }> {
    const res = await fetch(`/api/admin/products/${id}/suspend`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ reason }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to suspend product');
    }
    return res.json();
  }

  async getAdminOrders(status?: string, search?: string): Promise<{ count: number; orders: ShoppingOrder[] }> {
    const query = new URLSearchParams();
    if (status) query.set('status', status);
    if (search) query.set('search', search);

    const res = await fetch(`/api/admin/orders?${query.toString()}`, {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to load shopping orders');
    return res.json();
  }

  // Admin dynamic location management
  async getAdminDistricts(): Promise<{ districts: District[] }> {
    const res = await fetch('/api/admin/districts', {
      headers: this.getHeaders(),
    });
    if (!res.ok) throw new Error('Failed to fetch admin districts');
    return res.json();
  }

  async createAdminDistrict(payload: {
    name: string;
    state?: string;
    isLaunchMarket?: boolean;
  }): Promise<{ success: boolean; district: District }> {
    const res = await fetch('/api/admin/districts', {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to create district');
    }
    return res.json();
  }

  async addAdminLocality(
    districtId: string,
    payload: { name: string; latitude?: number; longitude?: number }
  ): Promise<{ success: boolean; locality: LocalityItem; district: District }> {
    const res = await fetch(`/api/admin/districts/${districtId}/localities`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to add locality');
    }
    return res.json();
  }

  async updateAdminLocality(
    districtId: string,
    localityId: string,
    payload: { name?: string; isActive?: boolean; latitude?: number; longitude?: number }
  ): Promise<{ success: boolean; locality: LocalityItem; district: District }> {
    const res = await fetch(`/api/admin/districts/${districtId}/localities/${localityId}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to update locality');
    }
    return res.json();
  }

  async deleteAdminLocality(
    districtId: string,
    localityId: string
  ): Promise<{ success: boolean; message: string; district: District }> {
    const res = await fetch(`/api/admin/districts/${districtId}/localities/${localityId}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to delete locality');
    }
    return res.json();
  }
}

export const api = new ApiClient();
