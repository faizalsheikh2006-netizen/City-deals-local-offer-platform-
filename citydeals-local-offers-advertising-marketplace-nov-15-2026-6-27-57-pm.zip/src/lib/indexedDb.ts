/**
 * CityDeals IndexedDB Manager for Saved Offers & Offline Resilience
 *
 * Stores both saved offer IDs and complete Offer entity snapshots into client-side IndexedDB,
 * ensuring users can bookmark offers and browse them completely offline even without internet connectivity.
 *
 * Supports bidirectional synchronization with Firestore user saved offers collection.
 */

import { Offer } from '../types';

const DB_NAME = 'citydeals_offline_store';
const DB_VERSION = 1;
const SAVED_OFFERS_STORE = 'saved_offers';
const METADATA_STORE = 'app_metadata';

export interface SavedOfferRecord {
  id: string; // Offer ID
  offer: Offer; // Full offer payload for offline rendering
  savedAt: string; // ISO timestamp
  updatedAt: string;
}

let dbPromise: Promise<IDBDatabase> | null = null;

function getIndexedDB(): IDBFactory | null {
  if (typeof window !== 'undefined' && 'indexedDB' in window) {
    return window.indexedDB;
  }
  return null;
}

/**
 * Initializes and returns the IndexedDB database instance
 */
export function openCityDealsDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  const idb = getIndexedDB();
  if (!idb) {
    return Promise.reject(new Error('IndexedDB is not supported in this environment'));
  }

  dbPromise = new Promise((resolve, reject) => {
    const request = idb.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Object store for saved offers with full offer object and indexed fields
      if (!db.objectStoreNames.contains(SAVED_OFFERS_STORE)) {
        const store = db.createObjectStore(SAVED_OFFERS_STORE, { keyPath: 'id' });
        store.createIndex('savedAt', 'savedAt', { unique: false });
        store.createIndex('shopName', 'offer.shopName', { unique: false });
        store.createIndex('category', 'offer.category', { unique: false });
      }

      // Metadata store for sync status, last sync timestamp, offline queues
      if (!db.objectStoreNames.contains(METADATA_STORE)) {
        db.createObjectStore(METADATA_STORE, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      dbPromise = null;
      reject(request.error || new Error('Failed to open IndexedDB database'));
    };
  });

  return dbPromise;
}

/**
 * Retrieve all saved offer records from IndexedDB
 */
export async function getAllSavedOffersFromIDB(): Promise<SavedOfferRecord[]> {
  try {
    const db = await openCityDealsDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(SAVED_OFFERS_STORE, 'readonly');
      const store = tx.objectStore(SAVED_OFFERS_STORE);
      const request = store.getAll();

      request.onsuccess = () => {
        const results = (request.result || []) as SavedOfferRecord[];
        // Sort newest saved first
        results.sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime());
        resolve(results);
      };

      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Failed to get saved offers from IDB:', err);
    return [];
  }
}

/**
 * Retrieve all saved offer IDs from IndexedDB
 */
export async function getSavedOfferIdsFromIDB(): Promise<string[]> {
  try {
    const records = await getAllSavedOffersFromIDB();
    return records.map((r) => r.id);
  } catch {
    return [];
  }
}

/**
 * Save an offer into IndexedDB with full offer payload
 */
export async function saveOfferToIDB(offer: Offer): Promise<void> {
  try {
    const db = await openCityDealsDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(SAVED_OFFERS_STORE, 'readwrite');
      const store = tx.objectStore(SAVED_OFFERS_STORE);
      const record: SavedOfferRecord = {
        id: offer.id,
        offer,
        savedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const request = store.put(record);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Failed to save offer into IDB:', err);
  }
}

/**
 * Bulk save or refresh offers into IndexedDB
 */
export async function bulkSaveOffersToIDB(offers: Offer[]): Promise<void> {
  if (!offers.length) return;
  try {
    const db = await openCityDealsDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(SAVED_OFFERS_STORE, 'readwrite');
      const store = tx.objectStore(SAVED_OFFERS_STORE);

      offers.forEach((offer) => {
        store.put({
          id: offer.id,
          offer,
          savedAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      });

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Bulk save failed:', err);
  }
}

/**
 * Remove an offer from IndexedDB
 */
export async function removeOfferFromIDB(offerId: string): Promise<void> {
  try {
    const db = await openCityDealsDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(SAVED_OFFERS_STORE, 'readwrite');
      const store = tx.objectStore(SAVED_OFFERS_STORE);
      const request = store.delete(offerId);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Failed to delete offer from IDB:', err);
  }
}

/**
 * Check if a specific offer is saved in IndexedDB
 */
export async function isOfferSavedInIDB(offerId: string): Promise<boolean> {
  try {
    const db = await openCityDealsDB();
    return new Promise((resolve) => {
      const tx = db.transaction(SAVED_OFFERS_STORE, 'readonly');
      const store = tx.objectStore(SAVED_OFFERS_STORE);
      const request = store.get(offerId);

      request.onsuccess = () => {
        resolve(!!request.result);
      };
      request.onerror = () => resolve(false);
    });
  } catch {
    return false;
  }
}

/**
 * Get or set app metadata key-value in IndexedDB
 */
export async function setIDBMetadata(key: string, value: any): Promise<void> {
  try {
    const db = await openCityDealsDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(METADATA_STORE, 'readwrite');
      const store = tx.objectStore(METADATA_STORE);
      const request = store.put({ key, value, updatedAt: new Date().toISOString() });
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] setIDBMetadata error:', err);
  }
}

export async function getIDBMetadata<T = any>(key: string): Promise<T | null> {
  try {
    const db = await openCityDealsDB();
    return new Promise((resolve) => {
      const tx = db.transaction(METADATA_STORE, 'readonly');
      const store = tx.objectStore(METADATA_STORE);
      const request = store.get(key);
      request.onsuccess = () => {
        resolve(request.result ? request.result.value : null);
      };
      request.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}
