/**
 * Google Analytics 4 (GA4) Integration Helper for CityDeals
 * Measurement ID: G-KEGZTX40Z6
 */

export const GA_MEASUREMENT_ID = 'G-KEGZTX40Z6';

declare global {
  interface Window {
    dataLayer?: any[];
    gtag?: (...args: any[]) => void;
  }
}

/**
 * Initialize Google Analytics 4 tracking script and dataLayer safely.
 * Guaranteed to execute only once without duplicating tags.
 */
export function initGA(): void {
  if (typeof window === 'undefined') return;

  // Prevent duplicate script injection
  if (document.getElementById('ga4-script') || document.querySelector(`script[src*="${GA_MEASUREMENT_ID}"]`)) {
    return;
  }

  // Setup dataLayer and gtag queue immediately so events before load are buffered
  window.dataLayer = window.dataLayer || [];
  if (typeof window.gtag !== 'function') {
    window.gtag = function gtag() {
      window.dataLayer?.push(arguments);
    };
    window.gtag('js', new Date());
    window.gtag('config', GA_MEASUREMENT_ID, {
      send_page_view: false,
    });
  }

  const injectScript = () => {
    if (document.getElementById('ga4-script')) return;
    const script = document.createElement('script');
    script.id = 'ga4-script';
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
    document.head.appendChild(script);
  };

  const scheduleInject = () => {
    if ('requestIdleCallback' in window) {
      (window as any).requestIdleCallback(injectScript, { timeout: 3000 });
    } else {
      setTimeout(injectScript, 1500);
    }
  };

  if (document.readyState === 'complete') {
    scheduleInject();
  } else {
    window.addEventListener('load', scheduleInject, { once: true });
  }
}

/**
 * Track SPA Page Views
 */
let lastTrackedPath = '';
export function trackPageView(pagePath: string, pageTitle?: string): void {
  if (typeof window === 'undefined') return;

  // Avoid duplicate rapid-fire tracking of identical page transitions
  const cleanPath = pagePath.startsWith('/') ? pagePath : `/${pagePath}`;
  if (cleanPath === lastTrackedPath) return;
  lastTrackedPath = cleanPath;

  if (typeof window.gtag === 'function') {
    window.gtag('event', 'page_view', {
      page_path: cleanPath,
      page_title: pageTitle || document.title,
      page_location: window.location.href,
    });
  }
}

/**
 * Track Custom GA4 Events safely
 */
export function trackEvent(eventName: string, params?: Record<string, any>): void {
  if (typeof window === 'undefined') return;

  if (typeof window.gtag === 'function') {
    window.gtag('event', eventName, params);
  }
}

/**
 * Specific GA4 Event Helpers for CityDeals Business Life-cycle
 */

// 1. User Registration (Customer or Merchant)
export function trackUserRegistration(method: string, role: string): void {
  trackEvent('sign_up', {
    method,
    user_role: role,
  });

  if (role === 'merchant') {
    trackEvent('merchant_registration', {
      method,
    });
  }
}

// 2. User Login
export function trackUserLogin(method: string, role?: string): void {
  trackEvent('login', {
    method,
    user_role: role || 'user',
  });
}

// 3. Offer / Deal Views
const recentlyTrackedOfferIds = new Set<string>();
export function trackOfferView(offer: {
  id: string;
  headline: string;
  category: string;
  discountValue?: string;
  shopName?: string;
  city?: string;
}): void {
  if (!offer?.id) return;

  // Debounce duplicate view events in the same session within 5 seconds
  if (recentlyTrackedOfferIds.has(offer.id)) return;
  recentlyTrackedOfferIds.add(offer.id);
  setTimeout(() => {
    recentlyTrackedOfferIds.delete(offer.id);
  }, 5000);

  trackEvent('view_item', {
    item_id: offer.id,
    item_name: offer.headline,
    item_category: offer.category,
    discount_value: offer.discountValue,
    shop_name: offer.shopName,
    city: offer.city || 'Dibrugarh',
  });
}

// 4. Offer Submissions by Merchants
export function trackOfferSubmission(offer: {
  headline: string;
  category: string;
  discountValue: string;
  shopName?: string;
  isEditing?: boolean;
}): void {
  trackEvent('offer_submission', {
    item_name: offer.headline,
    item_category: offer.category,
    discount_value: offer.discountValue,
    shop_name: offer.shopName,
    is_update: Boolean(offer.isEditing),
  });
}

// 5. Merchant Business Profile Creation / Update
export function trackMerchantBusinessSaved(business: {
  name: string;
  category: string;
  city: string;
  locality: string;
}): void {
  trackEvent('merchant_profile_saved', {
    shop_name: business.name,
    category: business.category,
    city: business.city,
    locality: business.locality,
  });
}
