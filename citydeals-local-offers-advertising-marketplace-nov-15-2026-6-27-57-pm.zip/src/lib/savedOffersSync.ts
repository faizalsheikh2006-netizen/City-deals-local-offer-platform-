/**
 * Firestore User Saved Offers Synchronization Service
 *
 * Provides bidirectional real-time and on-demand synchronization of bookmarked offers
 * between local IndexedDB and Google Cloud Firestore.
 *
 * Hierarchy:
 * /users/{userId}/savedOffers/{offerId}
 * Payload: { offerId, offerSnapshot, savedAt, updatedAt }
 */

import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDocs,
  onSnapshot,
  Unsubscribe,
} from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from './firebase';
import { Offer } from '../types';
import {
  saveOfferToIDB,
  removeOfferFromIDB,
  getAllSavedOffersFromIDB,
  bulkSaveOffersToIDB,
} from './indexedDb';

export interface FirestoreSavedOfferDoc {
  offerId: string;
  offer?: Offer;
  savedAt: string;
  updatedAt: string;
}

/**
 * Saves a bookmarked offer to Firestore under the authenticated user's profile
 */
export async function syncSaveOfferToFirestore(offer: Offer, userId: string): Promise<void> {
  if (!userId) return;
  const path = `users/${userId}/savedOffers/${offer.id}`;
  try {
    const docRef = doc(db, 'users', userId, 'savedOffers', offer.id);
    const payload: FirestoreSavedOfferDoc = {
      offerId: offer.id,
      offer,
      savedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(docRef, payload, { merge: true });
  } catch (error) {
    // If offline or permission error, log gracefully without blocking offline IndexedDB functionality
    console.warn(`[Firestore Saved Offers] Could not sync offer ${offer.id} to Firestore (will remain safe in IndexedDB):`, error);
  }
}

/**
 * Deletes a bookmarked offer from Firestore
 */
export async function syncRemoveOfferFromFirestore(offerId: string, userId: string): Promise<void> {
  if (!userId) return;
  const path = `users/${userId}/savedOffers/${offerId}`;
  try {
    const docRef = doc(db, 'users', userId, 'savedOffers', offerId);
    await deleteDoc(docRef);
  } catch (error) {
    console.warn(`[Firestore Saved Offers] Could not remove offer ${offerId} from Firestore:`, error);
  }
}

/**
 * Loads all saved offers from Firestore for a given user, merging them into IndexedDB
 */
export async function fetchUserSavedOffersFromFirestore(userId: string): Promise<Offer[]> {
  if (!userId) return [];
  const path = `users/${userId}/savedOffers`;
  try {
    const colRef = collection(db, 'users', userId, 'savedOffers');
    const snapshot = await getDocs(colRef);
    const remoteOffers: Offer[] = [];

    snapshot.forEach((docSnap) => {
      const data = docSnap.data() as FirestoreSavedOfferDoc;
      if (data.offer) {
        remoteOffers.push(data.offer);
      }
    });

    if (remoteOffers.length > 0) {
      // Sync down to IndexedDB
      await bulkSaveOffersToIDB(remoteOffers);
    }

    return remoteOffers;
  } catch (error) {
    console.warn('[Firestore Saved Offers] Fetch failed (falling back to IndexedDB):', error);
    return [];
  }
}

/**
 * Real-time listener for Firestore saved offers
 */
export function subscribeUserSavedOffers(
  userId: string,
  onUpdate: (remoteOffers: Offer[], remoteOfferIds: string[]) => void
): Unsubscribe | null {
  if (!userId) return null;
  const path = `users/${userId}/savedOffers`;

  try {
    const colRef = collection(db, 'users', userId, 'savedOffers');
    const unsub = onSnapshot(
      colRef,
      async (snapshot) => {
        const offers: Offer[] = [];
        const ids: string[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as FirestoreSavedOfferDoc;
          ids.push(docSnap.id);
          if (data.offer) {
            offers.push(data.offer);
          }
        });

        // Mirror remote changes into IndexedDB
        if (offers.length > 0) {
          await bulkSaveOffersToIDB(offers);
        }

        onUpdate(offers, ids);
      },
      (error) => {
        console.warn('[Firestore Saved Offers] Snapshot listener warning:', error.message);
      }
    );

    return unsub;
  } catch (err) {
    console.warn('[Firestore Saved Offers] Listener registration failed:', err);
    return null;
  }
}

/**
 * Push all local IndexedDB saved offers to Firestore once user signs in or reconnects
 */
export async function syncLocalIDBToFirestore(userId: string): Promise<void> {
  if (!userId) return;
  try {
    const localRecords = await getAllSavedOffersFromIDB();
    if (localRecords.length === 0) return;

    for (const record of localRecords) {
      if (record.offer) {
        await syncSaveOfferToFirestore(record.offer, userId);
      }
    }
  } catch (err) {
    console.warn('[Firestore Saved Offers] syncLocalIDBToFirestore failed:', err);
  }
}
