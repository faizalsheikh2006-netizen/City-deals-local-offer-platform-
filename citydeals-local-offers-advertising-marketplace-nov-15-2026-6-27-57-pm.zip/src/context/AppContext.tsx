import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { api } from '../api/client';
import { City, Category, PromotionPackage, Offer, Business, User, UserRole, Product, ShopCart, ShoppingOrder, District, LocalityItem } from '../types/index';
import { auth, signInWithGoogle, sendFirebasePasswordReset, signOut, onAuthStateChanged } from '../lib/firebase';
import { trackUserLogin, trackUserRegistration } from '../lib/analytics';
import {
  getAllSavedOffersFromIDB,
  getSavedOfferIdsFromIDB,
  saveOfferToIDB,
  removeOfferFromIDB,
  bulkSaveOffersToIDB,
} from '../lib/indexedDb';
import {
  syncSaveOfferToFirestore,
  syncRemoveOfferFromFirestore,
  fetchUserSavedOffersFromFirestore,
  subscribeUserSavedOffers,
  syncLocalIDBToFirestore,
} from '../lib/savedOffersSync';

interface ToastState {
  message: string;
  type: 'success' | 'error' | 'info';
  id: number;
}

export type ModalType =
  | 'details'
  | 'report'
  | 'request-promotion'
  | 'request-verification'
  | 'post-offer'
  | 'edit-offer'
  | 'info-about'
  | 'info-rates'
  | 'info-privacy'
  | 'city-selector'
  | 'auth'
  | 'share'
  | 'referrals'
  | 'suggest-deal'
  | 'product-details'
  | 'cart'
  | 'checkout'
  | 'order-details'
  | 'order-history'
  | 'post-product'
  | 'edit-product'
  | null;

interface AppContextType {
  // Role & Authentication Session
  role: UserRole;
  effectiveRole: UserRole;
  user: User;
  business: Business | null;
  isAuthenticated: boolean;
  adminPreviewMode: 'admin' | 'merchant' | 'public';
  setAdminPreviewMode: (mode: 'admin' | 'merchant' | 'public') => void;
  login: (email: string, password: string) => Promise<User>;
  loginWithGoogle: () => Promise<User>;
  sendPasswordReset: (email: string) => Promise<void>;
  register: (
    name: string,
    email: string,
    password: string,
    role: 'public' | 'merchant',
    phone?: string,
    referralCode?: string
  ) => Promise<User>;
  logout: () => Promise<void>;
  switchRole: (newRole: UserRole) => Promise<void>;
  setBusiness: (biz: Business | null) => void;

  // Referrals & Sharing
  activeReferralCode: string | null;
  referrerInfo: { name: string; role: string; code: string } | null;
  shareCityDeals: (customRefCode?: string) => Promise<void>;
  shareOffer: (offer: Offer) => Promise<void>;
  getPermanentAppUrl: (referralCode?: string) => string;
  getPermanentOfferUrl: (offerId: string) => string;

  // Selected Location & Dynamic Hierarchy
  selectedDistrict: string;
  setSelectedDistrict: (district: string) => void;
  selectedLocality: string;
  setSelectedLocality: (locality: string) => void;
  districts: District[];
  setDistricts: React.Dispatch<React.SetStateAction<District[]>>;
  getLocalitiesForDistrict: (districtIdOrName?: string) => LocalityItem[];

  // Selected City & Config (Maintained for backwards compatibility)
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  cities: City[];
  categories: Category[];
  promotionPackages: PromotionPackage[];
  isLoadingConfig: boolean;

  // Saved / Bookmarked Offers (IndexedDB + Firestore Sync)
  savedOfferIds: string[];
  savedOffers: Offer[];
  isOffline: boolean;
  isSyncingSavedOffers: boolean;
  toggleSaveOffer: (id: string, offerObj?: Offer) => Promise<void>;
  isOfferSaved: (id: string) => boolean;
  refreshSavedOffersFromIDB: () => Promise<void>;

  // Navigation & Views
  activeView: 'browse' | 'shopping' | 'merchant' | 'admin';
  setActiveView: (view: 'browse' | 'shopping' | 'merchant' | 'admin') => void;

  // CityDeals Shopping & Cart
  cart: ShopCart | null;
  cartCount: number;
  addToCart: (product: Product, quantity?: number) => { success: boolean; conflictShopName?: string };
  forceAddToCart: (product: Product, quantity?: number) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  selectedShopProfileId: string | null;
  setSelectedShopProfileId: (shopId: string | null) => void;

  // Modals
  modalType: ModalType;
  modalData: any;
  openModal: (type: ModalType, data?: any) => void;
  closeModal: () => void;

  // Global notification toast
  toast: ToastState | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;

  // PWA Install Prompt
  isInstallable: boolean;
  promptInstall: () => Promise<void>;

  // Global refresh counter
  refreshKey: number;
  triggerRefresh: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Default Fallback Public Citizen Persona
const DEFAULT_PUBLIC_USER: User = {
  id: 'usr-guest',
  name: 'Dibrugarh Visitor',
  email: 'visitor@citydeals.in',
  role: 'public',
  createdAt: new Date().toISOString(),
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [sessionCache] = useState(() => {
    try {
      const stored = localStorage.getItem('citydeals_auth_session');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [role, setRole] = useState<UserRole>(sessionCache?.user?.role || 'public');
  const [user, setUser] = useState<User>(sessionCache?.user || DEFAULT_PUBLIC_USER);
  const [business, setBusiness] = useState<Business | null>(sessionCache?.business || null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(
    Boolean(sessionCache?.user?.id && sessionCache.user.id !== 'usr-guest')
  );

  // Admin Preview Mode ('admin' | 'merchant' | 'public') - strictly in-memory / session preview without modifying real role
  const [adminPreviewMode, setAdminPreviewModeState] = useState<'admin' | 'merchant' | 'public'>(() => {
    try {
      const stored = sessionStorage.getItem('citydeals_admin_preview');
      if (stored === 'merchant' || stored === 'public' || stored === 'admin') {
        return stored;
      }
    } catch {}
    return 'admin';
  });

  const setAdminPreviewMode = (mode: 'admin' | 'merchant' | 'public') => {
    setAdminPreviewModeState(mode);
    try {
      sessionStorage.setItem('citydeals_admin_preview', mode);
    } catch {}
  };

  // Compute effective role for UI rendering
  const effectiveRole: UserRole =
    user.role === 'admin'
      ? adminPreviewMode === 'merchant'
        ? 'merchant'
        : adminPreviewMode === 'public'
        ? 'public'
        : 'admin'
      : user.role;

  const [selectedDistrict, setSelectedDistrictState] = useState<string>(() => {
    try {
      return localStorage.getItem('citydeals_district') || 'Dibrugarh';
    } catch {
      return 'Dibrugarh';
    }
  });
  const [selectedLocality, setSelectedLocalityState] = useState<string>(() => {
    try {
      return localStorage.getItem('citydeals_locality') || 'all';
    } catch {
      return 'all';
    }
  });
  const [districts, setDistricts] = useState<District[]>([]);

  const [selectedCity, setSelectedCityState] = useState<string>(() => {
    try {
      return localStorage.getItem('citydeals_district') || 'Dibrugarh';
    } catch {
      return 'Dibrugarh';
    }
  });

  const setSelectedDistrict = (dist: string) => {
    setSelectedDistrictState(dist);
    setSelectedCityState(dist);
    setSelectedLocalityState('all');
    try {
      localStorage.setItem('citydeals_district', dist);
      localStorage.setItem('citydeals_locality', 'all');
    } catch (e) {
      console.warn('Storage unavailable', e);
    }
  };

  const setSelectedLocality = (loc: string) => {
    setSelectedLocalityState(loc);
    try {
      localStorage.setItem('citydeals_locality', loc);
    } catch (e) {
      console.warn('Storage unavailable', e);
    }
  };

  const setSelectedCity = (city: string) => {
    setSelectedCityState(city);
    setSelectedDistrictState(city);
    try {
      localStorage.setItem('citydeals_district', city);
    } catch (e) {
      console.warn('Storage unavailable', e);
    }
  };

  const getLocalitiesForDistrict = (districtIdOrName?: string): LocalityItem[] => {
    const target = (districtIdOrName || selectedDistrict).toLowerCase().trim();
    const found = districts.find(
      (d) => d.id.toLowerCase() === target || d.name.toLowerCase() === target
    );
    if (found && found.localities && found.localities.length > 0) {
      return found.localities.filter((l) => l.isActive !== false);
    }
    const cityMatch = cities.find(
      (c) => c.id.toLowerCase() === target || c.name.toLowerCase() === target
    );
    if (cityMatch && cityMatch.localities) {
      return cityMatch.localities.map((locName) => ({
        id: locName.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        name: locName,
        districtId: cityMatch.id,
        districtName: cityMatch.name,
        state: 'Assam',
        isActive: true,
      }));
    }
    return [];
  };

  const [cities, setCities] = useState<City[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [promotionPackages, setPromotionPackages] = useState<PromotionPackage[]>([]);
  const [isLoadingConfig, setIsLoadingConfig] = useState<boolean>(true);

  const [savedOfferIds, setSavedOfferIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('citydeals_saved_offers');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [savedOffers, setSavedOffers] = useState<Offer[]>([]);
  const [isOffline, setIsOffline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? !navigator.onLine : false;
  });
  const [isSyncingSavedOffers, setIsSyncingSavedOffers] = useState<boolean>(false);

  const [activeView, setActiveView] = useState<'browse' | 'shopping' | 'merchant' | 'admin'>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname.toLowerCase();
      const params = new URLSearchParams(window.location.search);
      if (path === '/admin' || path.startsWith('/admin/') || params.get('view') === 'admin') {
        return 'admin';
      }
      if (path === '/shopping' || params.get('view') === 'shopping') {
        return 'shopping';
      }
      if (path === '/merchant' || params.get('view') === 'merchant') {
        return 'merchant';
      }
    }
    return 'browse';
  });

  // Sync URL route with activeView
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const currentPath = window.location.pathname.toLowerCase();
    const params = new URLSearchParams(window.location.search);
    if (activeView === 'admin') {
      if (currentPath !== '/admin') {
        window.history.pushState({}, '', '/admin');
      }
    } else if (currentPath === '/admin' || params.get('view') === 'admin') {
      window.history.pushState({}, '', '/');
    }
  }, [activeView]);

  // Listen for browser navigation (Back / Forward)
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname.toLowerCase();
      const params = new URLSearchParams(window.location.search);
      if (path === '/admin' || path.startsWith('/admin/') || params.get('view') === 'admin') {
        setActiveView('admin');
      } else if (path === '/shopping' || params.get('view') === 'shopping') {
        setActiveView('shopping');
      } else if (path === '/merchant' || params.get('view') === 'merchant') {
        setActiveView('merchant');
      } else {
        setActiveView('browse');
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);
  const [selectedShopProfileId, setSelectedShopProfileId] = useState<string | null>(null);

  // Cart State (Strictly single-shop per order)
  const [cart, setCart] = useState<ShopCart | null>(() => {
    try {
      const stored = localStorage.getItem('citydeals_shop_cart');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  // Sync cart to localStorage
  useEffect(() => {
    try {
      if (cart && cart.items.length > 0) {
        localStorage.setItem('citydeals_shop_cart', JSON.stringify(cart));
      } else {
        localStorage.removeItem('citydeals_shop_cart');
      }
    } catch (e) {
      console.warn('Could not save cart to localStorage:', e);
    }
  }, [cart]);

  const cartCount = cart ? cart.items.reduce((sum, item) => sum + item.quantity, 0) : 0;

  const addToCart = (product: Product, quantity = 1): { success: boolean; conflictShopName?: string } => {
    if (!product.inStock) {
      showToast(`${product.name} is currently out of stock.`, 'error');
      return { success: false };
    }

    if (cart && cart.items.length > 0 && cart.businessId !== product.businessId) {
      return { success: false, conflictShopName: cart.shopName };
    }

    const qtyToAdd = Math.max(1, quantity);

    setCart((prevCart) => {
      if (!prevCart || prevCart.businessId !== product.businessId) {
        return {
          businessId: product.businessId,
          shopName: product.shopName,
          shopAddress: product.shopAddress || product.address || 'Dibrugarh',
          shopPhone: product.shopPhone || product.contactPhone || '',
          shopWhatsapp: product.shopWhatsapp || product.contactWhatsapp,
          items: [{ product, quantity: qtyToAdd }],
        };
      }

      const existingItemIndex = prevCart.items.findIndex((i) => i.product.id === product.id);
      let updatedItems = [...prevCart.items];

      if (existingItemIndex > -1) {
        const curItem = updatedItems[existingItemIndex];
        const newQty = curItem.quantity + qtyToAdd;
        updatedItems[existingItemIndex] = { ...curItem, quantity: newQty };
      } else {
        updatedItems.push({ product, quantity: qtyToAdd });
      }

      return {
        ...prevCart,
        items: updatedItems,
      };
    });

    showToast(`Added ${product.name} to shopping cart`, 'success');
    return { success: true };
  };

  const forceAddToCart = (product: Product, quantity = 1) => {
    const qtyToAdd = Math.max(1, quantity);
    const newCart: ShopCart = {
      businessId: product.businessId,
      shopName: product.shopName,
      shopAddress: product.shopAddress || product.address || 'Dibrugarh',
      shopPhone: product.shopPhone || product.contactPhone || '',
      shopWhatsapp: product.shopWhatsapp || product.contactWhatsapp,
      items: [{ product, quantity: qtyToAdd }],
    };
    setCart(newCart);
    showToast(`Cart replaced with items from ${product.shopName}`, 'info');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    setCart((prev) => {
      if (!prev) return null;
      if (quantity <= 0) {
        const remaining = prev.items.filter((i) => i.product.id !== productId);
        if (remaining.length === 0) return null;
        return { ...prev, items: remaining };
      }

      const updated = prev.items.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      );
      return { ...prev, items: updated };
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => {
      if (!prev) return null;
      const remaining = prev.items.filter((i) => i.product.id !== productId);
      if (remaining.length === 0) {
        showToast('Shopping cart is now empty', 'info');
        return null;
      }
      return { ...prev, items: remaining };
    });
  };

  const clearCart = () => {
    setCart(null);
    try {
      localStorage.removeItem('citydeals_shop_cart');
    } catch {}
  };
  const [modalType, setModalType] = useState<ModalType>(null);
  const [modalData, setModalData] = useState<any>(null);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [refreshKey, setRefreshKey] = useState<number>(1);

  // Referral State
  const [activeReferralCode, setActiveReferralCode] = useState<string | null>(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const urlRef = urlParams.get('ref');
      if (urlRef) {
        localStorage.setItem('citydeals_pending_referral', urlRef.trim().toUpperCase());
        return urlRef.trim().toUpperCase();
      }
      return localStorage.getItem('citydeals_pending_referral');
    } catch {
      return null;
    }
  });

  const [referrerInfo, setReferrerInfo] = useState<{ name: string; role: string; code: string } | null>(null);

  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);

  // Listen for native PWA beforeinstallprompt event
  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  const promptInstall = async () => {
    if (!installPrompt) return;
    try {
      installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstallable(false);
        showToast('CityDeals installed to home screen!', 'success');
      }
      setInstallPrompt(null);
    } catch {
      // Ignored
    }
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now();
    setToast({ message, type, id });
    setTimeout(() => {
      setToast((current) => (current?.id === id ? null : current));
    }, 4500);
  };

  // Check URL query parameters for deep links (?ref=CODE, ?offer=ID)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const refParam = params.get('ref');
    const offerParam = params.get('offer');

    if (refParam) {
      const cleanRef = refParam.trim().toUpperCase();
      setActiveReferralCode(cleanRef);
      try {
        localStorage.setItem('citydeals_pending_referral', cleanRef);
      } catch (e) {
        console.warn('Storage unavailable', e);
      }

      // Validate referral code with backend
      api.validateReferralCode(cleanRef)
        .then((res) => {
          if (res.valid && res.referrer) {
            setReferrerInfo(res.referrer);
            showToast(`Invited by ${res.referrer.name}! Sign up to connect with local businesses.`, 'success');
          }
        })
        .catch(() => {
          // Invalid or nonexistent referral code
        });
    }

    // Direct offer link
    if (offerParam) {
      api.getOfferById(offerParam)
        .then((res) => {
          if (res.offer) {
            openModal('details', res.offer);
          }
        })
        .catch((err) => {
          console.warn('Direct offer link error:', err);
        });
    }

    // Password reset deep link (?reset_token=TOKEN or ?resetToken=TOKEN)
    const resetToken = params.get('reset_token') || params.get('resetToken');
    if (resetToken) {
      setModalType('auth');
      setModalData({ tab: 'reset-password', token: resetToken.trim() });
    }
  }, []);

  // Restore authenticated session on mount and listen to Firebase Auth state
  useEffect(() => {
    let isSubscribed = true;

    // 1. First check existing token from password session or cached Firebase token
    async function verifyCurrentToken() {
      const token = api.getToken();
      if (token) {
        try {
          const res = await api.getMe();
          if (isSubscribed) {
            setUser(res.user);
            setRole(res.user.role);
            setBusiness(res.business || null);
            setIsAuthenticated(true);
            try {
              localStorage.setItem(
                'citydeals_auth_session',
                JSON.stringify({ user: res.user, business: res.business || null, token })
              );
            } catch (e) {
              console.warn('Storage unavailable', e);
            }
          }
          return true;
        } catch {
          // Token expired, clear invalid token
          api.setToken(null);
          try {
            localStorage.removeItem('citydeals_auth_session');
          } catch {}
        }
      }
      return false;
    }

    verifyCurrentToken();

    // 2. Attach persistent Firebase Auth listener
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (!isSubscribed) return;

      if (fbUser) {
        try {
          const idToken = await fbUser.getIdToken();
          api.setToken(idToken);
          const res = await api.getMe();
          if (isSubscribed) {
            setUser(res.user);
            setRole(res.user.role);
            setBusiness(res.business || null);
            setIsAuthenticated(true);
            try {
              localStorage.setItem(
                'citydeals_auth_session',
                JSON.stringify({ user: res.user, business: res.business || null, token: idToken })
              );
            } catch (e) {
              console.warn('Storage unavailable', e);
            }
          }
        } catch (err) {
          console.warn('[Firebase Auth] Failed to restore session from Firebase token:', err);
        }
      }
    });

    return () => {
      isSubscribed = false;
      unsubscribe();
    };
  }, []);

  // Permanent URL Generators
  const getPermanentAppUrl = (overrideRefCode?: string): string => {
    const origin = typeof window !== 'undefined' && window.location.origin ? window.location.origin : 'https://citydeals.in';
    const code = overrideRefCode || user?.referralCode || activeReferralCode;
    return code ? `${origin}/?ref=${encodeURIComponent(code)}` : origin;
  };

  const getPermanentOfferUrl = (offerId: string): string => {
    const origin = typeof window !== 'undefined' && window.location.origin ? window.location.origin : 'https://citydeals.in';
    const base = `${origin}/?offer=${encodeURIComponent(offerId)}`;
    const code = user?.referralCode || activeReferralCode;
    return code ? `${base}&ref=${encodeURIComponent(code)}` : base;
  };

  const shareCityDeals = async (customRefCode?: string) => {
    openModal('share', {
      mode: 'app',
      referralCode: customRefCode || user?.referralCode || activeReferralCode,
    });
  };

  const shareOffer = async (offer: Offer) => {
    openModal('share', {
      mode: 'offer',
      offer,
      referralCode: user?.referralCode || activeReferralCode,
    });
  };

  // Load platform config on mount
  useEffect(() => {
    async function loadConfig() {
      try {
        setIsLoadingConfig(true);
        const data = await api.getConfig();
        setCities(data.cities);
        if (data.districts) setDistricts(data.districts);
        setCategories(data.categories);
        setPromotionPackages(data.promotionPackages);
      } catch (err) {
        console.error('Error loading config:', err);
      } finally {
        setIsLoadingConfig(false);
      }
    }
    loadConfig();
  }, []);

  // Track browser online / offline state
  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      showToast('Internet connection restored. Syncing saved offers...', 'success');
      // Push any offline bookmarks created while disconnected to Firestore
      if (user && user.id && user.id !== 'usr-guest') {
        syncLocalIDBToFirestore(user.id);
      }
    };
    const handleOffline = () => {
      setIsOffline(true);
      showToast('You are currently offline. Saved offers remain available from local storage.', 'info');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [user]);

  // Load saved offers from IndexedDB on initial mount
  const refreshSavedOffersFromIDB = async () => {
    try {
      const records = await getAllSavedOffersFromIDB();
      if (records && records.length > 0) {
        const idList = records.map((r) => r.id);
        const offerList = records.map((r) => r.offer).filter(Boolean);
        setSavedOfferIds(idList);
        setSavedOffers(offerList);
      }
    } catch (err) {
      console.warn('[AppContext] Could not refresh saved offers from IDB:', err);
    }
  };

  useEffect(() => {
    refreshSavedOffersFromIDB();
  }, []);

  // Multi-Device Firestore Synchronization for Authenticated Users
  useEffect(() => {
    if (!user || !user.id || user.id === 'usr-guest') {
      return;
    }

    let isMounted = true;
    setIsSyncingSavedOffers(true);

    // 1. Initial sync: sync any local IndexedDB bookmarks up to Firestore
    syncLocalIDBToFirestore(user.id).catch(() => {});

    // 2. Fetch remote saved offers and merge
    fetchUserSavedOffersFromFirestore(user.id)
      .then((remoteOffers) => {
        if (!isMounted) return;
        if (remoteOffers && remoteOffers.length > 0) {
          setSavedOffers((prev) => {
            const map = new Map<string, Offer>();
            prev.forEach((o) => map.set(o.id, o));
            remoteOffers.forEach((o) => map.set(o.id, o));
            return Array.from(map.values());
          });
          setSavedOfferIds((prev) => {
            const combined = Array.from(new Set([...prev, ...remoteOffers.map((o) => o.id)]));
            return combined;
          });
        }
      })
      .finally(() => {
        if (isMounted) setIsSyncingSavedOffers(false);
      });

    // 3. Attach real-time Firestore listener for live multi-device synchronization
    const unsub = subscribeUserSavedOffers(user.id, (remoteOffers, remoteIds) => {
      if (!isMounted) return;
      if (remoteOffers.length > 0) {
        setSavedOffers((prev) => {
          const map = new Map<string, Offer>();
          prev.forEach((o) => map.set(o.id, o));
          remoteOffers.forEach((o) => map.set(o.id, o));
          return Array.from(map.values());
        });
      }
      setSavedOfferIds((prev) => {
        return Array.from(new Set([...prev, ...remoteIds]));
      });
    });

    return () => {
      isMounted = false;
      if (unsub) unsub();
    };
  }, [user]);

  // Backup sync to localStorage for legacy fallback
  useEffect(() => {
    try {
      localStorage.setItem('citydeals_saved_offers', JSON.stringify(savedOfferIds));
    } catch (e) {
      console.warn('Could not save bookmarks to storage:', e);
    }
  }, [savedOfferIds]);

  // Real Login
  const login = async (email: string, pass: string): Promise<User> => {
    const res = await api.login(email, pass);
    setUser(res.user);
    setRole(res.user.role);
    setBusiness(res.business || null);
    setIsAuthenticated(true);
    try {
      localStorage.setItem(
        'citydeals_auth_session',
        JSON.stringify({ user: res.user, business: res.business || null, token: api.getToken() })
      );
    } catch (e) {
      console.warn('Storage unavailable', e);
    }

    // Track GA4 User Login
    trackUserLogin('password', res.user.role);

    if (res.user.role === 'admin') {
      setAdminPreviewMode('admin');
      setActiveView('admin');
      showToast(`Welcome Founder & Administrator ${res.user.name}!`, 'success');
    } else if (res.user.role === 'merchant') {
      setActiveView('merchant');
      showToast(`Welcome back, ${res.user.name} (Shopkeeper Portal)`, 'success');
    } else {
      setActiveView('browse');
      showToast(`Signed in as ${res.user.name}`, 'success');
    }

    closeModal();
    triggerRefresh();
    return res.user;
  };

  // Google Sign-In with Native Firebase Auth
  const loginWithGoogle = async (): Promise<User> => {
    try {
      const { token } = await signInWithGoogle();
      api.setToken(token);
      const res = await api.getMe();
      setUser(res.user);
      setRole(res.user.role);
      setBusiness(res.business || null);
      setIsAuthenticated(true);

      // Track GA4 User Login
      trackUserLogin('google', res.user.role);

      if (res.user.role === 'admin') {
        setAdminPreviewMode('admin');
        setActiveView('admin');
        showToast(`Authenticated as Administrator ${res.user.name}!`, 'success');
      } else if (res.user.role === 'merchant') {
        setActiveView('merchant');
        showToast(`Signed in as merchant ${res.user.name}`, 'success');
      } else {
        setActiveView('browse');
        showToast(`Signed in as ${res.user.name}`, 'success');
      }

      closeModal();
      triggerRefresh();
      return res.user;
    } catch (err: any) {
      console.error('Google Sign-in failed:', err);
      showToast(err.message || 'Google Sign-in failed', 'error');
      throw err;
    }
  };

  // Secure Password Reset via Firebase Auth with safe fallback
  const sendPasswordReset = async (email: string): Promise<void> => {
    try {
      await sendFirebasePasswordReset(email);
      showToast(`Password reset link dispatched to ${email} via Firebase Auth!`, 'success');
    } catch (err: any) {
      // If Email provider is disabled in Firebase console, fall back to backend recovery
      if (err.code === 'auth/operation-not-allowed' || err.message?.includes('operation-not-allowed')) {
        await api.forgotPassword(email);
        showToast(`Password recovery instructions dispatched to ${email}!`, 'success');
      } else {
        throw err;
      }
    }
  };

  // Real Registration
  const register = async (
    name: string,
    email: string,
    pass: string,
    regRole: 'public' | 'merchant',
    phone?: string,
    referralCode?: string
  ): Promise<User> => {
    // Resolve referral code: explicit param > active state > local storage
    const resolvedRefCode = referralCode || activeReferralCode || localStorage.getItem('citydeals_pending_referral') || undefined;

    const res = await api.register(name, email, pass, regRole, phone, resolvedRefCode);
    setUser(res.user);
    setRole(res.user.role);
    setBusiness(res.business || null);
    setIsAuthenticated(true);
    try {
      localStorage.setItem(
        'citydeals_auth_session',
        JSON.stringify({ user: res.user, business: res.business || null, token: api.getToken() })
      );
    } catch (e) {
      console.warn('Storage unavailable', e);
    }

    // Track GA4 User Registration (Customer or Merchant)
    trackUserRegistration('password', regRole);

    // Clear pending referral after successful registration
    try {
      localStorage.removeItem('citydeals_pending_referral');
    } catch {
      // ignore
    }
    setActiveReferralCode(null);

    if (regRole === 'merchant') {
      setActiveView('merchant');
      showToast(`Merchant account created! Set up your shop profile to start.`, 'success');
    } else {
      setActiveView('browse');
      showToast(`Welcome to CityDeals, ${res.user.name}!`, 'success');
    }

    closeModal();
    triggerRefresh();
    return res.user;
  };

  // Secure Manual Logout
  const logout = async () => {
    try {
      await api.logout();
    } catch (e) {
      console.warn('Backend logout failed:', e);
    }
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Firebase signOut failed:', e);
    }
    try {
      localStorage.removeItem('citydeals_auth_session');
      sessionStorage.removeItem('citydeals_admin_preview');
    } catch {}
    setAdminPreviewModeState('admin');
    api.setToken(null);
    setUser(DEFAULT_PUBLIC_USER);
    setRole('public');
    setBusiness(null);
    setIsAuthenticated(false);
    setActiveView('browse');
    showToast('Signed out of CityDeals.', 'info');
    triggerRefresh();
  };

  // Safe Role / Preview Switcher without mutating database role
  const switchRole = async (targetRole: UserRole) => {
    // If real role is admin, handle Preview Application As mode safely
    if (user.role === 'admin') {
      if (targetRole === 'admin') {
        setAdminPreviewMode('admin');
        setActiveView('admin');
        showToast('Returned to Founder & Admin Dashboard', 'info');
      } else if (targetRole === 'merchant') {
        setAdminPreviewMode('merchant');
        setActiveView('merchant');
        showToast('Previewing CityDeals as a Merchant', 'info');
      } else {
        setAdminPreviewMode('public');
        setActiveView('browse');
        showToast('Previewing CityDeals as a Public Citizen', 'info');
      }
      return;
    }

    // For merchants: seamlessly toggle between public browsing and merchant portal using ONE account
    if (user.role === 'merchant') {
      if (targetRole === 'merchant') {
        setActiveView('merchant');
      } else {
        setActiveView('browse');
      }
      return;
    }

    // For public users:
    if (user.role === 'public') {
      if (targetRole === 'public') {
        setActiveView('browse');
        return;
      }
      // Public users cannot self-elevate to merchant: prompt them to sign in or register
      openModal('auth', { defaultRole: 'merchant', tab: 'login' });
      return;
    }

    // Unauthenticated: prompt sign in
    openModal('auth', { defaultRole: targetRole, tab: 'login' });
  };

  const toggleSaveOffer = async (id: string, offerObj?: Offer) => {
    const exists = savedOfferIds.includes(id);

    if (exists) {
      // 1. Remove from React state
      setSavedOfferIds((prev) => prev.filter((item) => item !== id));
      setSavedOffers((prev) => prev.filter((o) => o.id !== id));
      showToast('Deal removed from saved list', 'info');

      // 2. Remove from IndexedDB
      await removeOfferFromIDB(id);

      // 3. Remove from Firestore if user is authenticated
      if (user && user.id && user.id !== 'usr-guest') {
        syncRemoveOfferFromFirestore(id, user.id);
      }
    } else {
      // 1. Add to React state
      setSavedOfferIds((prev) => [...prev, id]);
      if (offerObj) {
        setSavedOffers((prev) => {
          const filtered = prev.filter((o) => o.id !== id);
          return [offerObj, ...filtered];
        });
      }
      showToast(
        isOffline
          ? 'Deal saved locally in offline storage! Access anytime under Saved Deals.'
          : 'Deal saved! Synced across devices & available offline.',
        'success'
      );

      // 2. Persist to IndexedDB
      if (offerObj) {
        await saveOfferToIDB(offerObj);
      }

      // 3. Sync to Firestore if authenticated
      if (offerObj && user && user.id && user.id !== 'usr-guest') {
        syncSaveOfferToFirestore(offerObj, user.id);
      }
    }
  };

  const isOfferSaved = (id: string) => savedOfferIds.includes(id);

  const openModal = (type: ModalType, data?: any) => {
    setModalType(type);
    setModalData(data || null);
  };

  const closeModal = () => {
    setModalType(null);
    setModalData(null);
  };

  const triggerRefresh = () => {
    setRefreshKey((k) => k + 1);
  };

  return (
    <AppContext.Provider
      value={{
        role,
        effectiveRole,
        adminPreviewMode,
        setAdminPreviewMode,
        user,
        business,
        isAuthenticated,
        login,
        loginWithGoogle,
        sendPasswordReset,
        register,
        logout,
        switchRole,
        setBusiness,
        activeReferralCode,
        referrerInfo,
        shareCityDeals,
        shareOffer,
        getPermanentAppUrl,
        getPermanentOfferUrl,
        selectedDistrict,
        setSelectedDistrict,
        selectedLocality,
        setSelectedLocality,
        districts,
        setDistricts,
        getLocalitiesForDistrict,
        selectedCity,
        setSelectedCity,
        cities,
        categories,
        promotionPackages,
        isLoadingConfig,
        savedOfferIds,
        savedOffers,
        isOffline,
        isSyncingSavedOffers,
        toggleSaveOffer,
        isOfferSaved,
        refreshSavedOffersFromIDB,
        activeView,
        setActiveView,
        cart,
        cartCount,
        addToCart,
        forceAddToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        selectedShopProfileId,
        setSelectedShopProfileId,
        modalType,
        modalData,
        openModal,
        closeModal,
        toast,
        showToast,
        isInstallable,
        promptInstall,
        refreshKey,
        triggerRefresh,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
