export type UserRole = 'public' | 'merchant' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  businessId?: string;
  createdAt: string;
  isDemo?: boolean;
  referralCode?: string;
  referredBy?: string;
  referralCount?: number;
}

export type ReferralStatus = 'verified' | 'pending' | 'flagged';

export interface Referral {
  id: string;
  referrerId: string;
  referrerName: string;
  referrerEmail: string;
  referrerCode: string;
  referralCode?: string;
  referredUserId: string;
  referredUserName: string;
  referredUserEmail: string;
  referredUserRole: UserRole;
  status: ReferralStatus;
  notes?: string;
  ipAddress?: string;
  createdAt: string;
  verifiedAt?: string;
}

export interface ReferralCampaignConfig {
  enabled: boolean;
  programName: string;
  rewardType: 'community_badge' | 'privilege' | 'discount_credit';
  rewardDescription: string;
  maxReferralsPerUser: number;
  termsAndConditions: string;
  qualifyingAction: 'registration' | 'first_offer_published' | 'manual_review';
  isActive?: boolean;
  campaignName?: string;
  rulesDescription?: string;
}

export interface Session {
  token: string;
  userId: string;
  role: UserRole;
  createdAt: string;
  expiresAt: string;
}

export interface PasswordResetRecord {
  id: string;
  email: string;
  userId: string;
  token: string;
  expiresAt: string;
  usedAt?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorEmail: string;
  actorRole: UserRole;
  action: string;
  targetType: 'offer' | 'business' | 'promotion' | 'report' | 'user' | 'referral' | 'suggestion' | 'package' | 'product' | 'order';
  targetId: string;
  details: string;
  timestamp: string;
}

export interface LocalityItem {
  id: string;
  name: string;
  districtId: string;
  districtName: string;
  state: string;
  isActive?: boolean;
  latitude?: number;
  longitude?: number;
}

export interface District {
  id: string;
  name: string;
  state: string;
  isActive?: boolean;
  isLaunchMarket?: boolean;
  localities: LocalityItem[];
}

export interface City {
  id: string;
  name: string;
  state: string;
  districtId?: string;
  districtName?: string;
  isLaunchMarket?: boolean;
  localities: string[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  description: string;
  color: string;
}

export type OfferStatus = 'pending' | 'approved' | 'rejected' | 'expired' | 'suspended';

export type SponsorTier = 'starter' | 'popular' | 'monthly' | 'homepage_featured' | 'boost' | 'featured' | 'spotlight' | null;

export interface Offer {
  id: string;
  businessId: string;
  merchantId: string;
  merchantEmail: string;
  shopName: string;
  state?: string;
  district?: string;
  districtId?: string;
  city: string; // District or City name for backwards compatibility
  locality: string;
  localityId?: string;
  address: string;
  fullAddress?: string;
  landmark: string;
  category: string;
  headline: string; // e.g. "Up to 25% Off on Selected Ethnic Wear", "Buy 1 Get 1 Free on Woodfired Pizzas"
  discountValue: string; // e.g. "Up to 25% Off", "BOGO Offer", "Festival Special"
  description: string;
  terms: string[];
  contactPhone: string;
  contactWhatsapp?: string;
  locationUrl?: string; // Google Maps directions link
  imageUrl: string;
  openingHours?: string;
  validFrom: string;
  validUntil: string;
  startDate?: string;
  expiryDate?: string;
  status: OfferStatus;
  isActive: boolean; // Merchant can activate/deactivate
  isDistrictWide?: boolean; // When true, shown district-wide across all localities
  rejectionReason?: string | null;
  moderationNotes?: string | null;
  isSponsored: boolean;
  sponsorTier?: SponsorTier;
  sponsorBadge?: string;
  sponsorExpiry?: string | null;
  viewsCount: number;
  clicksCount: number;
  sharesCount?: number;
  latitude?: number;
  longitude?: number;
  distanceKm?: number;
  lastVerifiedAt?: string;
  verifiedBy?: string;
  createdAt: string;
  updatedAt: string;
  isDemo?: boolean;
}

export interface Business {
  id: string;
  merchantId: string;
  name: string;
  category: string;
  state?: string;
  district?: string;
  districtId?: string;
  city: string; // Backwards compatible city/district field
  locality: string;
  localityId?: string;
  address: string;
  fullAddress?: string;
  landmark: string;
  phone: string;
  whatsapp?: string;
  email: string;
  description: string;
  logoUrl?: string;
  openingHours: string;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  verified: boolean;
  isVerified?: boolean;
  isFeatured?: boolean;
  latitude?: number;
  longitude?: number;
  distanceKm?: number;
  rejectionReason?: string | null;
  createdAt: string;
  isDemo?: boolean;
  verifiedBadge?: boolean;
  verificationValidUntil?: string;
  verifiedAt?: string;
  verificationRequestId?: string;
}

export type VerificationStatus = 'pending' | 'pending_review' | 'approved' | 'verified' | 'rejected' | 'revoked';

export interface VerificationRequest {
  id: string;
  businessId: string;
  merchantId: string;
  merchantEmail: string;
  shopName: string;
  businessName?: string;
  ownerName: string;
  phone: string;
  locality: string;
  district: string;
  address: string;
  tradeLicenseNumber?: string;
  gstNumber?: string;
  documentType: 'trade_license' | 'gst_certificate' | 'utility_bill' | 'shop_establishment' | 'other';
  documentUrl: string;
  documentName?: string;
  verificationFee: number;
  feeAmount?: number;
  paymentMethod: string;
  paymentReference: string;
  paymentStatus?: 'pending' | 'verified' | 'failed' | 'rejected';
  status: VerificationStatus;
  adminNotes?: string;
  requestedAt: string;
  createdAt?: string;
  reviewedAt?: string;
  reviewedBy?: string;
  validUntil?: string;
  isDemo?: boolean;
}

export interface DealSuggestion {
  id: string;
  shopName: string;
  locality: string;
  category?: string;
  offerHeadline: string;
  estimatedDiscount?: string;
  details?: string;
  submitterName?: string;
  submitterContact?: string;
  status: 'pending' | 'verified_added' | 'dismissed';
  adminNotes?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface PromotionPackage {
  id: string;
  name: string;
  tier: 'starter' | 'popular' | 'monthly' | 'homepage_featured' | 'boost' | 'featured' | 'spotlight';
  priceInr: number;
  price?: number;
  durationDays: number;
  description: string;
  badge: string;
  features: string[];
  recommended?: boolean;
}

export type PromotionStatus = 'pending' | 'pending_verification' | 'approved' | 'active' | 'rejected' | 'expired';

export interface PromotionRequest {
  id: string;
  merchantId: string;
  merchantEmail: string;
  businessId: string;
  offerId: string;
  offerHeadline: string;
  shopName: string;
  packageId: string;
  packageName: string;
  tier: 'starter' | 'popular' | 'monthly' | 'homepage_featured' | 'boost' | 'featured' | 'spotlight';
  priceInr: number;
  feeAmount?: number;
  durationDays: number;
  paymentMethod: string;
  transactionReference: string;
  paymentReference?: string;
  paymentStatus?: 'pending' | 'verified' | 'rejected';
  status: PromotionStatus;
  adminNotes?: string;
  requestedAt: string;
  createdAt?: string;
  activatedAt?: string;
  expiresAt?: string;
  startDate?: string;
  isDemo?: boolean;
}

export type ReportReason = 
  | 'misleading'
  | 'expired'
  | 'incorrect_terms'
  | 'shop_refused_deal'
  | 'closed_shop'
  | 'offensive'
  | 'other';

export type ReportStatus = 'open' | 'investigating' | 'resolved_dismissed' | 'resolved_action_taken';

export interface Report {
  id: string;
  offerId: string;
  offerHeadline: string;
  shopName: string;
  reporterName?: string;
  reporterContact?: string;
  reason: ReportReason;
  details: string;
  status: ReportStatus;
  adminNotes?: string;
  createdAt: string;
  resolvedAt?: string;
  isDemo?: boolean;
}

// Grouped Shop with its active in-store offers
export interface ShopWithOffers {
  business: Business;
  activeOffers: Offer[];
}

// ==================== CITYDEALS SHOPPING MARKETPLACE TYPES ====================

export type ProductStatus = 'pending' | 'approved' | 'rejected' | 'suspended';

export interface Product {
  id: string;
  businessId: string;
  merchantId: string;
  merchantEmail: string;
  shopName: string;
  city: string;
  locality: string;
  address: string;
  category: string;
  name: string;
  description: string;
  price: number; // in INR
  originalPrice?: number; // MRP for discount calculation
  stockQuantity: number;
  inStock: boolean;
  imageUrl: string;
  additionalImages?: string[];
  videoUrl?: string; // Short product demo video (MP4/HLS)
  status: ProductStatus;
  isActive: boolean; // Merchant toggles visibility
  deliveryAvailable?: boolean; // Merchant offers local home delivery
  pickupAvailable?: boolean; // Merchant offers in-store customer pickup
  fulfillmentOptions?: ('delivery' | 'pickup')[];
  rejectionReason?: string | null;
  moderationNotes?: string | null;
  contactPhone: string;
  contactWhatsapp?: string;
  shopAddress?: string;
  shopPhone?: string;
  shopWhatsapp?: string;
  latitude?: number;
  longitude?: number;
  distanceKm?: number;
  viewsCount?: number;
  ordersCount?: number;
  featured?: boolean;
  createdAt: string;
  updatedAt: string;
  isDemo?: boolean;
}

export type OrderStatus =
  | 'pending'
  | 'accepted'
  | 'rejected'
  | 'preparing'
  | 'ready_for_pickup'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export type FulfillmentType = 'delivery' | 'pickup';

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  imageUrl?: string;
  category?: string;
}

export interface ShoppingOrder {
  id: string;
  orderNumber: string; // e.g. CD-ORD-9281
  customerId?: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  businessId: string;
  merchantId: string;
  shopName: string;
  shopAddress: string;
  shopPhone: string;
  shopWhatsapp?: string;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  totalAmount: number;
  fulfillmentType: FulfillmentType;
  deliveryAddress?: string;
  customerNotes?: string;
  status: OrderStatus;
  merchantNotes?: string;
  paymentMethod: 'cash_on_delivery' | 'pay_at_store';
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ShopCart {
  businessId: string;
  shopName: string;
  shopAddress: string;
  shopPhone: string;
  shopWhatsapp?: string;
  items: CartItem[];
}

